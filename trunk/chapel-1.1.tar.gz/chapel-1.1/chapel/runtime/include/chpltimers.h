/**************************************************************************
  Copyright (c) 2004-2010 Cray Inc.  (See LICENSE file for more details)
**************************************************************************/


#ifndef _chpltimers_h_
#define _chpltimers_h_

#ifndef LAUNCHER

_real64 _now_time(void);

#endif // LAUNCHER

#endif
