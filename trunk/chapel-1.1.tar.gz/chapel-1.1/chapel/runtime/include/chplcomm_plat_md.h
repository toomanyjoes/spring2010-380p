/**************************************************************************
  Copyright (c) 2004-2010 Cray Inc.  (See LICENSE file for more details)
**************************************************************************/


#ifndef _chplcomm_plat_md_h_
#define _chplcomm_plat_md_h_

#endif
