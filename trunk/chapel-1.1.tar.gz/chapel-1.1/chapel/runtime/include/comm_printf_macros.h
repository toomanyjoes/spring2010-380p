/**************************************************************************
  Copyright (c) 2004-2010 Cray Inc.  (See LICENSE file for more details)
**************************************************************************/


#ifndef _comm_printf_macros_h_
#define _comm_printf_macros_h_

#define PRINTF_DEF printf

#endif
