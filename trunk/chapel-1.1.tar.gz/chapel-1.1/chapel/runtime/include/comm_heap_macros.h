/**************************************************************************
  Copyright (c) 2004-2010 Cray Inc.  (See LICENSE file for more details)
**************************************************************************/


#ifndef _comm_heap_macros_h_
#define _comm_heap_macros_h_

#define CHPL_HEAP_REGISTER_GLOBAL_VAR_EXTRA(i, wide)

#endif
