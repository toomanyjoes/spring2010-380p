/**************************************************************************
  Copyright (c) 2004-2010 Cray Inc.  (See LICENSE file for more details)
**************************************************************************/


#ifndef _VERSION_H_
#define _VERSION_H_

void get_version(char *);

#endif
