/* A Bison parser, made by GNU Bison 2.3.  */

/* Skeleton interface for Bison's Yacc-like parsers in C

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     TIDENT = 258,
     IMAGLITERAL = 259,
     INTLITERAL = 260,
     REALLITERAL = 261,
     STRINGLITERAL = 262,
     TATOMIC = 263,
     TBEGIN = 264,
     TBREAK = 265,
     TBY = 266,
     TCLASS = 267,
     TCOBEGIN = 268,
     TCOFORALL = 269,
     TCONFIG = 270,
     TCONST = 271,
     TCONTINUE = 272,
     TDEF = 273,
     TDELETE = 274,
     TDMAPPED = 275,
     TDO = 276,
     TDOMAIN = 277,
     TELSE = 278,
     TENUM = 279,
     TEXTERN = 280,
     TFOR = 281,
     TFORALL = 282,
     TIF = 283,
     TIN = 284,
     TINDEX = 285,
     TINOUT = 286,
     TLABEL = 287,
     TLET = 288,
     TLOCAL = 289,
     TMINUSMINUS = 290,
     TMODULE = 291,
     TNEW = 292,
     TNIL = 293,
     TON = 294,
     TOTHERWISE = 295,
     TOUT = 296,
     TPARAM = 297,
     TPLUSPLUS = 298,
     TPRAGMA = 299,
     TPRIMITIVE = 300,
     TRECORD = 301,
     TREDUCE = 302,
     TRETURN = 303,
     TSCAN = 304,
     TSELECT = 305,
     TSERIAL = 306,
     TSINGLE = 307,
     TSPARSE = 308,
     TSUBDOMAIN = 309,
     TSYNC = 310,
     TTHEN = 311,
     TTYPE = 312,
     TUNION = 313,
     TUSE = 314,
     TVAR = 315,
     TWHEN = 316,
     TWHERE = 317,
     TWHILE = 318,
     TYIELD = 319,
     TALIAS = 320,
     TAND = 321,
     TASSIGN = 322,
     TASSIGNBAND = 323,
     TASSIGNBOR = 324,
     TASSIGNBXOR = 325,
     TASSIGNDIVIDE = 326,
     TASSIGNEXP = 327,
     TASSIGNLAND = 328,
     TASSIGNLOR = 329,
     TASSIGNMINUS = 330,
     TASSIGNMOD = 331,
     TASSIGNMULTIPLY = 332,
     TASSIGNPLUS = 333,
     TASSIGNSL = 334,
     TASSIGNSR = 335,
     TBAND = 336,
     TBNOT = 337,
     TBOR = 338,
     TBXOR = 339,
     TCOLON = 340,
     TCOMMA = 341,
     TDIVIDE = 342,
     TDOT = 343,
     TDOTDOT = 344,
     TDOTDOTDOT = 345,
     TEQUAL = 346,
     TEXP = 347,
     TGREATER = 348,
     TGREATEREQUAL = 349,
     THASH = 350,
     TLESS = 351,
     TLESSEQUAL = 352,
     TMINUS = 353,
     TMOD = 354,
     TNOT = 355,
     TNOTEQUAL = 356,
     TOR = 357,
     TPLUS = 358,
     TQUESTION = 359,
     TSEMI = 360,
     TSHIFTLEFT = 361,
     TSHIFTRIGHT = 362,
     TSTAR = 363,
     TSWAP = 364,
     TLCBR = 365,
     TRCBR = 366,
     TLP = 367,
     TRP = 368,
     TLSBR = 369,
     TRSBR = 370,
     TNOELSE = 371,
     TUMINUS = 372,
     TUPLUS = 373
   };
#endif
/* Tokens.  */
#define TIDENT 258
#define IMAGLITERAL 259
#define INTLITERAL 260
#define REALLITERAL 261
#define STRINGLITERAL 262
#define TATOMIC 263
#define TBEGIN 264
#define TBREAK 265
#define TBY 266
#define TCLASS 267
#define TCOBEGIN 268
#define TCOFORALL 269
#define TCONFIG 270
#define TCONST 271
#define TCONTINUE 272
#define TDEF 273
#define TDELETE 274
#define TDMAPPED 275
#define TDO 276
#define TDOMAIN 277
#define TELSE 278
#define TENUM 279
#define TEXTERN 280
#define TFOR 281
#define TFORALL 282
#define TIF 283
#define TIN 284
#define TINDEX 285
#define TINOUT 286
#define TLABEL 287
#define TLET 288
#define TLOCAL 289
#define TMINUSMINUS 290
#define TMODULE 291
#define TNEW 292
#define TNIL 293
#define TON 294
#define TOTHERWISE 295
#define TOUT 296
#define TPARAM 297
#define TPLUSPLUS 298
#define TPRAGMA 299
#define TPRIMITIVE 300
#define TRECORD 301
#define TREDUCE 302
#define TRETURN 303
#define TSCAN 304
#define TSELECT 305
#define TSERIAL 306
#define TSINGLE 307
#define TSPARSE 308
#define TSUBDOMAIN 309
#define TSYNC 310
#define TTHEN 311
#define TTYPE 312
#define TUNION 313
#define TUSE 314
#define TVAR 315
#define TWHEN 316
#define TWHERE 317
#define TWHILE 318
#define TYIELD 319
#define TALIAS 320
#define TAND 321
#define TASSIGN 322
#define TASSIGNBAND 323
#define TASSIGNBOR 324
#define TASSIGNBXOR 325
#define TASSIGNDIVIDE 326
#define TASSIGNEXP 327
#define TASSIGNLAND 328
#define TASSIGNLOR 329
#define TASSIGNMINUS 330
#define TASSIGNMOD 331
#define TASSIGNMULTIPLY 332
#define TASSIGNPLUS 333
#define TASSIGNSL 334
#define TASSIGNSR 335
#define TBAND 336
#define TBNOT 337
#define TBOR 338
#define TBXOR 339
#define TCOLON 340
#define TCOMMA 341
#define TDIVIDE 342
#define TDOT 343
#define TDOTDOT 344
#define TDOTDOTDOT 345
#define TEQUAL 346
#define TEXP 347
#define TGREATER 348
#define TGREATEREQUAL 349
#define THASH 350
#define TLESS 351
#define TLESSEQUAL 352
#define TMINUS 353
#define TMOD 354
#define TNOT 355
#define TNOTEQUAL 356
#define TOR 357
#define TPLUS 358
#define TQUESTION 359
#define TSEMI 360
#define TSHIFTLEFT 361
#define TSHIFTRIGHT 362
#define TSTAR 363
#define TSWAP 364
#define TLCBR 365
#define TRCBR 366
#define TLP 367
#define TRP 368
#define TLSBR 369
#define TRSBR 370
#define TNOELSE 371
#define TUMINUS 372
#define TUPLUS 373




#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
#line 38 "chapel.ypp"
{
  const char* pch;
  Vec<const char*>* vpch;
  RetTag retTag;
  bool b;
  IntentTag pt;
  Expr* pexpr;
  DefExpr* pdefexpr;
  CallExpr* pcallexpr;
  BlockStmt* pblockstmt;
  Type* ptype;
  EnumType* penumtype;
  FnSymbol* pfnsymbol;
}
/* Line 1489 of yacc.c.  */
#line 300 "chapel.tab.h"
	YYSTYPE;
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif

extern YYSTYPE yylval;

#if ! defined YYLTYPE && ! defined YYLTYPE_IS_DECLARED
typedef struct YYLTYPE
{
  int first_line;
  int first_column;
  int last_line;
  int last_column;
} YYLTYPE;
# define yyltype YYLTYPE /* obsolescent; will be withdrawn */
# define YYLTYPE_IS_DECLARED 1
# define YYLTYPE_IS_TRIVIAL 1
#endif

extern YYLTYPE yylloc;
