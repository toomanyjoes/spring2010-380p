/* A Bison parser, made by GNU Bison 2.3.  */

/* Skeleton implementation for Bison's Yacc-like parsers in C

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "2.3"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Using locations.  */
#define YYLSP_NEEDED 1



/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     TIDENT = 258,
     IMAGLITERAL = 259,
     INTLITERAL = 260,
     REALLITERAL = 261,
     STRINGLITERAL = 262,
     TATOMIC = 263,
     TBEGIN = 264,
     TBREAK = 265,
     TBY = 266,
     TCLASS = 267,
     TCOBEGIN = 268,
     TCOFORALL = 269,
     TCONFIG = 270,
     TCONST = 271,
     TCONTINUE = 272,
     TDEF = 273,
     TDELETE = 274,
     TDMAPPED = 275,
     TDO = 276,
     TDOMAIN = 277,
     TELSE = 278,
     TENUM = 279,
     TEXTERN = 280,
     TFOR = 281,
     TFORALL = 282,
     TIF = 283,
     TIN = 284,
     TINDEX = 285,
     TINOUT = 286,
     TLABEL = 287,
     TLET = 288,
     TLOCAL = 289,
     TMINUSMINUS = 290,
     TMODULE = 291,
     TNEW = 292,
     TNIL = 293,
     TON = 294,
     TOTHERWISE = 295,
     TOUT = 296,
     TPARAM = 297,
     TPLUSPLUS = 298,
     TPRAGMA = 299,
     TPRIMITIVE = 300,
     TRECORD = 301,
     TREDUCE = 302,
     TRETURN = 303,
     TSCAN = 304,
     TSELECT = 305,
     TSERIAL = 306,
     TSINGLE = 307,
     TSPARSE = 308,
     TSUBDOMAIN = 309,
     TSYNC = 310,
     TTHEN = 311,
     TTYPE = 312,
     TUNION = 313,
     TUSE = 314,
     TVAR = 315,
     TWHEN = 316,
     TWHERE = 317,
     TWHILE = 318,
     TYIELD = 319,
     TALIAS = 320,
     TAND = 321,
     TASSIGN = 322,
     TASSIGNBAND = 323,
     TASSIGNBOR = 324,
     TASSIGNBXOR = 325,
     TASSIGNDIVIDE = 326,
     TASSIGNEXP = 327,
     TASSIGNLAND = 328,
     TASSIGNLOR = 329,
     TASSIGNMINUS = 330,
     TASSIGNMOD = 331,
     TASSIGNMULTIPLY = 332,
     TASSIGNPLUS = 333,
     TASSIGNSL = 334,
     TASSIGNSR = 335,
     TBAND = 336,
     TBNOT = 337,
     TBOR = 338,
     TBXOR = 339,
     TCOLON = 340,
     TCOMMA = 341,
     TDIVIDE = 342,
     TDOT = 343,
     TDOTDOT = 344,
     TDOTDOTDOT = 345,
     TEQUAL = 346,
     TEXP = 347,
     TGREATER = 348,
     TGREATEREQUAL = 349,
     THASH = 350,
     TLESS = 351,
     TLESSEQUAL = 352,
     TMINUS = 353,
     TMOD = 354,
     TNOT = 355,
     TNOTEQUAL = 356,
     TOR = 357,
     TPLUS = 358,
     TQUESTION = 359,
     TSEMI = 360,
     TSHIFTLEFT = 361,
     TSHIFTRIGHT = 362,
     TSTAR = 363,
     TSWAP = 364,
     TLCBR = 365,
     TRCBR = 366,
     TLP = 367,
     TRP = 368,
     TLSBR = 369,
     TRSBR = 370,
     TNOELSE = 371,
     TUMINUS = 372,
     TUPLUS = 373
   };
#endif
/* Tokens.  */
#define TIDENT 258
#define IMAGLITERAL 259
#define INTLITERAL 260
#define REALLITERAL 261
#define STRINGLITERAL 262
#define TATOMIC 263
#define TBEGIN 264
#define TBREAK 265
#define TBY 266
#define TCLASS 267
#define TCOBEGIN 268
#define TCOFORALL 269
#define TCONFIG 270
#define TCONST 271
#define TCONTINUE 272
#define TDEF 273
#define TDELETE 274
#define TDMAPPED 275
#define TDO 276
#define TDOMAIN 277
#define TELSE 278
#define TENUM 279
#define TEXTERN 280
#define TFOR 281
#define TFORALL 282
#define TIF 283
#define TIN 284
#define TINDEX 285
#define TINOUT 286
#define TLABEL 287
#define TLET 288
#define TLOCAL 289
#define TMINUSMINUS 290
#define TMODULE 291
#define TNEW 292
#define TNIL 293
#define TON 294
#define TOTHERWISE 295
#define TOUT 296
#define TPARAM 297
#define TPLUSPLUS 298
#define TPRAGMA 299
#define TPRIMITIVE 300
#define TRECORD 301
#define TREDUCE 302
#define TRETURN 303
#define TSCAN 304
#define TSELECT 305
#define TSERIAL 306
#define TSINGLE 307
#define TSPARSE 308
#define TSUBDOMAIN 309
#define TSYNC 310
#define TTHEN 311
#define TTYPE 312
#define TUNION 313
#define TUSE 314
#define TVAR 315
#define TWHEN 316
#define TWHERE 317
#define TWHILE 318
#define TYIELD 319
#define TALIAS 320
#define TAND 321
#define TASSIGN 322
#define TASSIGNBAND 323
#define TASSIGNBOR 324
#define TASSIGNBXOR 325
#define TASSIGNDIVIDE 326
#define TASSIGNEXP 327
#define TASSIGNLAND 328
#define TASSIGNLOR 329
#define TASSIGNMINUS 330
#define TASSIGNMOD 331
#define TASSIGNMULTIPLY 332
#define TASSIGNPLUS 333
#define TASSIGNSL 334
#define TASSIGNSR 335
#define TBAND 336
#define TBNOT 337
#define TBOR 338
#define TBXOR 339
#define TCOLON 340
#define TCOMMA 341
#define TDIVIDE 342
#define TDOT 343
#define TDOTDOT 344
#define TDOTDOTDOT 345
#define TEQUAL 346
#define TEXP 347
#define TGREATER 348
#define TGREATEREQUAL 349
#define THASH 350
#define TLESS 351
#define TLESSEQUAL 352
#define TMINUS 353
#define TMOD 354
#define TNOT 355
#define TNOTEQUAL 356
#define TOR 357
#define TPLUS 358
#define TQUESTION 359
#define TSEMI 360
#define TSHIFTLEFT 361
#define TSHIFTRIGHT 362
#define TSTAR 363
#define TSWAP 364
#define TLCBR 365
#define TRCBR 366
#define TLP 367
#define TRP 368
#define TLSBR 369
#define TRSBR 370
#define TNOELSE 371
#define TUMINUS 372
#define TUPLUS 373




/* Copy the first part of user declarations.  */
#line 13 "chapel.ypp"


#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <stdint.h>
#include "lexyacc.h" // all #includes here, for make depend

  static int query_uid = 1;
  int captureTokens;
  char captureString[1024];

#define YYLLOC_DEFAULT(Current, Rhs, N)                             \
  if (N) {                                                          \
    (Current).first_line   = (Rhs)[1].first_line;                   \
    if ((Current).first_line) yystartlineno = (Current).first_line; \
    (Current).first_column = (Rhs)[1].first_column;                 \
    (Current).last_line    = (Rhs)[N].last_line;                    \
    (Current).last_column  = (Rhs)[N].last_column;                  \
  } else (Current) = yylloc;



/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 1
#endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

/* Enabling the token table.  */
#ifndef YYTOKEN_TABLE
# define YYTOKEN_TABLE 0
#endif

#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
#line 38 "chapel.ypp"
{
  const char* pch;
  Vec<const char*>* vpch;
  RetTag retTag;
  bool b;
  IntentTag pt;
  Expr* pexpr;
  DefExpr* pdefexpr;
  CallExpr* pcallexpr;
  BlockStmt* pblockstmt;
  Type* ptype;
  EnumType* penumtype;
  FnSymbol* pfnsymbol;
}
/* Line 187 of yacc.c.  */
#line 370 "chapel.tab.cpp"
	YYSTYPE;
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif

#if ! defined YYLTYPE && ! defined YYLTYPE_IS_DECLARED
typedef struct YYLTYPE
{
  int first_line;
  int first_column;
  int last_line;
  int last_column;
} YYLTYPE;
# define yyltype YYLTYPE /* obsolescent; will be withdrawn */
# define YYLTYPE_IS_DECLARED 1
# define YYLTYPE_IS_TRIVIAL 1
#endif


/* Copy the second part of user declarations.  */


/* Line 216 of yacc.c.  */
#line 395 "chapel.tab.cpp"

#ifdef short
# undef short
#endif

#ifdef YYTYPE_UINT8
typedef YYTYPE_UINT8 yytype_uint8;
#else
typedef unsigned char yytype_uint8;
#endif

#ifdef YYTYPE_INT8
typedef YYTYPE_INT8 yytype_int8;
#elif (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
typedef signed char yytype_int8;
#else
typedef short int yytype_int8;
#endif

#ifdef YYTYPE_UINT16
typedef YYTYPE_UINT16 yytype_uint16;
#else
typedef unsigned short int yytype_uint16;
#endif

#ifdef YYTYPE_INT16
typedef YYTYPE_INT16 yytype_int16;
#else
typedef short int yytype_int16;
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif ! defined YYSIZE_T && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned int
# endif
#endif

#define YYSIZE_MAXIMUM ((YYSIZE_T) -1)

#ifndef YY_
# if YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YYUSE(e) ((void) (e))
#else
# define YYUSE(e) /* empty */
#endif

/* Identity function, used to suppress warnings about constant conditions.  */
#ifndef lint
# define YYID(n) (n)
#else
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static int
YYID (int i)
#else
static int
YYID (i)
    int i;
#endif
{
  return i;
}
#endif

#if ! defined yyoverflow || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#     ifndef _STDLIB_H
#      define _STDLIB_H 1
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (YYID (0))
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined _STDLIB_H \
       && ! ((defined YYMALLOC || defined malloc) \
	     && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef _STDLIB_H
#    define _STDLIB_H 1
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* ! defined yyoverflow || YYERROR_VERBOSE */


#if (! defined yyoverflow \
     && (! defined __cplusplus \
	 || (defined YYLTYPE_IS_TRIVIAL && YYLTYPE_IS_TRIVIAL \
	     && defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yytype_int16 yyss;
  YYSTYPE yyvs;
    YYLTYPE yyls;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (yytype_int16) + sizeof (YYSTYPE) + sizeof (YYLTYPE)) \
      + 2 * YYSTACK_GAP_MAXIMUM)

/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  YYSIZE_T yyi;				\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (YYID (0))
#  endif
# endif

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack)					\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack, Stack, yysize);				\
	Stack = &yyptr->Stack;						\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (YYID (0))

#endif

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  3
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   7204

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  119
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  76
/* YYNRULES -- Number of rules.  */
#define YYNRULES  311
/* YYNRULES -- Number of states.  */
#define YYNSTATES  616

/* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   373

#define YYTRANSLATE(YYX)						\
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[YYLEX] -- Bison symbol number corresponding to YYLEX.  */
static const yytype_uint8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81,    82,    83,    84,
      85,    86,    87,    88,    89,    90,    91,    92,    93,    94,
      95,    96,    97,    98,    99,   100,   101,   102,   103,   104,
     105,   106,   107,   108,   109,   110,   111,   112,   113,   114,
     115,   116,   117,   118
};

#if YYDEBUG
/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
static const yytype_uint16 yyprhs[] =
{
       0,     0,     3,     5,     6,    10,    11,    15,    17,    19,
      21,    23,    25,    27,    29,    31,    33,    36,    39,    43,
      46,    50,    54,    57,    61,    64,    68,    72,    75,    79,
      83,    85,    90,    95,   100,   105,   110,   115,   120,   125,
     130,   135,   140,   145,   150,   155,   160,   164,   165,   167,
     169,   172,   174,   177,   181,   183,   185,   187,   189,   191,
     193,   199,   203,   209,   213,   219,   223,   230,   236,   240,
     247,   252,   257,   261,   268,   274,   280,   281,   284,   288,
     291,   298,   306,   307,   309,   311,   313,   315,   316,   319,
     320,   324,   331,   333,   337,   339,   343,   345,   346,   347,
     356,   362,   365,   370,   372,   375,   377,   379,   381,   383,
     385,   387,   389,   391,   393,   395,   397,   399,   401,   403,
     405,   407,   409,   411,   413,   415,   417,   419,   420,   424,
     425,   427,   431,   436,   441,   448,   455,   456,   458,   460,
     462,   464,   466,   468,   469,   471,   473,   475,   477,   479,
     481,   484,   486,   487,   489,   492,   495,   496,   499,   505,
     509,   512,   517,   518,   521,   526,   531,   536,   537,   539,
     541,   545,   549,   554,   560,   561,   563,   567,   570,   574,
     580,   581,   584,   585,   590,   591,   594,   597,   602,   609,
     610,   612,   614,   618,   623,   630,   631,   634,   637,   640,
     643,   646,   649,   651,   653,   657,   661,   662,   664,   666,
     669,   673,   677,   678,   680,   682,   686,   690,   694,   698,
     700,   702,   704,   708,   715,   720,   730,   738,   740,   747,
     752,   762,   770,   777,   782,   792,   800,   807,   810,   812,
     814,   816,   818,   823,   828,   834,   839,   842,   845,   850,
     852,   857,   859,   861,   865,   869,   872,   875,   877,   881,
     885,   889,   893,   897,   901,   905,   909,   913,   917,   921,
     925,   929,   933,   937,   941,   945,   949,   953,   957,   961,
     965,   968,   971,   974,   977,   980,   983,   985,   987,   989,
     991,   996,  1001,  1006,  1010,  1014,  1018,  1022,  1024,  1026,
    1028,  1030,  1034,  1038,  1042,  1046,  1048,  1050,  1052,  1054,
    1056,  1058
};

/* YYRHS -- A `-1'-separated list of the rules' RHS.  */
static const yytype_int16 yyrhs[] =
{
     120,     0,    -1,   121,    -1,    -1,   121,   122,   123,    -1,
      -1,   122,    44,     7,    -1,   124,    -1,   125,    -1,   130,
      -1,   132,    -1,   161,    -1,   131,    -1,   133,    -1,   136,
      -1,   129,    -1,     8,   123,    -1,     9,   123,    -1,    10,
     126,   105,    -1,    13,   125,    -1,    17,   126,   105,    -1,
      19,   182,   105,    -1,   184,   105,    -1,    32,   127,   123,
      -1,    34,   123,    -1,    39,   182,   128,    -1,    51,   182,
     128,    -1,    55,   123,    -1,    59,   177,   105,    -1,    64,
     182,   105,    -1,     1,    -1,   187,    67,   182,   105,    -1,
     187,    78,   182,   105,    -1,   187,    75,   182,   105,    -1,
     187,    77,   182,   105,    -1,   187,    71,   182,   105,    -1,
     187,    76,   182,   105,    -1,   187,    72,   182,   105,    -1,
     187,    68,   182,   105,    -1,   187,    69,   182,   105,    -1,
     187,    70,   182,   105,    -1,   187,    73,   182,   105,    -1,
     187,    74,   182,   105,    -1,   187,    80,   182,   105,    -1,
     187,    79,   182,   105,    -1,   187,   109,   187,   105,    -1,
     110,   121,   111,    -1,    -1,   127,    -1,     3,    -1,    21,
     123,    -1,   125,    -1,    48,   105,    -1,    48,   182,   105,
      -1,   105,    -1,   145,    -1,   137,    -1,   142,    -1,   162,
      -1,   165,    -1,    21,   123,    63,   182,   105,    -1,    63,
     182,   128,    -1,    14,   182,    29,   182,   128,    -1,    14,
     182,   128,    -1,    26,   182,    29,   182,   128,    -1,    26,
     182,   128,    -1,    26,    42,   127,    29,   182,   128,    -1,
      27,   182,    29,   182,   128,    -1,    27,   182,   128,    -1,
     114,   177,    29,   182,   115,   123,    -1,   114,   177,   115,
     123,    -1,    28,   182,    56,   123,    -1,    28,   182,   125,
      -1,    28,   182,    56,   123,    23,   123,    -1,    28,   182,
     125,    23,   123,    -1,    50,   182,   110,   134,   111,    -1,
      -1,   134,   135,    -1,    61,   177,   128,    -1,    40,   123,
      -1,    57,    50,   177,   110,   134,   111,    -1,   138,   139,
     127,   140,   110,   141,   111,    -1,    -1,    25,    -1,    12,
      -1,    46,    -1,    58,    -1,    -1,    85,   177,    -1,    -1,
     141,   122,   130,    -1,    24,   127,   110,   143,   111,   105,
      -1,   144,    -1,   143,    86,   144,    -1,   127,    -1,   127,
      67,   182,    -1,   148,    -1,    -1,    -1,    18,   146,   149,
     147,   155,   172,   160,   156,    -1,    25,    18,   149,   172,
     105,    -1,   150,   151,    -1,   127,    88,   150,   151,    -1,
     127,    -1,    82,   127,    -1,    67,    -1,    81,    -1,    83,
      -1,    84,    -1,    82,    -1,    91,    -1,   101,    -1,    97,
      -1,    94,    -1,    96,    -1,    93,    -1,   103,    -1,    98,
      -1,   108,    -1,    87,    -1,   106,    -1,   107,    -1,    99,
      -1,    92,    -1,   100,    -1,    11,    -1,    95,    -1,    -1,
     112,   152,   113,    -1,    -1,   153,    -1,   152,    86,   153,
      -1,   154,   127,   176,   170,    -1,   154,   127,   176,   159,
      -1,   154,   112,   169,   113,   176,   170,    -1,   154,   112,
     169,   113,   176,   159,    -1,    -1,    29,    -1,    31,    -1,
      41,    -1,    16,    -1,    42,    -1,    57,    -1,    -1,    16,
      -1,    60,    -1,    42,    -1,    57,    -1,   125,    -1,   129,
      -1,   104,   127,    -1,   104,    -1,    -1,   157,    -1,    90,
     182,    -1,    90,   158,    -1,    -1,    62,   182,    -1,    36,
     127,   110,   121,   111,    -1,    57,   163,   105,    -1,   127,
     164,    -1,   127,   164,    86,   163,    -1,    -1,    67,   182,
      -1,   166,    42,   167,   105,    -1,   166,    16,   167,   105,
      -1,   166,    60,   167,   105,    -1,    -1,    15,    -1,   168,
      -1,   167,    86,   168,    -1,   127,   172,   170,    -1,   127,
     171,    65,   182,    -1,   112,   169,   113,   172,   170,    -1,
      -1,   127,    -1,   112,   169,   113,    -1,   169,    86,    -1,
     169,    86,   127,    -1,   169,    86,   112,   169,   113,    -1,
      -1,    67,   182,    -1,    -1,    85,   114,   177,   115,    -1,
      -1,    85,   183,    -1,    85,   173,    -1,   114,   177,   115,
     182,    -1,   114,   177,    29,   182,   115,   182,    -1,    -1,
     182,    -1,   157,    -1,   114,   115,   174,    -1,   114,   177,
     115,   174,    -1,   114,   177,    29,   182,   115,   174,    -1,
      -1,    85,   183,    -1,    85,   157,    -1,    85,    22,    -1,
      85,    52,    -1,    85,    55,    -1,    85,   175,    -1,   182,
      -1,   157,    -1,   177,    86,   182,    -1,   177,    86,   157,
      -1,    -1,   182,    -1,   157,    -1,   178,    86,    -1,   178,
      86,   182,    -1,   178,    86,   157,    -1,    -1,   180,    -1,
     181,    -1,   180,    86,   181,    -1,   127,    67,   157,    -1,
     127,    67,   182,    -1,   127,    65,   182,    -1,   157,    -1,
     182,    -1,   183,    -1,   114,   177,   115,    -1,   114,   177,
      29,   182,   115,   182,    -1,   114,   177,   115,   182,    -1,
     114,   177,    29,   182,   115,    28,   182,    56,   182,    -1,
     114,   177,   115,    28,   182,    56,   182,    -1,   184,    -1,
      26,   182,    29,   182,    21,   182,    -1,    26,   182,    21,
     182,    -1,    26,   182,    29,   182,    21,    28,   182,    56,
     182,    -1,    26,   182,    21,    28,   182,    56,   182,    -1,
      27,   182,    29,   182,    21,   182,    -1,    27,   182,    21,
     182,    -1,    27,   182,    29,   182,    21,    28,   182,    56,
     182,    -1,    27,   182,    21,    28,   182,    56,   182,    -1,
      28,   182,    56,   182,    23,   182,    -1,    55,   182,    -1,
     185,    -1,   191,    -1,   187,    -1,   186,    -1,    22,   112,
     179,   113,    -1,    54,   112,   179,   113,    -1,    53,    54,
     112,   179,   113,    -1,    30,   112,   179,   113,    -1,    52,
     182,    -1,    37,   182,    -1,   112,    90,   182,   113,    -1,
      38,    -1,    33,   167,    29,   182,    -1,   192,    -1,   193,
      -1,   182,    85,   182,    -1,   182,    89,   182,    -1,   182,
      89,    -1,    89,   182,    -1,    89,    -1,   182,   103,   182,
      -1,   182,    98,   182,    -1,   182,   108,   182,    -1,   182,
      87,   182,    -1,   182,   106,   182,    -1,   182,   107,   182,
      -1,   182,    99,   182,    -1,   182,    91,   182,    -1,   182,
     101,   182,    -1,   182,    97,   182,    -1,   182,    94,   182,
      -1,   182,    96,   182,    -1,   182,    93,   182,    -1,   182,
      81,   182,    -1,   182,    83,   182,    -1,   182,    84,   182,
      -1,   182,    66,   182,    -1,   182,   102,   182,    -1,   182,
      92,   182,    -1,   182,    11,   182,    -1,   182,    95,   182,
      -1,   182,    20,   182,    -1,   103,   182,    -1,    98,   182,
      -1,    35,   182,    -1,    43,   182,    -1,   100,   182,    -1,
      82,   182,    -1,   127,    -1,   188,    -1,   189,    -1,   190,
      -1,   182,   112,   179,   113,    -1,   182,   114,   179,   115,
      -1,    45,   112,   179,   113,    -1,   182,    88,   127,    -1,
     182,    88,    57,    -1,   182,    88,    22,    -1,   112,   178,
     113,    -1,     5,    -1,     6,    -1,     4,    -1,     7,    -1,
     182,    47,   182,    -1,   194,    47,   182,    -1,   182,    49,
     182,    -1,   194,    49,   182,    -1,   103,    -1,   108,    -1,
      66,    -1,   102,    -1,    81,    -1,    83,    -1,    84,    -1
};

/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const yytype_uint16 yyrline[] =
{
       0,   162,   162,   166,   167,   171,   172,   176,   177,   178,
     179,   180,   181,   182,   183,   184,   185,   186,   187,   188,
     189,   190,   191,   192,   193,   194,   195,   196,   197,   198,
     199,   203,   204,   205,   206,   207,   208,   209,   210,   211,
     212,   213,   214,   215,   216,   217,   221,   225,   226,   230,
     234,   235,   239,   240,   244,   245,   246,   247,   248,   249,
     253,   254,   255,   256,   257,   258,   259,   260,   261,   262,
     268,   279,   280,   281,   282,   286,   291,   292,   296,   298,
     303,   310,   315,   316,   320,   321,   322,   326,   327,   332,
     333,   338,   348,   355,   363,   364,   368,   370,   375,   369,
     394,   407,   415,   429,   430,   431,   432,   433,   434,   435,
     436,   437,   438,   439,   440,   441,   442,   443,   444,   445,
     446,   447,   448,   449,   450,   451,   452,   456,   457,   461,
     462,   463,   467,   469,   471,   473,   478,   479,   480,   481,
     482,   483,   484,   488,   489,   490,   491,   492,   496,   497,
     501,   503,   508,   509,   513,   514,   518,   519,   523,   528,
     532,   539,   550,   551,   555,   557,   559,   564,   565,   569,
     570,   578,   583,   589,   594,   595,   597,   599,   601,   603,
     610,   611,   615,   616,   621,   622,   623,   627,   630,   641,
     642,   643,   647,   649,   651,   656,   657,   658,   659,   660,
     661,   662,   668,   669,   670,   671,   675,   677,   678,   679,
     681,   682,   686,   687,   691,   693,   698,   699,   700,   701,
     702,   706,   707,   709,   715,   722,   728,   738,   739,   741,
     743,   745,   747,   749,   751,   753,   755,   757,   762,   763,
     764,   765,   766,   768,   770,   772,   774,   776,   778,   780,
     782,   784,   785,   786,   788,   790,   792,   794,   799,   800,
     801,   802,   803,   804,   805,   806,   807,   808,   809,   810,
     811,   812,   813,   814,   815,   816,   817,   818,   819,   820,
     824,   825,   826,   827,   828,   829,   833,   834,   835,   836,
     840,   841,   842,   846,   847,   848,   852,   856,   857,   858,
     859,   863,   864,   868,   869,   873,   874,   875,   876,   877,
     878,   879
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || YYTOKEN_TABLE
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "TIDENT", "IMAGLITERAL", "INTLITERAL",
  "REALLITERAL", "STRINGLITERAL", "TATOMIC", "TBEGIN", "TBREAK", "TBY",
  "TCLASS", "TCOBEGIN", "TCOFORALL", "TCONFIG", "TCONST", "TCONTINUE",
  "TDEF", "TDELETE", "TDMAPPED", "TDO", "TDOMAIN", "TELSE", "TENUM",
  "TEXTERN", "TFOR", "TFORALL", "TIF", "TIN", "TINDEX", "TINOUT", "TLABEL",
  "TLET", "TLOCAL", "TMINUSMINUS", "TMODULE", "TNEW", "TNIL", "TON",
  "TOTHERWISE", "TOUT", "TPARAM", "TPLUSPLUS", "TPRAGMA", "TPRIMITIVE",
  "TRECORD", "TREDUCE", "TRETURN", "TSCAN", "TSELECT", "TSERIAL",
  "TSINGLE", "TSPARSE", "TSUBDOMAIN", "TSYNC", "TTHEN", "TTYPE", "TUNION",
  "TUSE", "TVAR", "TWHEN", "TWHERE", "TWHILE", "TYIELD", "TALIAS", "TAND",
  "TASSIGN", "TASSIGNBAND", "TASSIGNBOR", "TASSIGNBXOR", "TASSIGNDIVIDE",
  "TASSIGNEXP", "TASSIGNLAND", "TASSIGNLOR", "TASSIGNMINUS", "TASSIGNMOD",
  "TASSIGNMULTIPLY", "TASSIGNPLUS", "TASSIGNSL", "TASSIGNSR", "TBAND",
  "TBNOT", "TBOR", "TBXOR", "TCOLON", "TCOMMA", "TDIVIDE", "TDOT",
  "TDOTDOT", "TDOTDOTDOT", "TEQUAL", "TEXP", "TGREATER", "TGREATEREQUAL",
  "THASH", "TLESS", "TLESSEQUAL", "TMINUS", "TMOD", "TNOT", "TNOTEQUAL",
  "TOR", "TPLUS", "TQUESTION", "TSEMI", "TSHIFTLEFT", "TSHIFTRIGHT",
  "TSTAR", "TSWAP", "TLCBR", "TRCBR", "TLP", "TRP", "TLSBR", "TRSBR",
  "TNOELSE", "TUMINUS", "TUPLUS", "$accept", "program", "stmt_ls",
  "pragma_ls", "stmt", "assignment_stmt", "block_stmt", "opt_ident",
  "ident", "do_stmt", "return_stmt", "class_level_stmt", "loop_stmt",
  "if_stmt", "select_stmt", "when_stmt_ls", "when_stmt",
  "type_select_stmt", "class_decl_stmt", "opt_extern", "class_tag",
  "opt_inherit", "class_level_stmt_ls", "enum_decl_stmt", "enum_ls",
  "enum_item", "fn_decl_stmt", "@1", "@2", "extern_fn_decl_stmt",
  "fn_decl_stmt_inner", "fn_ident", "opt_formal_ls", "formal_ls", "formal",
  "opt_intent_tag", "opt_ret_tag", "function_body_stmt", "query_expr",
  "opt_query_expr", "var_arg_expr", "opt_where_part", "module_decl_stmt",
  "type_alias_decl_stmt", "type_alias_decl_stmt_inner", "opt_init_type",
  "var_decl_stmt", "opt_config", "var_decl_stmt_inner_ls",
  "var_decl_stmt_inner", "tuple_var_decl_stmt_inner_ls", "opt_init_expr",
  "opt_domain", "opt_type", "array_type", "opt_formal_array_elt_type",
  "formal_array_type", "opt_formal_type", "expr_ls", "tuple_expr_ls",
  "opt_actual_ls", "actual_ls", "actual_expr", "expr", "type_level_expr",
  "stmt_level_expr", "binary_op_expr", "unary_op_expr", "lhs_expr",
  "call_expr", "dot_expr", "parenthesized_expr", "literal_expr",
  "reduce_expr", "scan_expr", "reduce_scan_op_expr", 0
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[YYLEX-NUM] -- Internal token number corresponding to
   token YYLEX-NUM.  */
static const yytype_uint16 yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   310,   311,   312,   313,   314,
     315,   316,   317,   318,   319,   320,   321,   322,   323,   324,
     325,   326,   327,   328,   329,   330,   331,   332,   333,   334,
     335,   336,   337,   338,   339,   340,   341,   342,   343,   344,
     345,   346,   347,   348,   349,   350,   351,   352,   353,   354,
     355,   356,   357,   358,   359,   360,   361,   362,   363,   364,
     365,   366,   367,   368,   369,   370,   371,   372,   373
};
# endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const yytype_uint8 yyr1[] =
{
       0,   119,   120,   121,   121,   122,   122,   123,   123,   123,
     123,   123,   123,   123,   123,   123,   123,   123,   123,   123,
     123,   123,   123,   123,   123,   123,   123,   123,   123,   123,
     123,   124,   124,   124,   124,   124,   124,   124,   124,   124,
     124,   124,   124,   124,   124,   124,   125,   126,   126,   127,
     128,   128,   129,   129,   130,   130,   130,   130,   130,   130,
     131,   131,   131,   131,   131,   131,   131,   131,   131,   131,
     131,   132,   132,   132,   132,   133,   134,   134,   135,   135,
     136,   137,   138,   138,   139,   139,   139,   140,   140,   141,
     141,   142,   143,   143,   144,   144,   145,   146,   147,   145,
     148,   149,   149,   150,   150,   150,   150,   150,   150,   150,
     150,   150,   150,   150,   150,   150,   150,   150,   150,   150,
     150,   150,   150,   150,   150,   150,   150,   151,   151,   152,
     152,   152,   153,   153,   153,   153,   154,   154,   154,   154,
     154,   154,   154,   155,   155,   155,   155,   155,   156,   156,
     157,   157,   158,   158,   159,   159,   160,   160,   161,   162,
     163,   163,   164,   164,   165,   165,   165,   166,   166,   167,
     167,   168,   168,   168,   169,   169,   169,   169,   169,   169,
     170,   170,   171,   171,   172,   172,   172,   173,   173,   174,
     174,   174,   175,   175,   175,   176,   176,   176,   176,   176,
     176,   176,   177,   177,   177,   177,   178,   178,   178,   178,
     178,   178,   179,   179,   180,   180,   181,   181,   181,   181,
     181,   182,   182,   182,   182,   182,   182,   183,   183,   183,
     183,   183,   183,   183,   183,   183,   183,   183,   184,   184,
     184,   184,   184,   184,   184,   184,   184,   184,   184,   184,
     184,   184,   184,   184,   184,   184,   184,   184,   185,   185,
     185,   185,   185,   185,   185,   185,   185,   185,   185,   185,
     185,   185,   185,   185,   185,   185,   185,   185,   185,   185,
     186,   186,   186,   186,   186,   186,   187,   187,   187,   187,
     188,   188,   188,   189,   189,   189,   190,   191,   191,   191,
     191,   192,   192,   193,   193,   194,   194,   194,   194,   194,
     194,   194
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
static const yytype_uint8 yyr2[] =
{
       0,     2,     1,     0,     3,     0,     3,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     2,     2,     3,     2,
       3,     3,     2,     3,     2,     3,     3,     2,     3,     3,
       1,     4,     4,     4,     4,     4,     4,     4,     4,     4,
       4,     4,     4,     4,     4,     4,     3,     0,     1,     1,
       2,     1,     2,     3,     1,     1,     1,     1,     1,     1,
       5,     3,     5,     3,     5,     3,     6,     5,     3,     6,
       4,     4,     3,     6,     5,     5,     0,     2,     3,     2,
       6,     7,     0,     1,     1,     1,     1,     0,     2,     0,
       3,     6,     1,     3,     1,     3,     1,     0,     0,     8,
       5,     2,     4,     1,     2,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     0,     3,     0,
       1,     3,     4,     4,     6,     6,     0,     1,     1,     1,
       1,     1,     1,     0,     1,     1,     1,     1,     1,     1,
       2,     1,     0,     1,     2,     2,     0,     2,     5,     3,
       2,     4,     0,     2,     4,     4,     4,     0,     1,     1,
       3,     3,     4,     5,     0,     1,     3,     2,     3,     5,
       0,     2,     0,     4,     0,     2,     2,     4,     6,     0,
       1,     1,     3,     4,     6,     0,     2,     2,     2,     2,
       2,     2,     1,     1,     3,     3,     0,     1,     1,     2,
       3,     3,     0,     1,     1,     3,     3,     3,     3,     1,
       1,     1,     3,     6,     4,     9,     7,     1,     6,     4,
       9,     7,     6,     4,     9,     7,     6,     2,     1,     1,
       1,     1,     4,     4,     5,     4,     2,     2,     4,     1,
       4,     1,     1,     3,     3,     2,     2,     1,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       2,     2,     2,     2,     2,     2,     1,     1,     1,     1,
       4,     4,     4,     3,     3,     3,     3,     1,     1,     1,
       1,     3,     3,     3,     3,     1,     1,     1,     1,     1,
       1,     1
};

/* YYDEFACT[STATE-NAME] -- Default rule to reduce with in state
   STATE-NUM when YYTABLE doesn't specify something else to do.  Zero
   means the default is an error.  */
static const yytype_uint16 yydefact[] =
{
       3,     0,     5,     1,     0,    30,    49,   299,   297,   298,
     300,     0,     0,    47,     0,     0,   168,    47,    97,     0,
       0,     0,     0,    83,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   249,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     307,   309,     0,   310,   311,   257,     0,     0,   308,   305,
      54,   306,     3,   206,     0,     4,     7,     8,   286,    15,
       9,    12,    10,    13,    14,    56,     0,    57,    55,    96,
      11,    58,    59,     0,     0,   221,   227,   238,   241,   240,
     287,   288,   289,   239,   251,   252,     0,    16,    17,     0,
      48,    19,     0,     0,     0,     0,     0,     0,   227,   240,
       0,     0,     0,     0,   212,     0,     0,     0,     0,     0,
       0,   212,     0,   174,   184,     0,   169,    24,   282,     0,
     247,     0,   283,     6,   212,    52,     0,     0,     0,   246,
       0,   212,    27,   237,     0,   162,     0,   151,   203,     0,
     202,     0,     0,   285,   256,   281,   284,   280,     5,     0,
     208,     0,   207,     0,    84,    85,    86,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   255,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   212,   212,
      22,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,    18,     0,
       0,     0,     0,     0,     0,    51,    63,    20,   125,   105,
     106,   109,   107,   108,   119,   110,   123,   115,   113,   126,
     114,   112,   117,   122,   124,   111,   116,   120,   121,   118,
     103,    98,   127,    21,     0,   286,   219,     0,   213,   214,
     220,     0,   184,     0,     0,     0,    65,     0,     0,    68,
       0,    72,     0,    23,   174,   175,     0,     0,     0,   180,
       0,     0,     3,    25,     0,    53,    76,    26,   212,     0,
       0,     0,   160,   159,   150,     0,    28,    61,    29,    46,
       0,   209,   296,     0,     0,    87,     0,     0,     0,   277,
     279,   301,   303,   274,   271,   272,   273,   253,   261,   295,
     294,   293,   254,   265,   276,   270,   268,   278,   269,   267,
     259,   264,   266,   275,   258,   262,   263,   260,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   240,   302,   304,     0,     0,     0,
       0,     0,     0,   222,    50,     0,   104,     0,   143,   129,
     101,     0,     0,     0,   242,     0,    94,     0,    92,     0,
       0,     0,     0,   229,     0,     0,   233,     0,    71,     0,
       0,   245,     0,   177,   184,     0,   186,   221,     0,     0,
     171,   250,   170,     5,   292,     0,     0,   243,    76,   163,
       0,   205,   204,   248,   211,   210,     0,     0,    70,   224,
       0,     0,   165,   164,   166,   290,   291,    31,    38,    39,
      40,    35,    37,    41,    42,    33,    36,    34,    32,    44,
      43,    45,     0,     0,     0,     0,     0,     0,    62,   103,
     127,   144,   146,   147,   145,   184,   140,   137,   138,   139,
     141,   142,     0,   130,     0,    60,   218,   216,   217,   215,
       0,     0,     0,     0,   100,     0,     0,     0,    64,     0,
       0,    67,     0,     0,    74,   176,   174,   178,   180,     0,
     172,   181,   158,     0,     0,    75,    77,   244,     0,   161,
       0,     0,    88,    89,     0,     0,     0,     0,     0,     0,
     102,   156,   136,   128,   174,   195,    95,    93,    91,     0,
      66,     0,     0,   228,     0,     0,   232,    73,   236,     0,
     173,     0,   222,    79,     0,    80,     0,    69,   223,     0,
       5,     0,     0,     0,     0,     0,     0,     0,     0,   131,
       0,     0,   180,   222,   231,     0,   235,     0,   179,     0,
     187,    78,     0,   226,    81,    82,     0,     0,     0,   157,
     148,   149,    99,   195,   198,   199,   200,     0,   197,   201,
     221,   152,   133,   132,     0,     0,     0,     0,     0,    90,
       0,     0,     0,   180,   189,     0,   153,   155,   154,   230,
     234,   188,   225,   135,   134,   191,   192,   190,     0,   222,
       0,   193,   190,   189,   194,   190
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
      -1,     1,     2,     4,   388,    66,    67,    99,    68,   226,
      69,    70,    71,    72,    73,   405,   496,    74,    75,    76,
     167,   421,   540,    77,   377,   378,    78,   111,   368,    79,
     251,   252,   370,   462,   463,   464,   455,   572,   148,   597,
     582,   548,    80,    81,   146,   292,    82,    83,   125,   126,
     276,   400,   278,   279,   396,   606,   579,   552,   149,   161,
     257,   258,   259,    84,    85,   108,    87,    88,   109,    90,
      91,    92,    93,    94,    95,    96
};

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
#define YYPACT_NINF -597
static const yytype_int16 yypact[] =
{
    -597,    23,    31,  -597,   951,  -597,  -597,  -597,  -597,  -597,
    -597,  1063,  1063,    68,   -75,  2537,  -597,    68,  -597,  2537,
    1063,   -39,    68,    83,  2003,  2537,  2537,    33,    68,     2,
    1063,  2537,    68,  2537,  -597,  2537,  2537,   131,    40,  2092,
    2537,  2537,  2537,    97,    73,  1063,    80,  2181,  2537,  2537,
    -597,  -597,  2537,  -597,  -597,  3338,  2537,  2537,  -597,  2537,
    -597,  -597,  -597,  1914,  2181,  -597,  -597,  -597,  -597,  -597,
    -597,  -597,  -597,  -597,  -597,  -597,    85,  -597,  -597,  -597,
    -597,  -597,  -597,    93,  6798,  -597,   112,  -597,  -597,   366,
    -597,  -597,  -597,  -597,  -597,  -597,    32,  -597,  -597,   113,
    -597,  -597,  2537,  2537,  2537,  2537,  2181,  3689,  -597,  -597,
     116,  3375,  4853,   161,  2181,   115,  3375,    68,  3787,  3885,
    3947,  2181,  1063,     5,    81,    24,  -597,  -597,   312,   118,
     157,  4045,   312,  -597,  2181,  -597,  4915,  4977,  4045,  6798,
     122,  2181,  -597,  6798,  2181,   189,   162,    68,  -597,   155,
    6798,  4045,  5039,   210,  6922,   312,   210,   312,   167,  2537,
    -597,   -58,  6798,    18,  -597,  -597,  -597,    68,     2,     2,
       2,  2537,  2537,  2537,  2537,  2537,  2537,  2537,  2537,  2537,
    2537,    35,  3338,  2537,  2537,  2537,  2537,  2537,  2537,  2537,
    2537,  2537,  2537,  2537,  2537,  2537,  2537,  2537,  2181,  2181,
    -597,  2537,  2537,  2537,  2537,  2537,  2537,  2537,  2537,  2537,
    2537,  2537,  2537,  2537,  2537,  2537,  2537,  2537,  -597,  4143,
    4232,  5101,    21,  1063,  2537,  -597,  -597,  -597,  -597,  -597,
    -597,    68,  -597,  -597,  -597,  -597,  -597,  -597,  -597,  -597,
    -597,  -597,  -597,  -597,  -597,  -597,  -597,  -597,  -597,  -597,
     191,  -597,   156,  -597,  2537,   207,  -597,   174,   211,  -597,
    6798,    68,   205,   264,  1175,  2537,  -597,  1287,  2537,  -597,
    1063,   280,   192,  -597,     5,  -597,   -47,  2626,   239,   243,
    2537,     2,  -597,  -597,   193,  -597,  -597,  -597,  2181,   198,
     -43,  2537,   226,  -597,  -597,  2181,  -597,  -597,  -597,  -597,
    5163,  2181,  -597,  2537,   825,   228,   165,   176,   180,  6860,
     238,   238,   238,  6984,  3913,  7037,  7090,   157,   210,  -597,
    -597,  -597,  6922,  4349,   238,  6059,  6059,  6860,  6059,  6059,
     312,   210,  4349,   708,   312,  4263,  4263,   210,   201,   202,
    5225,  5287,  5349,  5411,  5473,  5535,  5597,  5659,  5721,  5783,
    5845,  5907,  5969,  6031,   215,   238,   238,  2715,  2537,  2804,
    2537,  2537,  2537,  2893,  -597,  4045,  -597,  3375,   204,    43,
    -597,  6093,  2537,  2181,  -597,  2181,   249,    26,  -597,  2982,
     224,  2537,  2537,  6798,  4321,  2537,  6798,  4419,   317,  6186,
    1063,  -597,    19,     9,   205,  2181,  -597,   229,  2537,  2537,
    -597,  6860,  -597,   230,  -597,   -25,   222,  -597,  -597,  6798,
      68,  -597,  6798,  -597,  -597,  6798,  3414,  2537,  -597,  6798,
    2181,   241,  -597,  -597,  -597,  -597,  -597,  -597,  -597,  -597,
    -597,  -597,  -597,  -597,  -597,  -597,  -597,  -597,  -597,  -597,
    -597,  -597,  2537,  6275,  2537,  6364,  3476,  2537,  -597,  -597,
     156,  -597,  -597,  -597,  -597,   205,  -597,  -597,  -597,  -597,
    -597,  -597,   120,  -597,    16,  -597,  6798,  -597,  6798,  -597,
    2537,    68,   250,  2181,  -597,  4045,  4481,  1399,  -597,  4543,
    1511,  -597,  1063,  2537,  -597,  -597,     5,  -597,   243,    27,
    6798,  6798,  -597,  1063,  2181,  -597,  -597,  -597,    37,  -597,
    1623,  4605,   268,  -597,  6426,  3071,  6488,  3160,  3249,  6550,
    -597,   300,   206,  -597,     5,   278,  6798,  -597,  -597,    39,
    -597,  1063,  2537,  6798,  1063,  2537,  6798,  -597,  6798,   127,
    -597,  2537,  2270,  -597,     8,  -597,  2537,  -597,  6798,  1063,
     253,  2537,  2537,  2537,  2537,  2537,  2537,  2537,   -34,  -597,
     130,  2359,   148,  2893,  6186,  4667,  6186,  4729,  -597,  3538,
    6798,  -597,  4791,  6186,  -597,    36,  6612,  6674,  6736,  6798,
    -597,  -597,  -597,   278,   -39,  2537,  2537,  1712,  -597,  -597,
     141,  2181,  -597,  -597,  1063,  1063,  3249,  1063,    68,  -597,
    2537,  2537,  2537,   148,  2181,   121,  -597,  -597,  6798,  6186,
    6186,  6798,  6186,  -597,  -597,  -597,  -597,  6798,  2537,  1825,
    3600,  -597,  6798,  2448,  -597,  6798
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -597,  -597,   -59,  -175,   288,  -597,   218,   355,   536,   -56,
    -173,  -192,  -597,  -597,  -597,   -32,  -597,  -597,  -597,  -597,
    -597,  -597,  -597,  -597,  -597,   -94,  -597,  -597,  -597,  -597,
     266,    20,   -65,  -597,  -126,  -597,  -597,  -597,     6,  -597,
    -205,  -597,  -597,  -597,   -21,  -597,  -597,  -597,   114,   109,
    -272,  -482,  -597,  -255,  -597,  -596,  -597,  -182,   -42,  -597,
     -76,  -597,    17,   -15,  -276,   199,  -597,  -597,   104,  -597,
    -597,  -597,  -597,  -597,  -597,  -597
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If zero, do what YYDEFACT says.
   If YYTABLE_NINF, syntax error.  */
#define YYTABLE_NINF -223
static const yytype_int16 yytable[] =
{
     107,   397,   392,   158,   112,     6,   530,   380,     6,   118,
     119,   120,     6,   611,    39,   493,   128,   614,   130,     6,
     131,   132,   163,     3,   136,   137,   138,   139,   301,   223,
     143,    -2,   150,   151,   152,    62,   494,   153,     6,   393,
     154,   155,   156,   295,   157,   272,  -136,   303,   162,   150,
     362,    16,  -167,   280,    18,   302,   531,   319,   284,   456,
      22,    23,   266,   269,   222,   289,   394,   408,   531,   160,
     583,     6,   457,   114,   458,   283,    62,   493,  -167,   216,
      37,   217,   287,     6,   459,   460,   495,   219,   220,   221,
     143,   150,   320,   588,   295,   297,  -167,   164,   494,   260,
     461,   116,   290,   397,   295,   393,   260,   295,    89,   168,
     281,   604,   471,   295,   123,    89,    89,   274,    62,   260,
     256,   486,   338,   339,    89,   295,   260,   256,   514,   150,
     144,   165,   485,   304,    89,   169,   363,   472,   133,   488,
     256,    60,   532,   166,   300,   121,  -182,   256,   535,    89,
     608,   140,   134,   170,   553,  -136,   309,   310,   311,   312,
     313,   314,   315,   316,   317,   318,   277,   322,   323,   324,
     325,   326,   327,   328,   329,   330,   331,   332,   333,   334,
     335,   336,   337,   260,   260,   141,   340,   341,   342,   343,
     344,   345,   346,   347,   348,   349,   350,   351,   352,   353,
     511,   355,   356,    86,   256,   256,   512,   295,  -196,   365,
      86,    86,   406,   393,   529,   399,   393,   200,   218,    86,
     451,   227,   456,   403,   254,   261,    89,  -196,   282,    86,
     172,  -196,   101,   513,   288,   457,   609,   458,   581,   371,
     558,   295,   550,   573,    86,   181,   452,   459,   460,   383,
     384,   281,   386,   387,  -196,   389,   291,   173,  -185,   174,
     296,   453,   281,   461,   454,   401,   281,   293,   369,   198,
     422,   199,   372,   260,   373,   580,   409,  -185,   299,   367,
     412,   423,   306,   307,   308,   424,   415,   374,   416,   419,
     379,  -185,    65,   381,   256,   179,  -185,   375,   181,    97,
      98,   411,   184,   390,   398,   391,   404,   414,   113,   448,
     399,   407,   410,   420,   425,  -185,   470,   426,   127,   354,
     441,    86,   198,   179,   199,   225,   181,    89,   478,   474,
     184,   481,   172,   142,  -185,   497,   225,   225,   271,  -185,
     482,   492,   383,   443,   386,   445,   389,   446,   419,   225,
     198,   503,   199,   489,   295,   518,   225,   466,   468,   173,
     260,   174,   547,   551,   564,   565,   475,   476,    89,   225,
     479,    89,   110,   589,    89,   571,   498,   517,   502,   467,
     150,   256,   262,   490,   491,   510,   549,   450,   603,   499,
     402,   593,   469,     0,     0,     0,     0,   179,     0,   180,
     181,     0,   501,     0,   184,   150,     0,     0,    89,     0,
     273,   191,     0,     0,     0,     0,     0,     0,     0,   520,
     197,     0,    86,     0,   198,     0,   199,   504,     0,   506,
       0,   519,   509,   201,   202,   203,   204,   205,   206,   207,
     208,   209,   210,   211,   212,   213,   214,     0,     0,     0,
       0,     0,   534,     0,     0,   516,     0,     0,   150,     0,
       0,     0,   523,    86,     0,   526,    86,     0,   528,    86,
       0,     0,     0,     0,     0,   215,     0,     0,   561,   150,
       0,     0,     0,     0,     0,   538,     0,     0,     0,     0,
     523,     0,   526,   538,    89,     0,     0,     0,     0,     0,
       0,     0,     0,    86,     0,     0,   554,   555,     0,   556,
     557,   364,     0,     0,     0,     0,   559,   560,     0,     0,
       0,   562,     0,     0,   563,     0,   554,   566,   556,   567,
     568,   563,   569,     0,     0,   595,     0,     0,   560,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   100,
       0,     0,   364,   100,     0,   364,     0,   578,   115,     0,
     139,   143,   150,     0,   122,   124,   598,     0,   129,   599,
     600,   601,   602,     0,     0,   599,   600,   602,     0,   607,
       0,    89,   145,   225,    89,     0,    89,   596,     0,    86,
       0,     0,   418,   610,   612,     0,     0,    89,   615,     0,
     605,     0,   225,     0,    89,   225,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   605,     0,     0,     0,   605,
       0,     0,     0,     0,     0,    89,     0,     0,    89,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    89,     0,     0,     0,   250,     0,     0,
     255,     0,   250,   263,     0,     0,     0,   255,     0,   275,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     255,     0,     0,     0,     0,     0,    86,   255,   484,    86,
       0,    86,     0,   294,     0,     0,     0,     0,    89,    89,
       0,    89,    86,   225,   271,     0,     0,   271,     0,    86,
       0,     0,     0,   305,   124,   124,   124,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   321,     0,   271,
      86,     0,     0,    86,     0,     0,     0,     0,   172,     0,
       0,     0,     0,     0,   255,   255,     0,     0,    86,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   225,     0,     0,   173,     0,   174,     0,     0,
       0,     0,     0,     0,     0,   364,   570,   366,   364,     0,
     527,     0,     0,   271,   175,   271,     0,     0,     0,     0,
     271,   533,     0,    86,    86,     0,    86,     0,   537,   176,
       0,   177,   178,   179,     0,   180,   181,   376,     0,   183,
     184,   185,   186,     0,   188,   189,   190,   191,     0,   192,
     275,   194,     0,     0,   195,   196,   197,   124,     0,     0,
     198,     0,   199,     0,   255,     0,     5,     0,     6,     7,
       8,     9,    10,    11,    12,    13,  -222,   -82,    14,    15,
      16,  -167,    17,    18,    19,  -222,    20,    21,  -222,    22,
      23,    24,    25,   417,     0,    27,     0,    28,    29,    30,
      31,    32,    33,    34,    35,     0,     0,  -167,    36,     0,
      38,   -82,  -222,    39,  -222,    40,    41,    42,    43,    44,
      45,     0,    46,   -82,    47,  -167,     0,     0,    48,    49,
       0,    50,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   449,     0,     0,    51,    52,    53,    54,
    -222,   255,  -222,  -222,    55,     0,  -222,  -222,  -222,  -222,
    -222,  -222,  -222,    56,  -222,    57,  -222,    58,    59,   487,
      60,  -222,  -222,    61,     0,    62,     0,    63,     0,    64,
       0,     0,     0,     0,     0,     0,   145,     0,     0,     0,
       0,     0,     5,     0,     6,     7,     8,     9,    10,    11,
      12,    13,     0,   -82,    14,    15,    16,  -167,    17,    18,
      19,     0,    20,    21,     0,    22,    23,    24,    25,    26,
       0,    27,     0,    28,    29,    30,    31,    32,    33,    34,
      35,     0,     0,  -167,    36,    37,    38,   -82,     0,    39,
     515,    40,    41,    42,    43,    44,    45,   376,    46,   -82,
      47,  -167,     0,     0,    48,    49,     0,    50,     0,     0,
       0,     0,   275,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    51,    52,    53,    54,     0,     0,     0,     0,
      55,     0,     0,     0,     0,     0,     0,     0,     0,    56,
     275,    57,     0,    58,    59,     0,    60,     0,     0,    61,
       0,    62,     0,    63,     5,    64,     6,     7,     8,     9,
      10,    11,    12,    13,     0,   -82,    14,    15,    16,  -167,
      17,    18,    19,     0,    20,    21,     0,    22,    23,    24,
      25,    26,     0,    27,     0,    28,    29,    30,    31,    32,
      33,    34,    35,     0,     0,  -167,    36,     0,    38,   -82,
       0,    39,     0,    40,    41,    42,    43,    44,    45,     0,
      46,   -82,    47,  -167,   145,     0,    48,    49,     0,    50,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    51,    52,    53,    54,     0,     0,
       0,     0,    55,     0,     0,     0,     0,     0,     0,     0,
       0,    56,     0,    57,     0,    58,    59,     0,    60,     0,
       0,    61,     0,    62,     0,    63,     5,    64,     6,     7,
       8,     9,    10,    11,    12,    13,     0,   -82,    14,    15,
      16,  -167,    17,    18,    19,     0,    20,    21,     0,    22,
      23,    24,    25,   382,     0,    27,     0,    28,    29,    30,
      31,    32,    33,    34,    35,     0,     0,  -167,    36,     0,
      38,   -82,     0,    39,     0,    40,    41,    42,    43,    44,
      45,     0,    46,   -82,    47,  -167,     0,     0,    48,    49,
       0,    50,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,    51,    52,    53,    54,
       0,     0,     0,     0,    55,     0,     0,     0,     0,     0,
       0,     0,     0,    56,     0,    57,     0,    58,    59,     0,
      60,     0,     0,    61,     0,    62,     0,    63,     5,    64,
       6,     7,     8,     9,    10,    11,    12,    13,     0,   -82,
      14,    15,    16,  -167,    17,    18,    19,     0,    20,    21,
       0,    22,    23,    24,    25,   385,     0,    27,     0,    28,
      29,    30,    31,    32,    33,    34,    35,     0,     0,  -167,
      36,     0,    38,   -82,     0,    39,     0,    40,    41,    42,
      43,    44,    45,     0,    46,   -82,    47,  -167,     0,     0,
      48,    49,     0,    50,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,    51,    52,
      53,    54,     0,     0,     0,     0,    55,     0,     0,     0,
       0,     0,     0,     0,     0,    56,     0,    57,     0,    58,
      59,     0,    60,     0,     0,    61,     0,    62,     0,    63,
       5,    64,     6,     7,     8,     9,    10,    11,    12,    13,
       0,   -82,    14,    15,    16,  -167,    17,    18,    19,     0,
      20,    21,     0,    22,    23,    24,    25,   522,     0,    27,
       0,    28,    29,    30,    31,    32,    33,    34,    35,     0,
       0,  -167,    36,     0,    38,   -82,     0,    39,     0,    40,
      41,    42,    43,    44,    45,     0,    46,   -82,    47,  -167,
       0,     0,    48,    49,     0,    50,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      51,    52,    53,    54,     0,     0,     0,     0,    55,     0,
       0,     0,     0,     0,     0,     0,     0,    56,     0,    57,
       0,    58,    59,     0,    60,     0,     0,    61,     0,    62,
       0,    63,     5,    64,     6,     7,     8,     9,    10,    11,
      12,    13,     0,   -82,    14,    15,    16,  -167,    17,    18,
      19,     0,    20,    21,     0,    22,    23,    24,    25,   525,
       0,    27,     0,    28,    29,    30,    31,    32,    33,    34,
      35,     0,     0,  -167,    36,     0,    38,   -82,     0,    39,
       0,    40,    41,    42,    43,    44,    45,     0,    46,   -82,
      47,  -167,     0,     0,    48,    49,     0,    50,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    51,    52,    53,    54,     0,     0,     0,     0,
      55,     0,     0,     0,     0,     0,     0,     0,     0,    56,
       0,    57,     0,    58,    59,     0,    60,     0,     0,    61,
       0,    62,     0,    63,     5,    64,     6,     7,     8,     9,
      10,    11,    12,    13,     0,   -82,    14,    15,    16,  -167,
      17,    18,    19,     0,    20,    21,     0,    22,    23,    24,
      25,   536,     0,    27,     0,    28,    29,    30,    31,    32,
      33,    34,    35,     0,     0,  -167,    36,     0,    38,   -82,
       0,    39,     0,    40,    41,    42,    43,    44,    45,     0,
      46,   -82,    47,  -167,     0,     0,    48,    49,     0,    50,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    51,    52,    53,    54,     0,     0,
       0,     0,    55,     0,     0,     6,     7,     8,     9,    10,
       0,    56,     0,    57,     0,    58,    59,     0,    60,     0,
       0,    61,     0,    62,    21,    63,     0,    64,   102,   103,
     104,     0,    27,     0,     0,    29,     0,    31,     0,    33,
      34,     0,     0,     0,     0,    36,     0,    38,     0,     0,
       0,     0,     0,     0,    42,    43,    44,   105,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,    50,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    51,    52,    53,    54,     0,     0,     0,
       0,    55,     0,     0,     0,     0,     0,     0,     0,     0,
      56,     0,    57,     0,    58,    59,   147,     0,     0,     0,
      61,     0,     0,     0,    63,     0,   106,   594,     6,     7,
       8,     9,    10,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    21,     0,     0,
       0,   102,   103,   447,     0,    27,     0,     0,    29,     0,
      31,     0,    33,    34,     0,     0,     0,     0,    36,     0,
      38,     0,     0,     0,     0,     0,     0,    42,    43,    44,
     105,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    50,  -189,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,    51,    52,    53,    54,
       0,  -189,     0,     0,    55,  -189,     0,     6,     7,     8,
       9,    10,     0,    56,     0,    57,     0,    58,    59,   147,
       0,     0,     0,    61,     0,     0,    21,    63,  -189,   106,
     102,   103,   104,     0,    27,     0,     0,    29,     0,    31,
       0,    33,    34,     0,     0,     0,     0,    36,     0,    38,
       0,     0,     0,     0,     0,     0,    42,    43,    44,   105,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      50,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    51,    52,    53,    54,     0,
       0,     0,     0,    55,   159,     0,     6,     7,     8,     9,
      10,     0,    56,     0,    57,     0,    58,    59,   147,     0,
       0,     0,    61,     0,     0,    21,    63,     0,   106,   102,
     103,   104,     0,    27,     0,     0,    29,     0,    31,     0,
      33,    34,     0,     0,     0,   117,    36,     0,    38,     0,
       0,     0,     0,     0,     0,    42,    43,    44,   105,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    50,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    51,    52,    53,    54,     0,     0,
       0,     0,    55,     0,     0,     6,     7,     8,     9,    10,
       0,    56,     0,    57,     0,    58,    59,     0,     0,     0,
       0,    61,     0,     0,    21,    63,     0,   106,   102,   103,
     104,     0,    27,     0,     0,    29,     0,    31,     0,    33,
      34,     0,     0,     0,     0,    36,     0,    38,     0,     0,
       0,     0,     0,     0,    42,    43,    44,   105,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,    50,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    51,    52,    53,    54,     0,     0,     0,
       0,    55,     0,     0,     6,     7,     8,     9,    10,     0,
      56,     0,    57,     0,    58,    59,     0,   135,     0,     0,
      61,     0,     0,    21,    63,     0,   106,   102,   103,   104,
       0,    27,     0,     0,    29,     0,    31,     0,    33,    34,
       0,     0,     0,     0,    36,     0,    38,     0,     0,     0,
       0,     0,     0,    42,    43,    44,   105,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    50,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    51,    52,    53,    54,     0,     0,     0,     0,
      55,     0,     0,     6,     7,     8,     9,    10,     0,    56,
       0,    57,     0,    58,    59,   147,     0,     0,     0,    61,
       0,     0,    21,    63,     0,   106,   102,   103,   447,     0,
      27,     0,     0,    29,     0,    31,     0,    33,    34,     0,
       0,     0,     0,    36,     0,    38,     0,     0,     0,     0,
       0,     0,    42,    43,    44,   105,     0,     0,     0,     0,
       0,     0,     0,     0,     0,  -183,    50,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    51,    52,    53,    54,     0,     0,     0,     0,    55,
       0,     0,     6,     7,     8,     9,    10,     0,    56,     0,
      57,     0,    58,    59,     0,     0,     0,     0,    61,     0,
       0,   574,    63,     0,   106,   102,   103,   104,     0,    27,
       0,     0,    29,     0,    31,     0,    33,    34,     0,     0,
       0,     0,    36,     0,    38,     0,     0,     0,     0,     0,
       0,   575,    43,    44,   576,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    50,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      51,    52,    53,    54,     0,     0,     0,     0,    55,     0,
       0,     6,     7,     8,     9,    10,     0,    56,     0,    57,
       0,    58,    59,   147,     0,     0,     0,    61,     0,     0,
      21,    63,     0,   577,   102,   103,   545,     0,    27,     0,
       0,    29,     0,    31,     0,    33,    34,     0,     0,     0,
       0,    36,     0,    38,     0,     0,     0,     0,     0,     0,
      42,    43,    44,   105,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    50,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    51,
      52,    53,    54,     0,     0,     0,     0,    55,     0,     0,
       6,     7,     8,     9,    10,     0,    56,     0,    57,     0,
      58,    59,   147,     0,     0,     0,    61,     0,     0,    21,
      63,     0,   106,   102,   103,   104,     0,    27,     0,     0,
      29,     0,    31,     0,    33,    34,     0,     0,     0,     0,
      36,     0,    38,     0,     0,     0,     0,     0,     0,    42,
      43,    44,   105,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    50,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,    51,    52,
      53,    54,     0,     0,     0,     0,    55,     0,     0,     6,
       7,     8,     9,    10,     0,    56,     0,    57,     0,    58,
      59,     0,     0,     0,     0,    61,     0,     0,    21,    63,
       0,   106,   102,   103,   104,     0,    27,     0,     0,    29,
       0,    31,     0,    33,    34,     0,     0,     0,     0,    36,
       0,    38,     0,     0,     0,     0,     0,     0,    42,    43,
      44,   105,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    50,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    51,    52,    53,
      54,     0,     0,     0,     0,    55,     0,     0,     6,     7,
       8,     9,    10,     0,    56,     0,    57,     0,    58,    59,
       0,     0,     0,     0,    61,     0,     0,    21,    63,     0,
     395,   102,   103,   442,     0,    27,     0,     0,    29,     0,
      31,     0,    33,    34,     0,     0,     0,     0,    36,     0,
      38,     0,     0,     0,     0,     0,     0,    42,    43,    44,
     105,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    50,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,    51,    52,    53,    54,
       0,     0,     0,     0,    55,     0,     0,     6,     7,     8,
       9,    10,     0,    56,     0,    57,     0,    58,    59,     0,
       0,     0,     0,    61,     0,     0,    21,    63,     0,   106,
     102,   103,   444,     0,    27,     0,     0,    29,     0,    31,
       0,    33,    34,     0,     0,     0,     0,    36,     0,    38,
       0,     0,     0,     0,     0,     0,    42,    43,    44,   105,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      50,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    51,    52,    53,    54,     0,
       0,     0,     0,    55,     0,     0,     6,     7,     8,     9,
      10,     0,    56,     0,    57,     0,    58,    59,     0,     0,
       0,     0,    61,     0,     0,    21,    63,     0,   106,   102,
     103,   447,     0,    27,     0,     0,    29,     0,    31,     0,
      33,    34,     0,     0,     0,     0,    36,     0,    38,     0,
       0,     0,     0,     0,     0,    42,    43,    44,   105,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    50,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    51,    52,    53,    54,     0,     0,
       0,     0,    55,     0,     0,     6,     7,     8,     9,    10,
       0,    56,     0,    57,     0,    58,    59,     0,     0,     0,
       0,    61,     0,     0,    21,    63,     0,   106,   102,   103,
     104,     0,    27,     0,     0,    29,     0,    31,     0,    33,
      34,     0,     0,     0,     0,    36,     0,    38,     0,     0,
       0,     0,     0,     0,    42,    43,    44,   105,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,    50,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    51,    52,    53,    54,     0,     0,     0,
       0,    55,     0,     0,     6,     7,     8,     9,    10,     0,
      56,     0,    57,     0,    58,    59,     0,     0,     0,     0,
      61,     0,     0,    21,    63,     0,   473,   102,   103,   542,
       0,    27,     0,     0,    29,     0,    31,     0,    33,    34,
       0,     0,     0,     0,    36,     0,    38,     0,     0,     0,
       0,     0,     0,    42,    43,    44,   105,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    50,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    51,    52,    53,    54,     0,     0,     0,     0,
      55,     0,     0,     6,     7,     8,     9,    10,     0,    56,
       0,    57,     0,    58,    59,     0,     0,     0,     0,    61,
       0,     0,    21,    63,     0,   106,   102,   103,   544,     0,
      27,     0,     0,    29,     0,    31,     0,    33,    34,     0,
       0,     0,     0,    36,     0,    38,     0,     0,     0,     0,
       0,     0,    42,    43,    44,   105,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,    50,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    51,    52,    53,    54,     0,     0,     0,     0,    55,
       0,     0,     6,     7,     8,     9,    10,     0,    56,     0,
      57,     0,    58,    59,     0,     0,     0,     0,    61,     0,
       0,    21,    63,     0,   106,   102,   103,   545,     0,    27,
       0,     0,    29,     0,    31,     0,    33,    34,     0,     0,
       0,     0,    36,     0,    38,     0,     0,     0,     0,     0,
       0,    42,    43,    44,   105,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    50,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      51,    52,    53,    54,     0,     0,     0,     0,    55,     0,
       0,     6,     7,     8,     9,    10,     0,    56,     0,    57,
       0,    58,    59,     0,     0,     0,     0,    61,     0,     0,
      21,    63,     0,   106,   102,   103,   104,     0,    27,     0,
       0,    29,     0,    31,     0,    33,    34,     0,     6,     0,
       0,    36,     0,    38,     0,     0,   228,     0,     0,     0,
      42,    43,    44,   105,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    50,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    51,
      52,    53,    54,     0,     0,   171,     0,     0,     0,     0,
       0,     0,     0,     0,   172,     0,    56,     0,    57,     0,
      58,    59,   229,     0,     0,     0,    61,     0,     0,     0,
      63,     0,   106,     0,     0,     0,   230,   231,   232,   233,
       0,   173,   234,   174,     0,     0,   235,   236,   237,   238,
     239,   240,   241,   242,   243,   244,   245,     0,   246,     0,
     175,   247,   248,   249,     0,     0,     0,   171,     0,     0,
       0,     0,     0,     0,     0,   176,   172,   177,   178,   179,
       0,   180,   181,   182,     0,   183,   184,   185,   186,   187,
     188,   189,   190,   191,     0,   192,   193,   194,     0,     0,
     195,   196,   197,   173,     0,   174,   198,     0,   199,   500,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   175,     0,     0,     0,     0,     0,     0,   171,
       0,     0,     0,     0,     0,     0,     0,   176,   172,   177,
     178,   179,     0,   180,   181,   182,     0,   183,   184,   185,
     186,   187,   188,   189,   190,   191,     0,   192,   193,   194,
       0,     0,   195,   196,   197,   173,     0,   174,   198,     0,
     199,   508,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   175,     0,     0,     0,     0,     0,
       0,   171,     0,     0,     0,     0,     0,     0,     0,   176,
     172,   177,   178,   179,     0,   180,   181,   182,     0,   183,
     184,   185,   186,   187,   188,   189,   190,   191,     0,   192,
     193,   194,     0,     0,   195,   196,   197,   173,     0,   174,
     198,     0,   199,   586,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   175,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   176,     0,   177,   178,   179,     0,   180,   181,   182,
       0,   183,   184,   185,   186,   187,   188,   189,   190,   191,
     171,   192,   193,   194,     0,     0,   195,   196,   197,   172,
     223,     0,   198,     0,   199,   613,     0,     0,   224,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   173,     0,   174,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   175,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     176,     0,   177,   178,   179,     0,   180,   181,   182,     0,
     183,   184,   185,   186,   187,   188,   189,   190,   191,     0,
     192,   193,   194,     0,     0,   195,   196,   197,   171,    62,
       0,   198,     0,   199,     0,     0,     0,   172,   264,     0,
       0,     0,     0,     0,     0,     0,   265,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   173,     0,   174,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   175,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   176,     0,
     177,   178,   179,     0,   180,   181,   182,     0,   183,   184,
     185,   186,   187,   188,   189,   190,   191,     0,   192,   193,
     194,     0,     0,   195,   196,   197,   171,    62,     0,   198,
       0,   199,     0,     0,     0,   172,   267,     0,     0,     0,
       0,     0,     0,     0,   268,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   173,   172,   174,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   175,     0,     0,     0,     0,     0,     0,   171,     0,
     173,     0,   174,     0,     0,     0,   176,   172,   177,   178,
     179,     0,   180,   181,   182,     0,   183,   184,   185,   186,
     187,   188,   189,   190,   191,     0,   192,   193,   194,     0,
       0,   195,   196,   197,   173,    62,   174,   198,   179,   199,
     180,   181,     0,   270,   183,   184,   185,   186,     0,   188,
     189,   190,   191,   175,   192,     0,   194,     0,     0,   195,
     196,   197,     0,     0,     0,   198,     0,   199,   176,     0,
     177,   178,   179,     0,   180,   181,   182,     0,   183,   184,
     185,   186,   187,   188,   189,   190,   191,     0,   192,   193,
     194,     0,     0,   195,   196,   197,   171,    62,     0,   198,
       0,   199,     0,     0,     0,   172,   223,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   173,     0,   174,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   175,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   176,     0,   177,   178,
     179,     0,   180,   181,   182,     0,   183,   184,   185,   186,
     187,   188,   189,   190,   191,     0,   192,   193,   194,     0,
       0,   195,   196,   197,   171,    62,     0,   198,     0,   199,
       0,     0,     0,   172,   357,     0,     0,     0,     0,     0,
       0,     0,   358,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     173,     0,   174,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   175,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   176,     0,   177,   178,   179,     0,
     180,   181,   182,     0,   183,   184,   185,   186,   187,   188,
     189,   190,   191,   171,   192,   193,   194,     0,     0,   195,
     196,   197,   172,   359,     0,   198,     0,   199,     0,     0,
       0,   360,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   173,
       0,   174,     0,   172,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   175,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     173,     0,   174,   176,     0,   177,   178,   179,     0,   180,
     181,   182,     0,   183,   184,   185,   186,   187,   188,   189,
     190,   191,   171,   192,   193,   194,     0,     0,   195,   196,
     197,   172,   477,     0,   198,     0,   199,     0,   179,     0,
     180,   181,     0,     0,     0,   184,     0,     0,     0,     0,
       0,   190,   191,     0,     0,     0,   194,     0,   173,   172,
     174,   197,     0,     0,     0,   198,     0,   199,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   175,     0,     0,
       0,     0,     0,     0,     0,     0,   173,     0,   174,     0,
       0,     0,   176,     0,   177,   178,   179,     0,   180,   181,
     182,     0,   183,   184,   185,   186,   187,   188,   189,   190,
     191,     0,   192,   193,   194,     0,     0,   195,   196,   197,
     171,    62,     0,   198,   179,   199,   180,   181,     0,   172,
     480,   184,   185,   186,     0,   188,   189,   190,   191,     0,
       0,     0,   194,     0,     0,   195,   196,   197,     0,     0,
       0,   198,     0,   199,     0,     0,   173,     0,   174,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   175,     0,     0,     0,     0,
       0,     0,   171,     0,     0,     0,     0,     0,     0,     0,
     176,   172,   177,   178,   179,     0,   180,   181,   182,     0,
     183,   184,   185,   186,   187,   188,   189,   190,   191,     0,
     192,   193,   194,     0,     0,   195,   196,   197,   173,    62,
     174,   198,     0,   199,     0,     0,     0,   521,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   175,     0,     0,
       0,     0,     0,     0,   171,     0,     0,     0,     0,     0,
       0,     0,   176,   172,   177,   178,   179,     0,   180,   181,
     182,     0,   183,   184,   185,   186,   187,   188,   189,   190,
     191,     0,   192,   193,   194,     0,     0,   195,   196,   197,
     173,    62,   174,   198,     0,   199,     0,     0,     0,   524,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   175,
       0,     0,     0,     0,     0,     0,   171,     0,     0,     0,
       0,     0,     0,     0,   176,   172,   177,   178,   179,     0,
     180,   181,   182,     0,   183,   184,   185,   186,   187,   188,
     189,   190,   191,     0,   192,   193,   194,     0,     0,   195,
     196,   197,   173,    62,   174,   198,     0,   199,     0,     0,
       0,   539,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   175,     0,     0,     0,     0,     0,     0,   171,     0,
       0,     0,     0,     0,     0,     0,   176,   172,   177,   178,
     179,     0,   180,   181,   182,     0,   183,   184,   185,   186,
     187,   188,   189,   190,   191,     0,   192,   193,   194,     0,
       0,   195,   196,   197,   173,    62,   174,   198,     0,   199,
       0,     0,     0,   584,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   175,     0,     0,     0,     0,     0,     0,
     171,     0,     0,     0,     0,     0,     0,     0,   176,   172,
     177,   178,   179,     0,   180,   181,   182,     0,   183,   184,
     185,   186,   187,   188,   189,   190,   191,     0,   192,   193,
     194,     0,     0,   195,   196,   197,   173,    62,   174,   198,
       0,   199,     0,     0,     0,   585,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   175,     0,     0,     0,     0,
       0,     0,   171,     0,     0,     0,     0,     0,     0,     0,
     176,   172,   177,   178,   179,     0,   180,   181,   182,     0,
     183,   184,   185,   186,   187,   188,   189,   190,   191,     0,
     192,   193,   194,     0,     0,   195,   196,   197,   173,    62,
     174,   198,     0,   199,     0,     0,     0,   587,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   175,     0,     0,
       0,     0,     0,     0,   171,     0,     0,     0,     0,     0,
       0,     0,   176,   172,   177,   178,   179,     0,   180,   181,
     182,     0,   183,   184,   185,   186,   187,   188,   189,   190,
     191,     0,   192,   193,   194,     0,     0,   195,   196,   197,
     173,    62,   174,   198,     0,   199,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   175,
       0,     0,     0,     0,     0,     0,   171,     0,     0,     0,
       0,     0,     0,     0,   176,   172,   177,   178,   179,     0,
     180,   181,   182,     0,   183,   184,   185,   186,   187,   188,
     189,   190,   191,     0,   192,   193,   194,     0,   253,   195,
     196,   197,   173,     0,   174,   198,     0,   199,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   175,     0,     0,     0,     0,     0,     0,   171,     0,
       0,     0,     0,     0,     0,     0,   176,   172,   177,   178,
     179,     0,   180,   181,   182,     0,   183,   184,   185,   186,
     187,   188,   189,   190,   191,     0,   192,   193,   194,     0,
     285,   195,   196,   197,   173,     0,   174,   198,     0,   199,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   175,     0,     0,     0,     0,     0,     0,
     171,     0,     0,     0,     0,     0,     0,     0,   176,   172,
     177,   178,   179,     0,   180,   181,   182,     0,   183,   184,
     185,   186,   187,   188,   189,   190,   191,     0,   192,   193,
     194,     0,     0,   195,   196,   197,   173,   286,   174,   198,
       0,   199,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   175,     0,     0,     0,     0,
       0,     0,   171,     0,     0,     0,     0,     0,     0,     0,
     176,   172,   177,   178,   179,     0,   180,   181,   182,     0,
     183,   184,   185,   186,   187,   188,   189,   190,   191,     0,
     192,   193,   194,     0,   298,   195,   196,   197,   173,     0,
     174,   198,     0,   199,     0,     0,     0,   361,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   175,     0,     0,
       0,     0,     0,     0,   171,     0,     0,     0,     0,     0,
       0,     0,   176,   172,   177,   178,   179,     0,   180,   181,
     182,     0,   183,   184,   185,   186,   187,   188,   189,   190,
     191,     0,   192,   193,   194,     0,     0,   195,   196,   197,
     173,     0,   174,   198,     0,   199,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   175,
       0,     0,     0,     0,     0,     0,   171,     0,     0,     0,
       0,     0,     0,     0,   176,   172,   177,   178,   179,     0,
     180,   181,   182,     0,   183,   184,   185,   186,   187,   188,
     189,   190,   191,     0,   192,   193,   194,     0,     0,   195,
     196,   197,   173,     0,   174,   198,   413,   199,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   175,     0,     0,     0,     0,     0,     0,   171,     0,
       0,     0,     0,     0,     0,     0,   176,   172,   177,   178,
     179,     0,   180,   181,   182,     0,   183,   184,   185,   186,
     187,   188,   189,   190,   191,     0,   192,   193,   194,     0,
     427,   195,   196,   197,   173,     0,   174,   198,     0,   199,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   175,     0,     0,     0,     0,     0,     0,
     171,     0,     0,     0,     0,     0,     0,     0,   176,   172,
     177,   178,   179,     0,   180,   181,   182,     0,   183,   184,
     185,   186,   187,   188,   189,   190,   191,     0,   192,   193,
     194,     0,   428,   195,   196,   197,   173,     0,   174,   198,
       0,   199,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   175,     0,     0,     0,     0,
       0,     0,   171,     0,     0,     0,     0,     0,     0,     0,
     176,   172,   177,   178,   179,     0,   180,   181,   182,     0,
     183,   184,   185,   186,   187,   188,   189,   190,   191,     0,
     192,   193,   194,     0,   429,   195,   196,   197,   173,     0,
     174,   198,     0,   199,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   175,     0,     0,
       0,     0,     0,     0,   171,     0,     0,     0,     0,     0,
       0,     0,   176,   172,   177,   178,   179,     0,   180,   181,
     182,     0,   183,   184,   185,   186,   187,   188,   189,   190,
     191,     0,   192,   193,   194,     0,   430,   195,   196,   197,
     173,     0,   174,   198,     0,   199,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   175,
       0,     0,     0,     0,     0,     0,   171,     0,     0,     0,
       0,     0,     0,     0,   176,   172,   177,   178,   179,     0,
     180,   181,   182,     0,   183,   184,   185,   186,   187,   188,
     189,   190,   191,     0,   192,   193,   194,     0,   431,   195,
     196,   197,   173,     0,   174,   198,     0,   199,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   175,     0,     0,     0,     0,     0,     0,   171,     0,
       0,     0,     0,     0,     0,     0,   176,   172,   177,   178,
     179,     0,   180,   181,   182,     0,   183,   184,   185,   186,
     187,   188,   189,   190,   191,     0,   192,   193,   194,     0,
     432,   195,   196,   197,   173,     0,   174,   198,     0,   199,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   175,     0,     0,     0,     0,     0,     0,
     171,     0,     0,     0,     0,     0,     0,     0,   176,   172,
     177,   178,   179,     0,   180,   181,   182,     0,   183,   184,
     185,   186,   187,   188,   189,   190,   191,     0,   192,   193,
     194,     0,   433,   195,   196,   197,   173,     0,   174,   198,
       0,   199,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   175,     0,     0,     0,     0,
       0,     0,   171,     0,     0,     0,     0,     0,     0,     0,
     176,   172,   177,   178,   179,     0,   180,   181,   182,     0,
     183,   184,   185,   186,   187,   188,   189,   190,   191,     0,
     192,   193,   194,     0,   434,   195,   196,   197,   173,     0,
     174,   198,     0,   199,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   175,     0,     0,
       0,     0,     0,     0,   171,     0,     0,     0,     0,     0,
       0,     0,   176,   172,   177,   178,   179,     0,   180,   181,
     182,     0,   183,   184,   185,   186,   187,   188,   189,   190,
     191,     0,   192,   193,   194,     0,   435,   195,   196,   197,
     173,     0,   174,   198,     0,   199,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   175,
       0,     0,     0,     0,     0,     0,   171,     0,     0,     0,
       0,     0,     0,     0,   176,   172,   177,   178,   179,     0,
     180,   181,   182,     0,   183,   184,   185,   186,   187,   188,
     189,   190,   191,     0,   192,   193,   194,     0,   436,   195,
     196,   197,   173,     0,   174,   198,     0,   199,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   175,     0,     0,     0,     0,     0,     0,   171,     0,
       0,     0,     0,     0,     0,     0,   176,   172,   177,   178,
     179,     0,   180,   181,   182,     0,   183,   184,   185,   186,
     187,   188,   189,   190,   191,     0,   192,   193,   194,     0,
     437,   195,   196,   197,   173,     0,   174,   198,     0,   199,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   175,     0,     0,     0,     0,     0,     0,
     171,     0,     0,     0,     0,     0,     0,     0,   176,   172,
     177,   178,   179,     0,   180,   181,   182,     0,   183,   184,
     185,   186,   187,   188,   189,   190,   191,     0,   192,   193,
     194,     0,   438,   195,   196,   197,   173,     0,   174,   198,
       0,   199,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   175,     0,     0,     0,     0,
       0,     0,   171,     0,     0,     0,     0,     0,     0,     0,
     176,   172,   177,   178,   179,     0,   180,   181,   182,     0,
     183,   184,   185,   186,   187,   188,   189,   190,   191,     0,
     192,   193,   194,     0,   439,   195,   196,   197,   173,   172,
     174,   198,     0,   199,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   175,     0,     0,
       0,     0,     0,     0,   171,     0,   173,     0,   174,     0,
       0,     0,   176,   172,   177,   178,   179,     0,   180,   181,
     182,     0,   183,   184,   185,   186,   187,   188,   189,   190,
     191,     0,   192,   193,   194,     0,   440,   195,   196,   197,
     173,     0,   174,   198,   179,   199,   180,   181,     0,     0,
       0,   184,     0,     0,     0,     0,     0,   190,   191,   175,
       0,     0,   194,     0,     0,   195,   196,   197,     0,     0,
       0,   198,     0,   199,   176,     0,   177,   178,   179,     0,
     180,   181,   182,     0,   183,   184,   185,   186,   187,   188,
     189,   190,   191,     0,   192,   193,   194,   171,   465,   195,
     196,   197,     0,     0,     0,   198,   172,   199,     0,   483,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   173,     0,   174,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   175,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   176,     0,   177,
     178,   179,     0,   180,   181,   182,     0,   183,   184,   185,
     186,   187,   188,   189,   190,   191,   171,   192,   193,   194,
       0,     0,   195,   196,   197,   172,   505,     0,   198,     0,
     199,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   173,     0,   174,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   175,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   176,     0,   177,   178,
     179,     0,   180,   181,   182,     0,   183,   184,   185,   186,
     187,   188,   189,   190,   191,   171,   192,   193,   194,     0,
       0,   195,   196,   197,   172,   507,     0,   198,     0,   199,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   173,     0,   174,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     175,     0,     0,     0,     0,     0,     0,   171,     0,     0,
       0,     0,     0,     0,     0,   176,   172,   177,   178,   179,
       0,   180,   181,   182,     0,   183,   184,   185,   186,   187,
     188,   189,   190,   191,     0,   192,   193,   194,     0,     0,
     195,   196,   197,   173,     0,   174,   198,     0,   199,     0,
       0,     0,   541,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   175,     0,     0,     0,     0,     0,     0,   171,
       0,     0,     0,     0,     0,     0,     0,   176,   172,   177,
     178,   179,     0,   180,   181,   182,     0,   183,   184,   185,
     186,   187,   188,   189,   190,   191,     0,   192,   193,   194,
       0,     0,   195,   196,   197,   173,     0,   174,   198,     0,
     199,     0,     0,     0,   543,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   175,     0,     0,     0,     0,     0,
       0,   171,     0,     0,     0,     0,     0,     0,     0,   176,
     172,   177,   178,   179,     0,   180,   181,   182,     0,   183,
     184,   185,   186,   187,   188,   189,   190,   191,     0,   192,
     193,   194,     0,     0,   195,   196,   197,   173,     0,   174,
     198,     0,   199,     0,     0,     0,   546,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   175,     0,     0,     0,
       0,     0,     0,   171,     0,     0,     0,     0,     0,     0,
       0,   176,   172,   177,   178,   179,     0,   180,   181,   182,
       0,   183,   184,   185,   186,   187,   188,   189,   190,   191,
       0,   192,   193,   194,     0,     0,   195,   196,   197,   173,
       0,   174,   198,     0,   199,     0,     0,     0,   590,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   175,     0,
       0,     0,     0,     0,     0,   171,     0,     0,     0,     0,
       0,     0,     0,   176,   172,   177,   178,   179,     0,   180,
     181,   182,     0,   183,   184,   185,   186,   187,   188,   189,
     190,   191,     0,   192,   193,   194,     0,     0,   195,   196,
     197,   173,     0,   174,   198,     0,   199,     0,     0,     0,
     591,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     175,     0,     0,     0,     0,     0,     0,   171,     0,     0,
       0,     0,     0,     0,     0,   176,   172,   177,   178,   179,
       0,   180,   181,   182,     0,   183,   184,   185,   186,   187,
     188,   189,   190,   191,     0,   192,   193,   194,     0,     0,
     195,   196,   197,   173,     0,   174,   198,     0,   199,     0,
       0,     0,   592,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   175,     0,     0,     0,     0,     0,     0,   171,
       0,     0,     0,     0,     0,     0,     0,   176,   172,   177,
     178,   179,     0,   180,   181,   182,     0,   183,   184,   185,
     186,   187,   188,   189,   190,   191,     0,   192,   193,   194,
       0,     0,   195,   196,   197,   173,     0,   174,   198,     0,
     199,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   175,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   176,
     172,   177,   178,   179,     0,   180,   181,   182,     0,   183,
     184,   185,   186,   187,   188,   189,   190,   191,     0,   192,
     193,   194,     0,     0,   195,   196,   197,   173,     0,   174,
     198,     0,   199,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   175,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   176,   172,   177,   178,   179,     0,   180,   181,   182,
       0,   183,   184,   185,   186,     0,   188,   189,   190,   191,
       0,   192,   193,   194,     0,     0,   195,   196,   197,   173,
       0,   174,   198,     0,   199,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   175,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   176,   172,   177,   178,   179,     0,   180,
     181,     0,     0,   183,   184,   185,   186,     0,   188,   189,
     190,   191,     0,   192,   193,   194,     0,     0,   195,   196,
     197,   173,     0,   174,   198,     0,   199,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   172,     0,     0,
       0,     0,     0,     0,     0,   176,     0,   177,   178,   179,
       0,   180,   181,     0,     0,   183,   184,   185,   186,     0,
     188,   189,   190,   191,   173,   192,   174,   194,     0,     0,
     195,   196,   197,     0,     0,     0,   198,     0,   199,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     172,     0,     0,     0,     0,     0,     0,     0,   176,     0,
       0,   178,   179,     0,   180,   181,     0,     0,   183,   184,
     185,   186,     0,   188,   189,   190,   191,   173,   192,   174,
     194,     0,     0,   195,   196,   197,     0,     0,     0,   198,
       0,   199,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   176,     0,     0,     0,   179,     0,   180,   181,     0,
       0,   183,   184,   185,   186,     0,   188,   189,   190,   191,
       0,   192,     0,   194,     0,     0,   195,   196,   197,     0,
       0,     0,   198,     0,   199
};

static const yytype_int16 yycheck[] =
{
      15,   277,   274,    62,    19,     3,   488,   262,     3,    24,
      25,    26,     3,   609,    48,    40,    31,   613,    33,     3,
      35,    36,    64,     0,    39,    40,    41,    42,    86,    21,
      45,     0,    47,    48,    49,   110,    61,    52,     3,    86,
      55,    56,    57,    86,    59,   121,     3,    29,    63,    64,
      29,    15,    16,    29,    18,   113,    29,    22,   134,    16,
      24,    25,   118,   119,   106,   141,   113,   110,    29,    63,
     552,     3,    29,   112,    31,   131,   110,    40,    42,    47,
      44,    49,   138,     3,    41,    42,   111,   102,   103,   104,
     105,   106,    57,    57,    86,   151,    60,    12,    61,   114,
      57,    18,   144,   379,    86,    86,   121,    86,     4,    16,
      86,   593,    86,    86,   112,    11,    12,   112,   110,   134,
     114,   112,   198,   199,    20,    86,   141,   121,   112,   144,
      50,    46,   113,   115,    30,    42,   115,   111,     7,   394,
     134,   105,   115,    58,   159,   112,    65,   141,   111,    45,
      29,    54,   112,    60,   115,   112,   171,   172,   173,   174,
     175,   176,   177,   178,   179,   180,    85,   182,   183,   184,
     185,   186,   187,   188,   189,   190,   191,   192,   193,   194,
     195,   196,   197,   198,   199,   112,   201,   202,   203,   204,
     205,   206,   207,   208,   209,   210,   211,   212,   213,   214,
     455,   216,   217,     4,   198,   199,    86,    86,    67,   224,
      11,    12,   288,    86,   486,    67,    86,   105,   105,    20,
      16,   105,    16,   282,    63,   110,   122,    86,   110,    30,
      20,    90,    14,   113,   112,    29,   115,    31,    90,   254,
     113,    86,   514,   113,    45,    88,    42,    41,    42,   264,
     265,    86,   267,   268,   113,   270,    67,    47,    29,    49,
     105,    57,    86,    57,    60,   280,    86,   105,   112,   112,
     105,   114,    65,   288,    67,   551,   291,    48,   111,    88,
     295,   105,   168,   169,   170,   105,   301,   113,   303,   304,
      85,    62,     4,    29,   288,    85,    67,    86,    88,    11,
      12,   295,    92,    23,    65,   113,   113,   301,    20,   365,
      67,   113,    86,    85,   113,    86,    67,   115,    30,   215,
     105,   122,   112,    85,   114,   107,    88,   223,   384,   105,
      92,   387,    20,    45,   105,   113,   118,   119,   120,   110,
      23,   111,   357,   358,   359,   360,   361,   362,   363,   131,
     112,   110,   114,   395,    86,   105,   138,   372,   373,    47,
     375,    49,    62,    85,   111,   540,   381,   382,   264,   151,
     385,   267,    17,   565,   270,   548,   408,   471,   420,   373,
     395,   375,   116,   398,   399,   450,   512,   367,   593,   410,
     281,   573,   375,    -1,    -1,    -1,    -1,    85,    -1,    87,
      88,    -1,   417,    -1,    92,   420,    -1,    -1,   304,    -1,
     122,    99,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   475,
     108,    -1,   223,    -1,   112,    -1,   114,   442,    -1,   444,
      -1,   473,   447,    67,    68,    69,    70,    71,    72,    73,
      74,    75,    76,    77,    78,    79,    80,    -1,    -1,    -1,
      -1,    -1,   494,    -1,    -1,   470,    -1,    -1,   473,    -1,
      -1,    -1,   477,   264,    -1,   480,   267,    -1,   483,   270,
      -1,    -1,    -1,    -1,    -1,   109,    -1,    -1,   534,   494,
      -1,    -1,    -1,    -1,    -1,   500,    -1,    -1,    -1,    -1,
     505,    -1,   507,   508,   390,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   304,    -1,    -1,   521,   522,    -1,   524,
     525,   223,    -1,    -1,    -1,    -1,   531,   532,    -1,    -1,
      -1,   536,    -1,    -1,   539,    -1,   541,   542,   543,   544,
     545,   546,   547,    -1,    -1,   577,    -1,    -1,   553,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    13,
      -1,    -1,   264,    17,    -1,   267,    -1,   551,    22,    -1,
     575,   576,   577,    -1,    28,    29,   581,    -1,    32,   584,
     585,   586,   587,    -1,    -1,   590,   591,   592,    -1,   594,
      -1,   477,    46,   365,   480,    -1,   482,   581,    -1,   390,
      -1,    -1,   304,   608,   609,    -1,    -1,   493,   613,    -1,
     594,    -1,   384,    -1,   500,   387,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   609,    -1,    -1,    -1,   613,
      -1,    -1,    -1,    -1,    -1,   521,    -1,    -1,   524,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   539,    -1,    -1,    -1,   111,    -1,    -1,
     114,    -1,   116,   117,    -1,    -1,    -1,   121,    -1,   123,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     134,    -1,    -1,    -1,    -1,    -1,   477,   141,   390,   480,
      -1,   482,    -1,   147,    -1,    -1,    -1,    -1,   584,   585,
      -1,   587,   493,   475,   476,    -1,    -1,   479,    -1,   500,
      -1,    -1,    -1,   167,   168,   169,   170,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   181,    -1,   501,
     521,    -1,    -1,   524,    -1,    -1,    -1,    -1,    20,    -1,
      -1,    -1,    -1,    -1,   198,   199,    -1,    -1,   539,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   534,    -1,    -1,    47,    -1,    49,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   477,   548,   231,   480,    -1,
     482,    -1,    -1,   555,    66,   557,    -1,    -1,    -1,    -1,
     562,   493,    -1,   584,   585,    -1,   587,    -1,   500,    81,
      -1,    83,    84,    85,    -1,    87,    88,   261,    -1,    91,
      92,    93,    94,    -1,    96,    97,    98,    99,    -1,   101,
     274,   103,    -1,    -1,   106,   107,   108,   281,    -1,    -1,
     112,    -1,   114,    -1,   288,    -1,     1,    -1,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    -1,    30,    -1,    32,    33,    34,
      35,    36,    37,    38,    39,    -1,    -1,    42,    43,    -1,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    -1,    57,    58,    59,    60,    -1,    -1,    63,    64,
      -1,    66,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   367,    -1,    -1,    81,    82,    83,    84,
      85,   375,    87,    88,    89,    -1,    91,    92,    93,    94,
      95,    96,    97,    98,    99,   100,   101,   102,   103,   393,
     105,   106,   107,   108,    -1,   110,    -1,   112,    -1,   114,
      -1,    -1,    -1,    -1,    -1,    -1,   410,    -1,    -1,    -1,
      -1,    -1,     1,    -1,     3,     4,     5,     6,     7,     8,
       9,    10,    -1,    12,    13,    14,    15,    16,    17,    18,
      19,    -1,    21,    22,    -1,    24,    25,    26,    27,    28,
      -1,    30,    -1,    32,    33,    34,    35,    36,    37,    38,
      39,    -1,    -1,    42,    43,    44,    45,    46,    -1,    48,
     464,    50,    51,    52,    53,    54,    55,   471,    57,    58,
      59,    60,    -1,    -1,    63,    64,    -1,    66,    -1,    -1,
      -1,    -1,   486,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    81,    82,    83,    84,    -1,    -1,    -1,    -1,
      89,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    98,
     514,   100,    -1,   102,   103,    -1,   105,    -1,    -1,   108,
      -1,   110,    -1,   112,     1,   114,     3,     4,     5,     6,
       7,     8,     9,    10,    -1,    12,    13,    14,    15,    16,
      17,    18,    19,    -1,    21,    22,    -1,    24,    25,    26,
      27,    28,    -1,    30,    -1,    32,    33,    34,    35,    36,
      37,    38,    39,    -1,    -1,    42,    43,    -1,    45,    46,
      -1,    48,    -1,    50,    51,    52,    53,    54,    55,    -1,
      57,    58,    59,    60,   588,    -1,    63,    64,    -1,    66,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    81,    82,    83,    84,    -1,    -1,
      -1,    -1,    89,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    98,    -1,   100,    -1,   102,   103,    -1,   105,    -1,
      -1,   108,    -1,   110,    -1,   112,     1,   114,     3,     4,
       5,     6,     7,     8,     9,    10,    -1,    12,    13,    14,
      15,    16,    17,    18,    19,    -1,    21,    22,    -1,    24,
      25,    26,    27,    28,    -1,    30,    -1,    32,    33,    34,
      35,    36,    37,    38,    39,    -1,    -1,    42,    43,    -1,
      45,    46,    -1,    48,    -1,    50,    51,    52,    53,    54,
      55,    -1,    57,    58,    59,    60,    -1,    -1,    63,    64,
      -1,    66,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    81,    82,    83,    84,
      -1,    -1,    -1,    -1,    89,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    98,    -1,   100,    -1,   102,   103,    -1,
     105,    -1,    -1,   108,    -1,   110,    -1,   112,     1,   114,
       3,     4,     5,     6,     7,     8,     9,    10,    -1,    12,
      13,    14,    15,    16,    17,    18,    19,    -1,    21,    22,
      -1,    24,    25,    26,    27,    28,    -1,    30,    -1,    32,
      33,    34,    35,    36,    37,    38,    39,    -1,    -1,    42,
      43,    -1,    45,    46,    -1,    48,    -1,    50,    51,    52,
      53,    54,    55,    -1,    57,    58,    59,    60,    -1,    -1,
      63,    64,    -1,    66,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    81,    82,
      83,    84,    -1,    -1,    -1,    -1,    89,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    98,    -1,   100,    -1,   102,
     103,    -1,   105,    -1,    -1,   108,    -1,   110,    -1,   112,
       1,   114,     3,     4,     5,     6,     7,     8,     9,    10,
      -1,    12,    13,    14,    15,    16,    17,    18,    19,    -1,
      21,    22,    -1,    24,    25,    26,    27,    28,    -1,    30,
      -1,    32,    33,    34,    35,    36,    37,    38,    39,    -1,
      -1,    42,    43,    -1,    45,    46,    -1,    48,    -1,    50,
      51,    52,    53,    54,    55,    -1,    57,    58,    59,    60,
      -1,    -1,    63,    64,    -1,    66,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      81,    82,    83,    84,    -1,    -1,    -1,    -1,    89,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    98,    -1,   100,
      -1,   102,   103,    -1,   105,    -1,    -1,   108,    -1,   110,
      -1,   112,     1,   114,     3,     4,     5,     6,     7,     8,
       9,    10,    -1,    12,    13,    14,    15,    16,    17,    18,
      19,    -1,    21,    22,    -1,    24,    25,    26,    27,    28,
      -1,    30,    -1,    32,    33,    34,    35,    36,    37,    38,
      39,    -1,    -1,    42,    43,    -1,    45,    46,    -1,    48,
      -1,    50,    51,    52,    53,    54,    55,    -1,    57,    58,
      59,    60,    -1,    -1,    63,    64,    -1,    66,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    81,    82,    83,    84,    -1,    -1,    -1,    -1,
      89,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    98,
      -1,   100,    -1,   102,   103,    -1,   105,    -1,    -1,   108,
      -1,   110,    -1,   112,     1,   114,     3,     4,     5,     6,
       7,     8,     9,    10,    -1,    12,    13,    14,    15,    16,
      17,    18,    19,    -1,    21,    22,    -1,    24,    25,    26,
      27,    28,    -1,    30,    -1,    32,    33,    34,    35,    36,
      37,    38,    39,    -1,    -1,    42,    43,    -1,    45,    46,
      -1,    48,    -1,    50,    51,    52,    53,    54,    55,    -1,
      57,    58,    59,    60,    -1,    -1,    63,    64,    -1,    66,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    81,    82,    83,    84,    -1,    -1,
      -1,    -1,    89,    -1,    -1,     3,     4,     5,     6,     7,
      -1,    98,    -1,   100,    -1,   102,   103,    -1,   105,    -1,
      -1,   108,    -1,   110,    22,   112,    -1,   114,    26,    27,
      28,    -1,    30,    -1,    -1,    33,    -1,    35,    -1,    37,
      38,    -1,    -1,    -1,    -1,    43,    -1,    45,    -1,    -1,
      -1,    -1,    -1,    -1,    52,    53,    54,    55,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    66,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    81,    82,    83,    84,    -1,    -1,    -1,
      -1,    89,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      98,    -1,   100,    -1,   102,   103,   104,    -1,    -1,    -1,
     108,    -1,    -1,    -1,   112,    -1,   114,   115,     3,     4,
       5,     6,     7,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    22,    -1,    -1,
      -1,    26,    27,    28,    -1,    30,    -1,    -1,    33,    -1,
      35,    -1,    37,    38,    -1,    -1,    -1,    -1,    43,    -1,
      45,    -1,    -1,    -1,    -1,    -1,    -1,    52,    53,    54,
      55,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    66,    67,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    81,    82,    83,    84,
      -1,    86,    -1,    -1,    89,    90,    -1,     3,     4,     5,
       6,     7,    -1,    98,    -1,   100,    -1,   102,   103,   104,
      -1,    -1,    -1,   108,    -1,    -1,    22,   112,   113,   114,
      26,    27,    28,    -1,    30,    -1,    -1,    33,    -1,    35,
      -1,    37,    38,    -1,    -1,    -1,    -1,    43,    -1,    45,
      -1,    -1,    -1,    -1,    -1,    -1,    52,    53,    54,    55,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      66,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    81,    82,    83,    84,    -1,
      -1,    -1,    -1,    89,    90,    -1,     3,     4,     5,     6,
       7,    -1,    98,    -1,   100,    -1,   102,   103,   104,    -1,
      -1,    -1,   108,    -1,    -1,    22,   112,    -1,   114,    26,
      27,    28,    -1,    30,    -1,    -1,    33,    -1,    35,    -1,
      37,    38,    -1,    -1,    -1,    42,    43,    -1,    45,    -1,
      -1,    -1,    -1,    -1,    -1,    52,    53,    54,    55,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    66,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    81,    82,    83,    84,    -1,    -1,
      -1,    -1,    89,    -1,    -1,     3,     4,     5,     6,     7,
      -1,    98,    -1,   100,    -1,   102,   103,    -1,    -1,    -1,
      -1,   108,    -1,    -1,    22,   112,    -1,   114,    26,    27,
      28,    -1,    30,    -1,    -1,    33,    -1,    35,    -1,    37,
      38,    -1,    -1,    -1,    -1,    43,    -1,    45,    -1,    -1,
      -1,    -1,    -1,    -1,    52,    53,    54,    55,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    66,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    81,    82,    83,    84,    -1,    -1,    -1,
      -1,    89,    -1,    -1,     3,     4,     5,     6,     7,    -1,
      98,    -1,   100,    -1,   102,   103,    -1,   105,    -1,    -1,
     108,    -1,    -1,    22,   112,    -1,   114,    26,    27,    28,
      -1,    30,    -1,    -1,    33,    -1,    35,    -1,    37,    38,
      -1,    -1,    -1,    -1,    43,    -1,    45,    -1,    -1,    -1,
      -1,    -1,    -1,    52,    53,    54,    55,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    66,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    81,    82,    83,    84,    -1,    -1,    -1,    -1,
      89,    -1,    -1,     3,     4,     5,     6,     7,    -1,    98,
      -1,   100,    -1,   102,   103,   104,    -1,    -1,    -1,   108,
      -1,    -1,    22,   112,    -1,   114,    26,    27,    28,    -1,
      30,    -1,    -1,    33,    -1,    35,    -1,    37,    38,    -1,
      -1,    -1,    -1,    43,    -1,    45,    -1,    -1,    -1,    -1,
      -1,    -1,    52,    53,    54,    55,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    65,    66,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    81,    82,    83,    84,    -1,    -1,    -1,    -1,    89,
      -1,    -1,     3,     4,     5,     6,     7,    -1,    98,    -1,
     100,    -1,   102,   103,    -1,    -1,    -1,    -1,   108,    -1,
      -1,    22,   112,    -1,   114,    26,    27,    28,    -1,    30,
      -1,    -1,    33,    -1,    35,    -1,    37,    38,    -1,    -1,
      -1,    -1,    43,    -1,    45,    -1,    -1,    -1,    -1,    -1,
      -1,    52,    53,    54,    55,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    66,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      81,    82,    83,    84,    -1,    -1,    -1,    -1,    89,    -1,
      -1,     3,     4,     5,     6,     7,    -1,    98,    -1,   100,
      -1,   102,   103,   104,    -1,    -1,    -1,   108,    -1,    -1,
      22,   112,    -1,   114,    26,    27,    28,    -1,    30,    -1,
      -1,    33,    -1,    35,    -1,    37,    38,    -1,    -1,    -1,
      -1,    43,    -1,    45,    -1,    -1,    -1,    -1,    -1,    -1,
      52,    53,    54,    55,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    66,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    81,
      82,    83,    84,    -1,    -1,    -1,    -1,    89,    -1,    -1,
       3,     4,     5,     6,     7,    -1,    98,    -1,   100,    -1,
     102,   103,   104,    -1,    -1,    -1,   108,    -1,    -1,    22,
     112,    -1,   114,    26,    27,    28,    -1,    30,    -1,    -1,
      33,    -1,    35,    -1,    37,    38,    -1,    -1,    -1,    -1,
      43,    -1,    45,    -1,    -1,    -1,    -1,    -1,    -1,    52,
      53,    54,    55,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    66,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    81,    82,
      83,    84,    -1,    -1,    -1,    -1,    89,    -1,    -1,     3,
       4,     5,     6,     7,    -1,    98,    -1,   100,    -1,   102,
     103,    -1,    -1,    -1,    -1,   108,    -1,    -1,    22,   112,
      -1,   114,    26,    27,    28,    -1,    30,    -1,    -1,    33,
      -1,    35,    -1,    37,    38,    -1,    -1,    -1,    -1,    43,
      -1,    45,    -1,    -1,    -1,    -1,    -1,    -1,    52,    53,
      54,    55,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    66,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    81,    82,    83,
      84,    -1,    -1,    -1,    -1,    89,    -1,    -1,     3,     4,
       5,     6,     7,    -1,    98,    -1,   100,    -1,   102,   103,
      -1,    -1,    -1,    -1,   108,    -1,    -1,    22,   112,    -1,
     114,    26,    27,    28,    -1,    30,    -1,    -1,    33,    -1,
      35,    -1,    37,    38,    -1,    -1,    -1,    -1,    43,    -1,
      45,    -1,    -1,    -1,    -1,    -1,    -1,    52,    53,    54,
      55,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    66,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    81,    82,    83,    84,
      -1,    -1,    -1,    -1,    89,    -1,    -1,     3,     4,     5,
       6,     7,    -1,    98,    -1,   100,    -1,   102,   103,    -1,
      -1,    -1,    -1,   108,    -1,    -1,    22,   112,    -1,   114,
      26,    27,    28,    -1,    30,    -1,    -1,    33,    -1,    35,
      -1,    37,    38,    -1,    -1,    -1,    -1,    43,    -1,    45,
      -1,    -1,    -1,    -1,    -1,    -1,    52,    53,    54,    55,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      66,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    81,    82,    83,    84,    -1,
      -1,    -1,    -1,    89,    -1,    -1,     3,     4,     5,     6,
       7,    -1,    98,    -1,   100,    -1,   102,   103,    -1,    -1,
      -1,    -1,   108,    -1,    -1,    22,   112,    -1,   114,    26,
      27,    28,    -1,    30,    -1,    -1,    33,    -1,    35,    -1,
      37,    38,    -1,    -1,    -1,    -1,    43,    -1,    45,    -1,
      -1,    -1,    -1,    -1,    -1,    52,    53,    54,    55,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    66,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    81,    82,    83,    84,    -1,    -1,
      -1,    -1,    89,    -1,    -1,     3,     4,     5,     6,     7,
      -1,    98,    -1,   100,    -1,   102,   103,    -1,    -1,    -1,
      -1,   108,    -1,    -1,    22,   112,    -1,   114,    26,    27,
      28,    -1,    30,    -1,    -1,    33,    -1,    35,    -1,    37,
      38,    -1,    -1,    -1,    -1,    43,    -1,    45,    -1,    -1,
      -1,    -1,    -1,    -1,    52,    53,    54,    55,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    66,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    81,    82,    83,    84,    -1,    -1,    -1,
      -1,    89,    -1,    -1,     3,     4,     5,     6,     7,    -1,
      98,    -1,   100,    -1,   102,   103,    -1,    -1,    -1,    -1,
     108,    -1,    -1,    22,   112,    -1,   114,    26,    27,    28,
      -1,    30,    -1,    -1,    33,    -1,    35,    -1,    37,    38,
      -1,    -1,    -1,    -1,    43,    -1,    45,    -1,    -1,    -1,
      -1,    -1,    -1,    52,    53,    54,    55,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    66,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    81,    82,    83,    84,    -1,    -1,    -1,    -1,
      89,    -1,    -1,     3,     4,     5,     6,     7,    -1,    98,
      -1,   100,    -1,   102,   103,    -1,    -1,    -1,    -1,   108,
      -1,    -1,    22,   112,    -1,   114,    26,    27,    28,    -1,
      30,    -1,    -1,    33,    -1,    35,    -1,    37,    38,    -1,
      -1,    -1,    -1,    43,    -1,    45,    -1,    -1,    -1,    -1,
      -1,    -1,    52,    53,    54,    55,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    66,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    81,    82,    83,    84,    -1,    -1,    -1,    -1,    89,
      -1,    -1,     3,     4,     5,     6,     7,    -1,    98,    -1,
     100,    -1,   102,   103,    -1,    -1,    -1,    -1,   108,    -1,
      -1,    22,   112,    -1,   114,    26,    27,    28,    -1,    30,
      -1,    -1,    33,    -1,    35,    -1,    37,    38,    -1,    -1,
      -1,    -1,    43,    -1,    45,    -1,    -1,    -1,    -1,    -1,
      -1,    52,    53,    54,    55,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    66,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      81,    82,    83,    84,    -1,    -1,    -1,    -1,    89,    -1,
      -1,     3,     4,     5,     6,     7,    -1,    98,    -1,   100,
      -1,   102,   103,    -1,    -1,    -1,    -1,   108,    -1,    -1,
      22,   112,    -1,   114,    26,    27,    28,    -1,    30,    -1,
      -1,    33,    -1,    35,    -1,    37,    38,    -1,     3,    -1,
      -1,    43,    -1,    45,    -1,    -1,    11,    -1,    -1,    -1,
      52,    53,    54,    55,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    66,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    81,
      82,    83,    84,    -1,    -1,    11,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    20,    -1,    98,    -1,   100,    -1,
     102,   103,    67,    -1,    -1,    -1,   108,    -1,    -1,    -1,
     112,    -1,   114,    -1,    -1,    -1,    81,    82,    83,    84,
      -1,    47,    87,    49,    -1,    -1,    91,    92,    93,    94,
      95,    96,    97,    98,    99,   100,   101,    -1,   103,    -1,
      66,   106,   107,   108,    -1,    -1,    -1,    11,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    81,    20,    83,    84,    85,
      -1,    87,    88,    89,    -1,    91,    92,    93,    94,    95,
      96,    97,    98,    99,    -1,   101,   102,   103,    -1,    -1,
     106,   107,   108,    47,    -1,    49,   112,    -1,   114,   115,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    66,    -1,    -1,    -1,    -1,    -1,    -1,    11,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    81,    20,    83,
      84,    85,    -1,    87,    88,    89,    -1,    91,    92,    93,
      94,    95,    96,    97,    98,    99,    -1,   101,   102,   103,
      -1,    -1,   106,   107,   108,    47,    -1,    49,   112,    -1,
     114,   115,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    66,    -1,    -1,    -1,    -1,    -1,
      -1,    11,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    81,
      20,    83,    84,    85,    -1,    87,    88,    89,    -1,    91,
      92,    93,    94,    95,    96,    97,    98,    99,    -1,   101,
     102,   103,    -1,    -1,   106,   107,   108,    47,    -1,    49,
     112,    -1,   114,   115,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    66,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    81,    -1,    83,    84,    85,    -1,    87,    88,    89,
      -1,    91,    92,    93,    94,    95,    96,    97,    98,    99,
      11,   101,   102,   103,    -1,    -1,   106,   107,   108,    20,
      21,    -1,   112,    -1,   114,   115,    -1,    -1,    29,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    47,    -1,    49,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    66,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      81,    -1,    83,    84,    85,    -1,    87,    88,    89,    -1,
      91,    92,    93,    94,    95,    96,    97,    98,    99,    -1,
     101,   102,   103,    -1,    -1,   106,   107,   108,    11,   110,
      -1,   112,    -1,   114,    -1,    -1,    -1,    20,    21,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    29,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    47,    -1,    49,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    66,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    81,    -1,
      83,    84,    85,    -1,    87,    88,    89,    -1,    91,    92,
      93,    94,    95,    96,    97,    98,    99,    -1,   101,   102,
     103,    -1,    -1,   106,   107,   108,    11,   110,    -1,   112,
      -1,   114,    -1,    -1,    -1,    20,    21,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    29,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    47,    20,    49,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    66,    -1,    -1,    -1,    -1,    -1,    -1,    11,    -1,
      47,    -1,    49,    -1,    -1,    -1,    81,    20,    83,    84,
      85,    -1,    87,    88,    89,    -1,    91,    92,    93,    94,
      95,    96,    97,    98,    99,    -1,   101,   102,   103,    -1,
      -1,   106,   107,   108,    47,   110,    49,   112,    85,   114,
      87,    88,    -1,    56,    91,    92,    93,    94,    -1,    96,
      97,    98,    99,    66,   101,    -1,   103,    -1,    -1,   106,
     107,   108,    -1,    -1,    -1,   112,    -1,   114,    81,    -1,
      83,    84,    85,    -1,    87,    88,    89,    -1,    91,    92,
      93,    94,    95,    96,    97,    98,    99,    -1,   101,   102,
     103,    -1,    -1,   106,   107,   108,    11,   110,    -1,   112,
      -1,   114,    -1,    -1,    -1,    20,    21,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    47,    -1,    49,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    66,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    81,    -1,    83,    84,
      85,    -1,    87,    88,    89,    -1,    91,    92,    93,    94,
      95,    96,    97,    98,    99,    -1,   101,   102,   103,    -1,
      -1,   106,   107,   108,    11,   110,    -1,   112,    -1,   114,
      -1,    -1,    -1,    20,    21,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    29,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      47,    -1,    49,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    66,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    81,    -1,    83,    84,    85,    -1,
      87,    88,    89,    -1,    91,    92,    93,    94,    95,    96,
      97,    98,    99,    11,   101,   102,   103,    -1,    -1,   106,
     107,   108,    20,    21,    -1,   112,    -1,   114,    -1,    -1,
      -1,    29,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    47,
      -1,    49,    -1,    20,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    66,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      47,    -1,    49,    81,    -1,    83,    84,    85,    -1,    87,
      88,    89,    -1,    91,    92,    93,    94,    95,    96,    97,
      98,    99,    11,   101,   102,   103,    -1,    -1,   106,   107,
     108,    20,    21,    -1,   112,    -1,   114,    -1,    85,    -1,
      87,    88,    -1,    -1,    -1,    92,    -1,    -1,    -1,    -1,
      -1,    98,    99,    -1,    -1,    -1,   103,    -1,    47,    20,
      49,   108,    -1,    -1,    -1,   112,    -1,   114,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    66,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    47,    -1,    49,    -1,
      -1,    -1,    81,    -1,    83,    84,    85,    -1,    87,    88,
      89,    -1,    91,    92,    93,    94,    95,    96,    97,    98,
      99,    -1,   101,   102,   103,    -1,    -1,   106,   107,   108,
      11,   110,    -1,   112,    85,   114,    87,    88,    -1,    20,
      21,    92,    93,    94,    -1,    96,    97,    98,    99,    -1,
      -1,    -1,   103,    -1,    -1,   106,   107,   108,    -1,    -1,
      -1,   112,    -1,   114,    -1,    -1,    47,    -1,    49,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    66,    -1,    -1,    -1,    -1,
      -1,    -1,    11,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      81,    20,    83,    84,    85,    -1,    87,    88,    89,    -1,
      91,    92,    93,    94,    95,    96,    97,    98,    99,    -1,
     101,   102,   103,    -1,    -1,   106,   107,   108,    47,   110,
      49,   112,    -1,   114,    -1,    -1,    -1,    56,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    66,    -1,    -1,
      -1,    -1,    -1,    -1,    11,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    81,    20,    83,    84,    85,    -1,    87,    88,
      89,    -1,    91,    92,    93,    94,    95,    96,    97,    98,
      99,    -1,   101,   102,   103,    -1,    -1,   106,   107,   108,
      47,   110,    49,   112,    -1,   114,    -1,    -1,    -1,    56,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    66,
      -1,    -1,    -1,    -1,    -1,    -1,    11,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    81,    20,    83,    84,    85,    -1,
      87,    88,    89,    -1,    91,    92,    93,    94,    95,    96,
      97,    98,    99,    -1,   101,   102,   103,    -1,    -1,   106,
     107,   108,    47,   110,    49,   112,    -1,   114,    -1,    -1,
      -1,    56,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    66,    -1,    -1,    -1,    -1,    -1,    -1,    11,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    81,    20,    83,    84,
      85,    -1,    87,    88,    89,    -1,    91,    92,    93,    94,
      95,    96,    97,    98,    99,    -1,   101,   102,   103,    -1,
      -1,   106,   107,   108,    47,   110,    49,   112,    -1,   114,
      -1,    -1,    -1,    56,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    66,    -1,    -1,    -1,    -1,    -1,    -1,
      11,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    81,    20,
      83,    84,    85,    -1,    87,    88,    89,    -1,    91,    92,
      93,    94,    95,    96,    97,    98,    99,    -1,   101,   102,
     103,    -1,    -1,   106,   107,   108,    47,   110,    49,   112,
      -1,   114,    -1,    -1,    -1,    56,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    66,    -1,    -1,    -1,    -1,
      -1,    -1,    11,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      81,    20,    83,    84,    85,    -1,    87,    88,    89,    -1,
      91,    92,    93,    94,    95,    96,    97,    98,    99,    -1,
     101,   102,   103,    -1,    -1,   106,   107,   108,    47,   110,
      49,   112,    -1,   114,    -1,    -1,    -1,    56,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    66,    -1,    -1,
      -1,    -1,    -1,    -1,    11,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    81,    20,    83,    84,    85,    -1,    87,    88,
      89,    -1,    91,    92,    93,    94,    95,    96,    97,    98,
      99,    -1,   101,   102,   103,    -1,    -1,   106,   107,   108,
      47,   110,    49,   112,    -1,   114,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    66,
      -1,    -1,    -1,    -1,    -1,    -1,    11,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    81,    20,    83,    84,    85,    -1,
      87,    88,    89,    -1,    91,    92,    93,    94,    95,    96,
      97,    98,    99,    -1,   101,   102,   103,    -1,   105,   106,
     107,   108,    47,    -1,    49,   112,    -1,   114,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    66,    -1,    -1,    -1,    -1,    -1,    -1,    11,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    81,    20,    83,    84,
      85,    -1,    87,    88,    89,    -1,    91,    92,    93,    94,
      95,    96,    97,    98,    99,    -1,   101,   102,   103,    -1,
     105,   106,   107,   108,    47,    -1,    49,   112,    -1,   114,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    66,    -1,    -1,    -1,    -1,    -1,    -1,
      11,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    81,    20,
      83,    84,    85,    -1,    87,    88,    89,    -1,    91,    92,
      93,    94,    95,    96,    97,    98,    99,    -1,   101,   102,
     103,    -1,    -1,   106,   107,   108,    47,   110,    49,   112,
      -1,   114,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    66,    -1,    -1,    -1,    -1,
      -1,    -1,    11,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      81,    20,    83,    84,    85,    -1,    87,    88,    89,    -1,
      91,    92,    93,    94,    95,    96,    97,    98,    99,    -1,
     101,   102,   103,    -1,   105,   106,   107,   108,    47,    -1,
      49,   112,    -1,   114,    -1,    -1,    -1,    56,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    66,    -1,    -1,
      -1,    -1,    -1,    -1,    11,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    81,    20,    83,    84,    85,    -1,    87,    88,
      89,    -1,    91,    92,    93,    94,    95,    96,    97,    98,
      99,    -1,   101,   102,   103,    -1,    -1,   106,   107,   108,
      47,    -1,    49,   112,    -1,   114,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    66,
      -1,    -1,    -1,    -1,    -1,    -1,    11,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    81,    20,    83,    84,    85,    -1,
      87,    88,    89,    -1,    91,    92,    93,    94,    95,    96,
      97,    98,    99,    -1,   101,   102,   103,    -1,    -1,   106,
     107,   108,    47,    -1,    49,   112,   113,   114,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    66,    -1,    -1,    -1,    -1,    -1,    -1,    11,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    81,    20,    83,    84,
      85,    -1,    87,    88,    89,    -1,    91,    92,    93,    94,
      95,    96,    97,    98,    99,    -1,   101,   102,   103,    -1,
     105,   106,   107,   108,    47,    -1,    49,   112,    -1,   114,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    66,    -1,    -1,    -1,    -1,    -1,    -1,
      11,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    81,    20,
      83,    84,    85,    -1,    87,    88,    89,    -1,    91,    92,
      93,    94,    95,    96,    97,    98,    99,    -1,   101,   102,
     103,    -1,   105,   106,   107,   108,    47,    -1,    49,   112,
      -1,   114,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    66,    -1,    -1,    -1,    -1,
      -1,    -1,    11,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      81,    20,    83,    84,    85,    -1,    87,    88,    89,    -1,
      91,    92,    93,    94,    95,    96,    97,    98,    99,    -1,
     101,   102,   103,    -1,   105,   106,   107,   108,    47,    -1,
      49,   112,    -1,   114,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    66,    -1,    -1,
      -1,    -1,    -1,    -1,    11,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    81,    20,    83,    84,    85,    -1,    87,    88,
      89,    -1,    91,    92,    93,    94,    95,    96,    97,    98,
      99,    -1,   101,   102,   103,    -1,   105,   106,   107,   108,
      47,    -1,    49,   112,    -1,   114,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    66,
      -1,    -1,    -1,    -1,    -1,    -1,    11,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    81,    20,    83,    84,    85,    -1,
      87,    88,    89,    -1,    91,    92,    93,    94,    95,    96,
      97,    98,    99,    -1,   101,   102,   103,    -1,   105,   106,
     107,   108,    47,    -1,    49,   112,    -1,   114,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    66,    -1,    -1,    -1,    -1,    -1,    -1,    11,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    81,    20,    83,    84,
      85,    -1,    87,    88,    89,    -1,    91,    92,    93,    94,
      95,    96,    97,    98,    99,    -1,   101,   102,   103,    -1,
     105,   106,   107,   108,    47,    -1,    49,   112,    -1,   114,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    66,    -1,    -1,    -1,    -1,    -1,    -1,
      11,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    81,    20,
      83,    84,    85,    -1,    87,    88,    89,    -1,    91,    92,
      93,    94,    95,    96,    97,    98,    99,    -1,   101,   102,
     103,    -1,   105,   106,   107,   108,    47,    -1,    49,   112,
      -1,   114,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    66,    -1,    -1,    -1,    -1,
      -1,    -1,    11,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      81,    20,    83,    84,    85,    -1,    87,    88,    89,    -1,
      91,    92,    93,    94,    95,    96,    97,    98,    99,    -1,
     101,   102,   103,    -1,   105,   106,   107,   108,    47,    -1,
      49,   112,    -1,   114,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    66,    -1,    -1,
      -1,    -1,    -1,    -1,    11,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    81,    20,    83,    84,    85,    -1,    87,    88,
      89,    -1,    91,    92,    93,    94,    95,    96,    97,    98,
      99,    -1,   101,   102,   103,    -1,   105,   106,   107,   108,
      47,    -1,    49,   112,    -1,   114,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    66,
      -1,    -1,    -1,    -1,    -1,    -1,    11,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    81,    20,    83,    84,    85,    -1,
      87,    88,    89,    -1,    91,    92,    93,    94,    95,    96,
      97,    98,    99,    -1,   101,   102,   103,    -1,   105,   106,
     107,   108,    47,    -1,    49,   112,    -1,   114,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    66,    -1,    -1,    -1,    -1,    -1,    -1,    11,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    81,    20,    83,    84,
      85,    -1,    87,    88,    89,    -1,    91,    92,    93,    94,
      95,    96,    97,    98,    99,    -1,   101,   102,   103,    -1,
     105,   106,   107,   108,    47,    -1,    49,   112,    -1,   114,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    66,    -1,    -1,    -1,    -1,    -1,    -1,
      11,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    81,    20,
      83,    84,    85,    -1,    87,    88,    89,    -1,    91,    92,
      93,    94,    95,    96,    97,    98,    99,    -1,   101,   102,
     103,    -1,   105,   106,   107,   108,    47,    -1,    49,   112,
      -1,   114,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    66,    -1,    -1,    -1,    -1,
      -1,    -1,    11,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      81,    20,    83,    84,    85,    -1,    87,    88,    89,    -1,
      91,    92,    93,    94,    95,    96,    97,    98,    99,    -1,
     101,   102,   103,    -1,   105,   106,   107,   108,    47,    20,
      49,   112,    -1,   114,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    66,    -1,    -1,
      -1,    -1,    -1,    -1,    11,    -1,    47,    -1,    49,    -1,
      -1,    -1,    81,    20,    83,    84,    85,    -1,    87,    88,
      89,    -1,    91,    92,    93,    94,    95,    96,    97,    98,
      99,    -1,   101,   102,   103,    -1,   105,   106,   107,   108,
      47,    -1,    49,   112,    85,   114,    87,    88,    -1,    -1,
      -1,    92,    -1,    -1,    -1,    -1,    -1,    98,    99,    66,
      -1,    -1,   103,    -1,    -1,   106,   107,   108,    -1,    -1,
      -1,   112,    -1,   114,    81,    -1,    83,    84,    85,    -1,
      87,    88,    89,    -1,    91,    92,    93,    94,    95,    96,
      97,    98,    99,    -1,   101,   102,   103,    11,   105,   106,
     107,   108,    -1,    -1,    -1,   112,    20,   114,    -1,    23,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    47,    -1,    49,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    66,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    81,    -1,    83,
      84,    85,    -1,    87,    88,    89,    -1,    91,    92,    93,
      94,    95,    96,    97,    98,    99,    11,   101,   102,   103,
      -1,    -1,   106,   107,   108,    20,    21,    -1,   112,    -1,
     114,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    47,    -1,    49,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    66,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    81,    -1,    83,    84,
      85,    -1,    87,    88,    89,    -1,    91,    92,    93,    94,
      95,    96,    97,    98,    99,    11,   101,   102,   103,    -1,
      -1,   106,   107,   108,    20,    21,    -1,   112,    -1,   114,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    47,    -1,    49,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      66,    -1,    -1,    -1,    -1,    -1,    -1,    11,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    81,    20,    83,    84,    85,
      -1,    87,    88,    89,    -1,    91,    92,    93,    94,    95,
      96,    97,    98,    99,    -1,   101,   102,   103,    -1,    -1,
     106,   107,   108,    47,    -1,    49,   112,    -1,   114,    -1,
      -1,    -1,    56,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    66,    -1,    -1,    -1,    -1,    -1,    -1,    11,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    81,    20,    83,
      84,    85,    -1,    87,    88,    89,    -1,    91,    92,    93,
      94,    95,    96,    97,    98,    99,    -1,   101,   102,   103,
      -1,    -1,   106,   107,   108,    47,    -1,    49,   112,    -1,
     114,    -1,    -1,    -1,    56,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    66,    -1,    -1,    -1,    -1,    -1,
      -1,    11,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    81,
      20,    83,    84,    85,    -1,    87,    88,    89,    -1,    91,
      92,    93,    94,    95,    96,    97,    98,    99,    -1,   101,
     102,   103,    -1,    -1,   106,   107,   108,    47,    -1,    49,
     112,    -1,   114,    -1,    -1,    -1,    56,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    66,    -1,    -1,    -1,
      -1,    -1,    -1,    11,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    81,    20,    83,    84,    85,    -1,    87,    88,    89,
      -1,    91,    92,    93,    94,    95,    96,    97,    98,    99,
      -1,   101,   102,   103,    -1,    -1,   106,   107,   108,    47,
      -1,    49,   112,    -1,   114,    -1,    -1,    -1,    56,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    66,    -1,
      -1,    -1,    -1,    -1,    -1,    11,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    81,    20,    83,    84,    85,    -1,    87,
      88,    89,    -1,    91,    92,    93,    94,    95,    96,    97,
      98,    99,    -1,   101,   102,   103,    -1,    -1,   106,   107,
     108,    47,    -1,    49,   112,    -1,   114,    -1,    -1,    -1,
      56,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      66,    -1,    -1,    -1,    -1,    -1,    -1,    11,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    81,    20,    83,    84,    85,
      -1,    87,    88,    89,    -1,    91,    92,    93,    94,    95,
      96,    97,    98,    99,    -1,   101,   102,   103,    -1,    -1,
     106,   107,   108,    47,    -1,    49,   112,    -1,   114,    -1,
      -1,    -1,    56,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    66,    -1,    -1,    -1,    -1,    -1,    -1,    11,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    81,    20,    83,
      84,    85,    -1,    87,    88,    89,    -1,    91,    92,    93,
      94,    95,    96,    97,    98,    99,    -1,   101,   102,   103,
      -1,    -1,   106,   107,   108,    47,    -1,    49,   112,    -1,
     114,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    66,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    81,
      20,    83,    84,    85,    -1,    87,    88,    89,    -1,    91,
      92,    93,    94,    95,    96,    97,    98,    99,    -1,   101,
     102,   103,    -1,    -1,   106,   107,   108,    47,    -1,    49,
     112,    -1,   114,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    66,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    81,    20,    83,    84,    85,    -1,    87,    88,    89,
      -1,    91,    92,    93,    94,    -1,    96,    97,    98,    99,
      -1,   101,   102,   103,    -1,    -1,   106,   107,   108,    47,
      -1,    49,   112,    -1,   114,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    66,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    81,    20,    83,    84,    85,    -1,    87,
      88,    -1,    -1,    91,    92,    93,    94,    -1,    96,    97,
      98,    99,    -1,   101,   102,   103,    -1,    -1,   106,   107,
     108,    47,    -1,    49,   112,    -1,   114,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    20,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    81,    -1,    83,    84,    85,
      -1,    87,    88,    -1,    -1,    91,    92,    93,    94,    -1,
      96,    97,    98,    99,    47,   101,    49,   103,    -1,    -1,
     106,   107,   108,    -1,    -1,    -1,   112,    -1,   114,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      20,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    81,    -1,
      -1,    84,    85,    -1,    87,    88,    -1,    -1,    91,    92,
      93,    94,    -1,    96,    97,    98,    99,    47,   101,    49,
     103,    -1,    -1,   106,   107,   108,    -1,    -1,    -1,   112,
      -1,   114,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    81,    -1,    -1,    -1,    85,    -1,    87,    88,    -1,
      -1,    91,    92,    93,    94,    -1,    96,    97,    98,    99,
      -1,   101,    -1,   103,    -1,    -1,   106,   107,   108,    -1,
      -1,    -1,   112,    -1,   114
};

/* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
static const yytype_uint8 yystos[] =
{
       0,   120,   121,     0,   122,     1,     3,     4,     5,     6,
       7,     8,     9,    10,    13,    14,    15,    17,    18,    19,
      21,    22,    24,    25,    26,    27,    28,    30,    32,    33,
      34,    35,    36,    37,    38,    39,    43,    44,    45,    48,
      50,    51,    52,    53,    54,    55,    57,    59,    63,    64,
      66,    81,    82,    83,    84,    89,    98,   100,   102,   103,
     105,   108,   110,   112,   114,   123,   124,   125,   127,   129,
     130,   131,   132,   133,   136,   137,   138,   142,   145,   148,
     161,   162,   165,   166,   182,   183,   184,   185,   186,   187,
     188,   189,   190,   191,   192,   193,   194,   123,   123,   126,
     127,   125,    26,    27,    28,    55,   114,   182,   184,   187,
     126,   146,   182,   123,   112,   127,    18,    42,   182,   182,
     182,   112,   127,   112,   127,   167,   168,   123,   182,   127,
     182,   182,   182,     7,   112,   105,   182,   182,   182,   182,
      54,   112,   123,   182,    50,   127,   163,   104,   157,   177,
     182,   182,   182,   182,   182,   182,   182,   182,   121,    90,
     157,   178,   182,   177,    12,    46,    58,   139,    16,    42,
      60,    11,    20,    47,    49,    66,    81,    83,    84,    85,
      87,    88,    89,    91,    92,    93,    94,    95,    96,    97,
      98,    99,   101,   102,   103,   106,   107,   108,   112,   114,
     105,    67,    68,    69,    70,    71,    72,    73,    74,    75,
      76,    77,    78,    79,    80,   109,    47,    49,   105,   182,
     182,   182,   177,    21,    29,   125,   128,   105,    11,    67,
      81,    82,    83,    84,    87,    91,    92,    93,    94,    95,
      96,    97,    98,    99,   100,   101,   103,   106,   107,   108,
     127,   149,   150,   105,    63,   127,   157,   179,   180,   181,
     182,   110,   149,   127,    21,    29,   128,    21,    29,   128,
      56,   125,   179,   123,   112,   127,   169,    85,   171,   172,
      29,    86,   110,   128,   179,   105,   110,   128,   112,   179,
     177,    67,   164,   105,   127,    86,   105,   128,   105,   111,
     182,    86,   113,    29,   115,   127,   167,   167,   167,   182,
     182,   182,   182,   182,   182,   182,   182,   182,   182,    22,
      57,   127,   182,   182,   182,   182,   182,   182,   182,   182,
     182,   182,   182,   182,   182,   182,   182,   182,   179,   179,
     182,   182,   182,   182,   182,   182,   182,   182,   182,   182,
     182,   182,   182,   182,   187,   182,   182,    21,    29,    21,
      29,    56,    29,   115,   123,   182,   127,    88,   147,   112,
     151,   182,    65,    67,   113,    86,   127,   143,   144,    85,
     172,    29,    28,   182,   182,    28,   182,   182,   123,   182,
      23,   113,   169,    86,   113,   114,   173,   183,    65,    67,
     170,   182,   168,   121,   113,   134,   179,   113,   110,   182,
      86,   157,   182,   113,   157,   182,   182,    28,   123,   182,
      85,   140,   105,   105,   105,   113,   115,   105,   105,   105,
     105,   105,   105,   105,   105,   105,   105,   105,   105,   105,
     105,   105,    28,   182,    28,   182,   182,    28,   128,   127,
     150,    16,    42,    57,    60,   155,    16,    29,    31,    41,
      42,    57,   152,   153,   154,   105,   182,   157,   182,   181,
      67,    86,   111,   114,   105,   182,   182,    21,   128,   182,
      21,   128,    23,    23,   123,   113,   112,   127,   172,   177,
     182,   182,   111,    40,    61,   111,   135,   113,   134,   163,
     115,   182,   177,   110,   182,    21,   182,    21,   115,   182,
     151,   172,    86,   113,   112,   127,   182,   144,   105,   177,
     128,    56,    28,   182,    56,    28,   182,   123,   182,   169,
     170,    29,   115,   123,   177,   111,    28,   123,   182,    56,
     141,    56,    28,    56,    28,    28,    56,    62,   160,   153,
     169,    85,   176,   115,   182,   182,   182,   182,   113,   182,
     182,   128,   182,   182,   111,   122,   182,   182,   182,   182,
     125,   129,   156,   113,    22,    52,    55,   114,   157,   175,
     183,    90,   159,   170,    56,    56,   115,    56,    57,   130,
      56,    56,    56,   176,   115,   177,   157,   158,   182,   182,
     182,   182,   182,   159,   170,   157,   174,   182,    29,   115,
     182,   174,   182,   115,   174,   182
};

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		(-2)
#define YYEOF		0

#define YYACCEPT	goto yyacceptlab
#define YYABORT		goto yyabortlab
#define YYERROR		goto yyerrorlab


/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */

#define YYFAIL		goto yyerrlab

#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      yytoken = YYTRANSLATE (yychar);				\
      YYPOPSTACK (1);						\
      goto yybackup;						\
    }								\
  else								\
    {								\
      yyerror (YY_("syntax error: cannot back up")); \
      YYERROR;							\
    }								\
while (YYID (0))


#define YYTERROR	1
#define YYERRCODE	256


/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

#define YYRHSLOC(Rhs, K) ((Rhs)[K])
#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)				\
    do									\
      if (YYID (N))                                                    \
	{								\
	  (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;	\
	  (Current).first_column = YYRHSLOC (Rhs, 1).first_column;	\
	  (Current).last_line    = YYRHSLOC (Rhs, N).last_line;		\
	  (Current).last_column  = YYRHSLOC (Rhs, N).last_column;	\
	}								\
      else								\
	{								\
	  (Current).first_line   = (Current).last_line   =		\
	    YYRHSLOC (Rhs, 0).last_line;				\
	  (Current).first_column = (Current).last_column =		\
	    YYRHSLOC (Rhs, 0).last_column;				\
	}								\
    while (YYID (0))
#endif


/* YY_LOCATION_PRINT -- Print the location on the stream.
   This macro was not mandated originally: define only if we know
   we won't break user code: when these are the locations we know.  */

#ifndef YY_LOCATION_PRINT
# if YYLTYPE_IS_TRIVIAL
#  define YY_LOCATION_PRINT(File, Loc)			\
     fprintf (File, "%d.%d-%d.%d",			\
	      (Loc).first_line, (Loc).first_column,	\
	      (Loc).last_line,  (Loc).last_column)
# else
#  define YY_LOCATION_PRINT(File, Loc) ((void) 0)
# endif
#endif


/* YYLEX -- calling `yylex' with the right arguments.  */

#ifdef YYLEX_PARAM
# define YYLEX yylex (YYLEX_PARAM)
#else
# define YYLEX yylex ()
#endif

/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (YYID (0))

# define YY_SYMBOL_PRINT(Title, Type, Value, Location)			  \
do {									  \
  if (yydebug)								  \
    {									  \
      YYFPRINTF (stderr, "%s ", Title);					  \
      yy_symbol_print (stderr,						  \
		  Type, Value, Location); \
      YYFPRINTF (stderr, "\n");						  \
    }									  \
} while (YYID (0))


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_value_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep, YYLTYPE const * const yylocationp)
#else
static void
yy_symbol_value_print (yyoutput, yytype, yyvaluep, yylocationp)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
    YYLTYPE const * const yylocationp;
#endif
{
  if (!yyvaluep)
    return;
  YYUSE (yylocationp);
# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# else
  YYUSE (yyoutput);
# endif
  switch (yytype)
    {
      default:
	break;
    }
}


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep, YYLTYPE const * const yylocationp)
#else
static void
yy_symbol_print (yyoutput, yytype, yyvaluep, yylocationp)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
    YYLTYPE const * const yylocationp;
#endif
{
  if (yytype < YYNTOKENS)
    YYFPRINTF (yyoutput, "token %s (", yytname[yytype]);
  else
    YYFPRINTF (yyoutput, "nterm %s (", yytname[yytype]);

  YY_LOCATION_PRINT (yyoutput, *yylocationp);
  YYFPRINTF (yyoutput, ": ");
  yy_symbol_value_print (yyoutput, yytype, yyvaluep, yylocationp);
  YYFPRINTF (yyoutput, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_stack_print (yytype_int16 *bottom, yytype_int16 *top)
#else
static void
yy_stack_print (bottom, top)
    yytype_int16 *bottom;
    yytype_int16 *top;
#endif
{
  YYFPRINTF (stderr, "Stack now");
  for (; bottom <= top; ++bottom)
    YYFPRINTF (stderr, " %d", *bottom);
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)				\
do {								\
  if (yydebug)							\
    yy_stack_print ((Bottom), (Top));				\
} while (YYID (0))


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_reduce_print (YYSTYPE *yyvsp, YYLTYPE *yylsp, int yyrule)
#else
static void
yy_reduce_print (yyvsp, yylsp, yyrule)
    YYSTYPE *yyvsp;
    YYLTYPE *yylsp;
    int yyrule;
#endif
{
  int yynrhs = yyr2[yyrule];
  int yyi;
  unsigned long int yylno = yyrline[yyrule];
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %lu):\n",
	     yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      fprintf (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr, yyrhs[yyprhs[yyrule] + yyi],
		       &(yyvsp[(yyi + 1) - (yynrhs)])
		       , &(yylsp[(yyi + 1) - (yynrhs)])		       );
      fprintf (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)		\
do {					\
  if (yydebug)				\
    yy_reduce_print (yyvsp, yylsp, Rule); \
} while (YYID (0))

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif



#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined __GLIBC__ && defined _STRING_H
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static YYSIZE_T
yystrlen (const char *yystr)
#else
static YYSIZE_T
yystrlen (yystr)
    const char *yystr;
#endif
{
  YYSIZE_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static char *
yystpcpy (char *yydest, const char *yysrc)
#else
static char *
yystpcpy (yydest, yysrc)
    char *yydest;
    const char *yysrc;
#endif
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYSIZE_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYSIZE_T yyn = 0;
      char const *yyp = yystr;

      for (;;)
	switch (*++yyp)
	  {
	  case '\'':
	  case ',':
	    goto do_not_strip_quotes;

	  case '\\':
	    if (*++yyp != '\\')
	      goto do_not_strip_quotes;
	    /* Fall through.  */
	  default:
	    if (yyres)
	      yyres[yyn] = *yyp;
	    yyn++;
	    break;

	  case '"':
	    if (yyres)
	      yyres[yyn] = '\0';
	    return yyn;
	  }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return yystrlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

/* Copy into YYRESULT an error message about the unexpected token
   YYCHAR while in state YYSTATE.  Return the number of bytes copied,
   including the terminating null byte.  If YYRESULT is null, do not
   copy anything; just return the number of bytes that would be
   copied.  As a special case, return 0 if an ordinary "syntax error"
   message will do.  Return YYSIZE_MAXIMUM if overflow occurs during
   size calculation.  */
static YYSIZE_T
yysyntax_error (char *yyresult, int yystate, int yychar)
{
  int yyn = yypact[yystate];

  if (! (YYPACT_NINF < yyn && yyn <= YYLAST))
    return 0;
  else
    {
      int yytype = YYTRANSLATE (yychar);
      YYSIZE_T yysize0 = yytnamerr (0, yytname[yytype]);
      YYSIZE_T yysize = yysize0;
      YYSIZE_T yysize1;
      int yysize_overflow = 0;
      enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
      char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
      int yyx;

# if 0
      /* This is so xgettext sees the translatable formats that are
	 constructed on the fly.  */
      YY_("syntax error, unexpected %s");
      YY_("syntax error, unexpected %s, expecting %s");
      YY_("syntax error, unexpected %s, expecting %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s");
# endif
      char *yyfmt;
      char const *yyf;
      static char const yyunexpected[] = "syntax error, unexpected %s";
      static char const yyexpecting[] = ", expecting %s";
      static char const yyor[] = " or %s";
      char yyformat[sizeof yyunexpected
		    + sizeof yyexpecting - 1
		    + ((YYERROR_VERBOSE_ARGS_MAXIMUM - 2)
		       * (sizeof yyor - 1))];
      char const *yyprefix = yyexpecting;

      /* Start YYX at -YYN if negative to avoid negative indexes in
	 YYCHECK.  */
      int yyxbegin = yyn < 0 ? -yyn : 0;

      /* Stay within bounds of both yycheck and yytname.  */
      int yychecklim = YYLAST - yyn + 1;
      int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
      int yycount = 1;

      yyarg[0] = yytname[yytype];
      yyfmt = yystpcpy (yyformat, yyunexpected);

      for (yyx = yyxbegin; yyx < yyxend; ++yyx)
	if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
	  {
	    if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
	      {
		yycount = 1;
		yysize = yysize0;
		yyformat[sizeof yyunexpected - 1] = '\0';
		break;
	      }
	    yyarg[yycount++] = yytname[yyx];
	    yysize1 = yysize + yytnamerr (0, yytname[yyx]);
	    yysize_overflow |= (yysize1 < yysize);
	    yysize = yysize1;
	    yyfmt = yystpcpy (yyfmt, yyprefix);
	    yyprefix = yyor;
	  }

      yyf = YY_(yyformat);
      yysize1 = yysize + yystrlen (yyf);
      yysize_overflow |= (yysize1 < yysize);
      yysize = yysize1;

      if (yysize_overflow)
	return YYSIZE_MAXIMUM;

      if (yyresult)
	{
	  /* Avoid sprintf, as that infringes on the user's name space.
	     Don't have undefined behavior even if the translation
	     produced a string with the wrong number of "%s"s.  */
	  char *yyp = yyresult;
	  int yyi = 0;
	  while ((*yyp = *yyf) != '\0')
	    {
	      if (*yyp == '%' && yyf[1] == 's' && yyi < yycount)
		{
		  yyp += yytnamerr (yyp, yyarg[yyi++]);
		  yyf += 2;
		}
	      else
		{
		  yyp++;
		  yyf++;
		}
	    }
	}
      return yysize;
    }
}
#endif /* YYERROR_VERBOSE */


/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep, YYLTYPE *yylocationp)
#else
static void
yydestruct (yymsg, yytype, yyvaluep, yylocationp)
    const char *yymsg;
    int yytype;
    YYSTYPE *yyvaluep;
    YYLTYPE *yylocationp;
#endif
{
  YYUSE (yyvaluep);
  YYUSE (yylocationp);

  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  switch (yytype)
    {

      default:
	break;
    }
}


/* Prevent warnings from -Wmissing-prototypes.  */

#ifdef YYPARSE_PARAM
#if defined __STDC__ || defined __cplusplus
int yyparse (void *YYPARSE_PARAM);
#else
int yyparse ();
#endif
#else /* ! YYPARSE_PARAM */
#if defined __STDC__ || defined __cplusplus
int yyparse (void);
#else
int yyparse ();
#endif
#endif /* ! YYPARSE_PARAM */



/* The look-ahead symbol.  */
int yychar;

/* The semantic value of the look-ahead symbol.  */
YYSTYPE yylval;

/* Number of syntax errors so far.  */
int yynerrs;
/* Location data for the look-ahead symbol.  */
YYLTYPE yylloc;



/*----------.
| yyparse.  |
`----------*/

#ifdef YYPARSE_PARAM
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void *YYPARSE_PARAM)
#else
int
yyparse (YYPARSE_PARAM)
    void *YYPARSE_PARAM;
#endif
#else /* ! YYPARSE_PARAM */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void)
#else
int
yyparse ()

#endif
#endif
{
  
  int yystate;
  int yyn;
  int yyresult;
  /* Number of tokens to shift before error messages enabled.  */
  int yyerrstatus;
  /* Look-ahead token as an internal (translated) token number.  */
  int yytoken = 0;
#if YYERROR_VERBOSE
  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYSIZE_T yymsg_alloc = sizeof yymsgbuf;
#endif

  /* Three stacks and their tools:
     `yyss': related to states,
     `yyvs': related to semantic values,
     `yyls': related to locations.

     Refer to the stacks thru separate pointers, to allow yyoverflow
     to reallocate them elsewhere.  */

  /* The state stack.  */
  yytype_int16 yyssa[YYINITDEPTH];
  yytype_int16 *yyss = yyssa;
  yytype_int16 *yyssp;

  /* The semantic value stack.  */
  YYSTYPE yyvsa[YYINITDEPTH];
  YYSTYPE *yyvs = yyvsa;
  YYSTYPE *yyvsp;

  /* The location stack.  */
  YYLTYPE yylsa[YYINITDEPTH];
  YYLTYPE *yyls = yylsa;
  YYLTYPE *yylsp;
  /* The locations where the error started and ended.  */
  YYLTYPE yyerror_range[2];

#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N), yylsp -= (N))

  YYSIZE_T yystacksize = YYINITDEPTH;

  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;
  YYLTYPE yyloc;

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss;
  yyvsp = yyvs;
  yylsp = yyls;
#if YYLTYPE_IS_TRIVIAL
  /* Initialize the default location before parsing starts.  */
  yylloc.first_line   = yylloc.last_line   = 1;
  yylloc.first_column = yylloc.last_column = 0;
#endif

  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack.  Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	yytype_int16 *yyss1 = yyss;
	YYLTYPE *yyls1 = yyls;

	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  This used to be a
	   conditional around just the two extra args, but that might
	   be undefined if yyoverflow is a macro.  */
	yyoverflow (YY_("memory exhausted"),
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),
		    &yyls1, yysize * sizeof (*yylsp),
		    &yystacksize);
	yyls = yyls1;
	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyexhaustedlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
	goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
	yystacksize = YYMAXDEPTH;

      {
	yytype_int16 *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyexhaustedlab;
	YYSTACK_RELOCATE (yyss);
	YYSTACK_RELOCATE (yyvs);
	YYSTACK_RELOCATE (yyls);
#  undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;
      yylsp = yyls + yysize - 1;

      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

  /* Do appropriate processing given the current state.  Read a
     look-ahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to look-ahead token.  */
  yyn = yypact[yystate];
  if (yyn == YYPACT_NINF)
    goto yydefault;

  /* Not known => get a look-ahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid look-ahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yyn == 0 || yyn == YYTABLE_NINF)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the look-ahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

  /* Discard the shifted token unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  yystate = yyn;
  *++yyvsp = yylval;
  *++yylsp = yylloc;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];

  /* Default location.  */
  YYLLOC_DEFAULT (yyloc, (yylsp - yylen), yylen);
  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 2:
#line 162 "chapel.ypp"
    { (void)(yylsp[(1) - (1)]).first_line; yyblock = (yyval.pblockstmt); ;}
    break;

  case 3:
#line 166 "chapel.ypp"
    { (yyval.pblockstmt) = new BlockStmt(); ;}
    break;

  case 4:
#line 167 "chapel.ypp"
    { (yyval.pblockstmt) = buildPragmaStmt((yyvsp[(1) - (3)].pblockstmt), (yyvsp[(2) - (3)].vpch), (yyvsp[(3) - (3)].pblockstmt)); ;}
    break;

  case 5:
#line 171 "chapel.ypp"
    { (yyval.vpch) = new Vec<const char*>(); ;}
    break;

  case 6:
#line 172 "chapel.ypp"
    { (yyvsp[(1) - (3)].vpch)->add(astr((yyvsp[(3) - (3)].pch))); ;}
    break;

  case 16:
#line 185 "chapel.ypp"
    { (yyval.pblockstmt) = buildAtomicStmt((yyvsp[(2) - (2)].pblockstmt)); ;}
    break;

  case 17:
#line 186 "chapel.ypp"
    { (yyval.pblockstmt) = buildBeginStmt((yyvsp[(2) - (2)].pblockstmt)); ;}
    break;

  case 18:
#line 187 "chapel.ypp"
    { (yyval.pblockstmt) = buildGotoStmt(GOTO_BREAK, (yyvsp[(2) - (3)].pch)); ;}
    break;

  case 19:
#line 188 "chapel.ypp"
    { (yyval.pblockstmt) = buildCobeginStmt((yyvsp[(2) - (2)].pblockstmt));  ;}
    break;

  case 20:
#line 189 "chapel.ypp"
    { (yyval.pblockstmt) = buildGotoStmt(GOTO_CONTINUE, (yyvsp[(2) - (3)].pch)); ;}
    break;

  case 21:
#line 190 "chapel.ypp"
    { (yyval.pblockstmt) = buildPrimitiveStmt(PRIM_DELETE, (yyvsp[(2) - (3)].pexpr)); ;}
    break;

  case 22:
#line 191 "chapel.ypp"
    { (yyval.pblockstmt) = buildChapelStmt((yyvsp[(1) - (2)].pexpr)); ;}
    break;

  case 23:
#line 192 "chapel.ypp"
    { (yyval.pblockstmt) = buildLabelStmt((yyvsp[(2) - (3)].pch), (yyvsp[(3) - (3)].pblockstmt)); ;}
    break;

  case 24:
#line 193 "chapel.ypp"
    { (yyval.pblockstmt) = buildLocalStmt((yyvsp[(2) - (2)].pblockstmt)); ;}
    break;

  case 25:
#line 194 "chapel.ypp"
    { (yyval.pblockstmt) = buildOnStmt((yyvsp[(2) - (3)].pexpr), (yyvsp[(3) - (3)].pblockstmt)); ;}
    break;

  case 26:
#line 195 "chapel.ypp"
    { (yyval.pblockstmt) = buildSerialStmt((yyvsp[(2) - (3)].pexpr), (yyvsp[(3) - (3)].pblockstmt)); ;}
    break;

  case 27:
#line 196 "chapel.ypp"
    { (yyval.pblockstmt) = buildSyncStmt((yyvsp[(2) - (2)].pblockstmt)); ;}
    break;

  case 28:
#line 197 "chapel.ypp"
    { (yyval.pblockstmt) = buildUseStmt((yyvsp[(2) - (3)].pcallexpr)); ;}
    break;

  case 29:
#line 198 "chapel.ypp"
    { (yyval.pblockstmt) = buildPrimitiveStmt(PRIM_YIELD, (yyvsp[(2) - (3)].pexpr)); ;}
    break;

  case 30:
#line 199 "chapel.ypp"
    { printf("syntax error"); clean_exit(1); ;}
    break;

  case 31:
#line 203 "chapel.ypp"
    { (yyval.pblockstmt) = buildAssignment((yyvsp[(1) - (4)].pexpr), (yyvsp[(3) - (4)].pexpr)); ;}
    break;

  case 32:
#line 204 "chapel.ypp"
    { (yyval.pblockstmt) = buildAssignment((yyvsp[(1) - (4)].pexpr), (yyvsp[(3) - (4)].pexpr), "+"); ;}
    break;

  case 33:
#line 205 "chapel.ypp"
    { (yyval.pblockstmt) = buildAssignment((yyvsp[(1) - (4)].pexpr), (yyvsp[(3) - (4)].pexpr), "-"); ;}
    break;

  case 34:
#line 206 "chapel.ypp"
    { (yyval.pblockstmt) = buildAssignment((yyvsp[(1) - (4)].pexpr), (yyvsp[(3) - (4)].pexpr), "*"); ;}
    break;

  case 35:
#line 207 "chapel.ypp"
    { (yyval.pblockstmt) = buildAssignment((yyvsp[(1) - (4)].pexpr), (yyvsp[(3) - (4)].pexpr), "/"); ;}
    break;

  case 36:
#line 208 "chapel.ypp"
    { (yyval.pblockstmt) = buildAssignment((yyvsp[(1) - (4)].pexpr), (yyvsp[(3) - (4)].pexpr), "%"); ;}
    break;

  case 37:
#line 209 "chapel.ypp"
    { (yyval.pblockstmt) = buildAssignment((yyvsp[(1) - (4)].pexpr), (yyvsp[(3) - (4)].pexpr), "**"); ;}
    break;

  case 38:
#line 210 "chapel.ypp"
    { (yyval.pblockstmt) = buildAssignment((yyvsp[(1) - (4)].pexpr), (yyvsp[(3) - (4)].pexpr), "&"); ;}
    break;

  case 39:
#line 211 "chapel.ypp"
    { (yyval.pblockstmt) = buildAssignment((yyvsp[(1) - (4)].pexpr), (yyvsp[(3) - (4)].pexpr), "|"); ;}
    break;

  case 40:
#line 212 "chapel.ypp"
    { (yyval.pblockstmt) = buildAssignment((yyvsp[(1) - (4)].pexpr), (yyvsp[(3) - (4)].pexpr), "^"); ;}
    break;

  case 41:
#line 213 "chapel.ypp"
    { (yyval.pblockstmt) = buildLAndAssignment((yyvsp[(1) - (4)].pexpr), (yyvsp[(3) - (4)].pexpr)); ;}
    break;

  case 42:
#line 214 "chapel.ypp"
    { (yyval.pblockstmt) = buildLOrAssignment((yyvsp[(1) - (4)].pexpr), (yyvsp[(3) - (4)].pexpr)); ;}
    break;

  case 43:
#line 215 "chapel.ypp"
    { (yyval.pblockstmt) = buildAssignment((yyvsp[(1) - (4)].pexpr), (yyvsp[(3) - (4)].pexpr), ">>"); ;}
    break;

  case 44:
#line 216 "chapel.ypp"
    { (yyval.pblockstmt) = buildAssignment((yyvsp[(1) - (4)].pexpr), (yyvsp[(3) - (4)].pexpr), "<<"); ;}
    break;

  case 45:
#line 217 "chapel.ypp"
    { (yyval.pblockstmt) = buildSwapStmt((yyvsp[(1) - (4)].pexpr), (yyvsp[(3) - (4)].pexpr)); ;}
    break;

  case 46:
#line 221 "chapel.ypp"
    { (yyval.pblockstmt) = buildChapelStmt((yyvsp[(2) - (3)].pblockstmt)); ;}
    break;

  case 47:
#line 225 "chapel.ypp"
    { (yyval.pch) = NULL; ;}
    break;

  case 49:
#line 230 "chapel.ypp"
    { (yyval.pch) = astr(yytext); ;}
    break;

  case 50:
#line 234 "chapel.ypp"
    { (yyval.pblockstmt) = (yyvsp[(2) - (2)].pblockstmt); ;}
    break;

  case 51:
#line 235 "chapel.ypp"
    { (yyval.pblockstmt) = (yyvsp[(1) - (1)].pblockstmt); ;}
    break;

  case 52:
#line 239 "chapel.ypp"
    { (yyval.pblockstmt) = buildPrimitiveStmt(PRIM_RETURN, new SymExpr(gVoid)); ;}
    break;

  case 53:
#line 240 "chapel.ypp"
    { (yyval.pblockstmt) = buildPrimitiveStmt(PRIM_RETURN, (yyvsp[(2) - (3)].pexpr)); ;}
    break;

  case 54:
#line 244 "chapel.ypp"
    { (yyval.pblockstmt) = buildChapelStmt(new BlockStmt()); ;}
    break;

  case 60:
#line 253 "chapel.ypp"
    { (yyval.pblockstmt) = buildDoWhileLoopStmt((yyvsp[(4) - (5)].pexpr), (yyvsp[(2) - (5)].pblockstmt)); ;}
    break;

  case 61:
#line 254 "chapel.ypp"
    { (yyval.pblockstmt) = buildWhileDoLoopStmt((yyvsp[(2) - (3)].pexpr), (yyvsp[(3) - (3)].pblockstmt)); ;}
    break;

  case 62:
#line 255 "chapel.ypp"
    { (yyval.pblockstmt) = buildCoforallLoopStmt((yyvsp[(2) - (5)].pexpr), (yyvsp[(4) - (5)].pexpr), (yyvsp[(5) - (5)].pblockstmt)); ;}
    break;

  case 63:
#line 256 "chapel.ypp"
    { (yyval.pblockstmt) = buildCoforallLoopStmt(NULL, (yyvsp[(2) - (3)].pexpr), (yyvsp[(3) - (3)].pblockstmt)); ;}
    break;

  case 64:
#line 257 "chapel.ypp"
    { (yyval.pblockstmt) = buildForLoopStmt((yyvsp[(2) - (5)].pexpr), (yyvsp[(4) - (5)].pexpr), (yyvsp[(5) - (5)].pblockstmt)); ;}
    break;

  case 65:
#line 258 "chapel.ypp"
    { (yyval.pblockstmt) = buildForLoopStmt(NULL, (yyvsp[(2) - (3)].pexpr), (yyvsp[(3) - (3)].pblockstmt)); ;}
    break;

  case 66:
#line 259 "chapel.ypp"
    { (yyval.pblockstmt) = buildParamForLoopStmt((yyvsp[(3) - (6)].pch), (yyvsp[(5) - (6)].pexpr), (yyvsp[(6) - (6)].pblockstmt)); ;}
    break;

  case 67:
#line 260 "chapel.ypp"
    { (yyval.pblockstmt) = buildForallLoopStmt((yyvsp[(2) - (5)].pexpr), (yyvsp[(4) - (5)].pexpr), (yyvsp[(5) - (5)].pblockstmt)); ;}
    break;

  case 68:
#line 261 "chapel.ypp"
    { (yyval.pblockstmt) = buildForallLoopStmt(NULL, (yyvsp[(2) - (3)].pexpr), (yyvsp[(3) - (3)].pblockstmt)); ;}
    break;

  case 69:
#line 263 "chapel.ypp"
    {
      if ((yyvsp[(2) - (6)].pcallexpr)->argList.length != 1)
        USR_FATAL((yyvsp[(4) - (6)].pexpr), "invalid index expression");
      (yyval.pblockstmt) = buildForallLoopStmt((yyvsp[(2) - (6)].pcallexpr)->get(1)->remove(), (yyvsp[(4) - (6)].pexpr), new BlockStmt((yyvsp[(6) - (6)].pblockstmt)));
    ;}
    break;

  case 70:
#line 269 "chapel.ypp"
    {
      if ((yyvsp[(2) - (4)].pcallexpr)->argList.length > 1)
        (yyval.pblockstmt) = buildForallLoopStmt(NULL, new CallExpr("chpl__buildDomainExpr", (yyvsp[(2) - (4)].pcallexpr)), new BlockStmt((yyvsp[(4) - (4)].pblockstmt)));
      else
        (yyval.pblockstmt) = buildForallLoopStmt(NULL, (yyvsp[(2) - (4)].pcallexpr)->get(1)->remove(), new BlockStmt((yyvsp[(4) - (4)].pblockstmt)));
    ;}
    break;

  case 71:
#line 279 "chapel.ypp"
    { (yyval.pblockstmt) = buildIfStmt((yyvsp[(2) - (4)].pexpr), (yyvsp[(4) - (4)].pblockstmt)); ;}
    break;

  case 72:
#line 280 "chapel.ypp"
    { (yyval.pblockstmt) = buildIfStmt((yyvsp[(2) - (3)].pexpr), (yyvsp[(3) - (3)].pblockstmt)); ;}
    break;

  case 73:
#line 281 "chapel.ypp"
    { (yyval.pblockstmt) = buildIfStmt((yyvsp[(2) - (6)].pexpr), (yyvsp[(4) - (6)].pblockstmt), (yyvsp[(6) - (6)].pblockstmt)); ;}
    break;

  case 74:
#line 282 "chapel.ypp"
    { (yyval.pblockstmt) = buildIfStmt((yyvsp[(2) - (5)].pexpr), (yyvsp[(3) - (5)].pblockstmt), (yyvsp[(5) - (5)].pblockstmt)); ;}
    break;

  case 75:
#line 287 "chapel.ypp"
    { (yyval.pblockstmt) = buildChapelStmt(buildSelectStmt((yyvsp[(2) - (5)].pexpr), (yyvsp[(4) - (5)].pblockstmt))); ;}
    break;

  case 76:
#line 291 "chapel.ypp"
    { (yyval.pblockstmt) = buildChapelStmt(); ;}
    break;

  case 77:
#line 292 "chapel.ypp"
    { (yyvsp[(1) - (2)].pblockstmt)->insertAtTail((yyvsp[(2) - (2)].pexpr)); ;}
    break;

  case 78:
#line 297 "chapel.ypp"
    { (yyval.pexpr) = new CondStmt(new CallExpr(PRIM_WHEN, (yyvsp[(2) - (3)].pcallexpr)), (yyvsp[(3) - (3)].pblockstmt)); ;}
    break;

  case 79:
#line 299 "chapel.ypp"
    { (yyval.pexpr) = new CondStmt(new CallExpr(PRIM_WHEN), (yyvsp[(2) - (2)].pblockstmt)); ;}
    break;

  case 80:
#line 304 "chapel.ypp"
    { (yyval.pblockstmt) = buildTypeSelectStmt((yyvsp[(3) - (6)].pcallexpr), (yyvsp[(5) - (6)].pblockstmt)); ;}
    break;

  case 81:
#line 311 "chapel.ypp"
    { (yyval.pblockstmt) = buildChapelStmt(buildClassDefExpr((yyvsp[(3) - (7)].pch), (yyvsp[(2) - (7)].ptype), (yyvsp[(4) - (7)].pcallexpr), (yyvsp[(6) - (7)].pblockstmt), (yyvsp[(1) - (7)].b))); ;}
    break;

  case 82:
#line 315 "chapel.ypp"
    { (yyval.b) = false; ;}
    break;

  case 83:
#line 316 "chapel.ypp"
    { (yyval.b) = true; ;}
    break;

  case 84:
#line 320 "chapel.ypp"
    { (yyval.ptype) = new ClassType(CLASS_CLASS); ;}
    break;

  case 85:
#line 321 "chapel.ypp"
    { (yyval.ptype) = new ClassType(CLASS_RECORD); ;}
    break;

  case 86:
#line 322 "chapel.ypp"
    { (yyval.ptype) = new ClassType(CLASS_UNION); ;}
    break;

  case 87:
#line 326 "chapel.ypp"
    { (yyval.pcallexpr) = new CallExpr(PRIM_ACTUALS_LIST); ;}
    break;

  case 88:
#line 327 "chapel.ypp"
    { (yyval.pcallexpr) = (yyvsp[(2) - (2)].pcallexpr); ;}
    break;

  case 89:
#line 332 "chapel.ypp"
    { (yyval.pblockstmt) = new BlockStmt(); ;}
    break;

  case 90:
#line 334 "chapel.ypp"
    { (yyval.pblockstmt) = buildPragmaStmt((yyvsp[(1) - (3)].pblockstmt), (yyvsp[(2) - (3)].vpch), (yyvsp[(3) - (3)].pblockstmt)); ;}
    break;

  case 91:
#line 339 "chapel.ypp"
    {
      EnumType* pdt = (yyvsp[(4) - (6)].penumtype);
      TypeSymbol* pst = new TypeSymbol((yyvsp[(2) - (6)].pch), pdt);
      (yyvsp[(4) - (6)].penumtype)->symbol = pst;
      (yyval.pblockstmt) = buildChapelStmt(new DefExpr(pst));
    ;}
    break;

  case 92:
#line 349 "chapel.ypp"
    {
      (yyval.penumtype) = new EnumType();
      (yyvsp[(1) - (1)].pdefexpr)->sym->type = (yyval.penumtype);
      (yyval.penumtype)->constants.insertAtTail((yyvsp[(1) - (1)].pdefexpr));
      (yyval.penumtype)->defaultValue = (yyvsp[(1) - (1)].pdefexpr)->sym;
    ;}
    break;

  case 93:
#line 356 "chapel.ypp"
    {
      (yyvsp[(1) - (3)].penumtype)->constants.insertAtTail((yyvsp[(3) - (3)].pdefexpr));
      (yyvsp[(3) - (3)].pdefexpr)->sym->type = (yyvsp[(1) - (3)].penumtype);
    ;}
    break;

  case 94:
#line 363 "chapel.ypp"
    { (yyval.pdefexpr) = new DefExpr(new EnumSymbol((yyvsp[(1) - (1)].pch))); ;}
    break;

  case 95:
#line 364 "chapel.ypp"
    { (yyval.pdefexpr) = new DefExpr(new EnumSymbol((yyvsp[(1) - (3)].pch)), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 97:
#line 370 "chapel.ypp"
    {
      captureTokens = 1;
      captureString[0] = '\0';
    ;}
    break;

  case 98:
#line 375 "chapel.ypp"
    {
      captureTokens = 0;
      (yyvsp[(3) - (3)].pfnsymbol)->userString = astr(captureString);
    ;}
    break;

  case 99:
#line 380 "chapel.ypp"
    {
      (yyvsp[(3) - (8)].pfnsymbol)->retTag = (yyvsp[(5) - (8)].retTag);
      if ((yyvsp[(5) - (8)].retTag) == RET_VAR)
        (yyvsp[(3) - (8)].pfnsymbol)->setter = new DefExpr(new ArgSymbol(INTENT_BLANK, "setter", dtBool));
      if ((yyvsp[(6) - (8)].pexpr))
        (yyvsp[(3) - (8)].pfnsymbol)->retExprType = new BlockStmt((yyvsp[(6) - (8)].pexpr), BLOCK_SCOPELESS);
      if ((yyvsp[(7) - (8)].pexpr))
        (yyvsp[(3) - (8)].pfnsymbol)->where = new BlockStmt((yyvsp[(7) - (8)].pexpr));
      (yyvsp[(3) - (8)].pfnsymbol)->insertAtTail((yyvsp[(8) - (8)].pblockstmt));
      (yyval.pblockstmt) = buildChapelStmt(new DefExpr((yyvsp[(3) - (8)].pfnsymbol)));
    ;}
    break;

  case 100:
#line 395 "chapel.ypp"
    {
      FnSymbol* fn = (yyvsp[(3) - (5)].pfnsymbol);
      fn->addFlag(FLAG_EXTERN);
      if ((yyvsp[(4) - (5)].pexpr))
        fn->retExprType = new BlockStmt((yyvsp[(4) - (5)].pexpr), BLOCK_SCOPELESS);
      else
        fn->retType = dtVoid;
      (yyval.pblockstmt) = buildChapelStmt(new DefExpr(fn));
    ;}
    break;

  case 101:
#line 408 "chapel.ypp"
    {
      (yyval.pfnsymbol) = (yyvsp[(2) - (2)].pfnsymbol);
      (yyval.pfnsymbol)->name = astr((yyvsp[(1) - (2)].pch));
      (yyval.pfnsymbol)->cname = (yyval.pfnsymbol)->name;
      if ((yyvsp[(1) - (2)].pch)[0] == '~' && (yyvsp[(1) - (2)].pch)[1] != '\0')
        (yyval.pfnsymbol)->addFlag(FLAG_DESTRUCTOR);
    ;}
    break;

  case 102:
#line 416 "chapel.ypp"
    {
      (yyval.pfnsymbol) = (yyvsp[(4) - (4)].pfnsymbol);
      (yyval.pfnsymbol)->name = astr((yyvsp[(3) - (4)].pch));
      (yyval.pfnsymbol)->cname = (yyval.pfnsymbol)->name;
      if ((yyvsp[(3) - (4)].pch)[0] == '~' && (yyvsp[(3) - (4)].pch)[1] != '\0')
        (yyval.pfnsymbol)->addFlag(FLAG_DESTRUCTOR);
      (yyval.pfnsymbol)->_this = new ArgSymbol(INTENT_BLANK, "this", dtUnknown, new UnresolvedSymExpr((yyvsp[(1) - (4)].pch)));
      (yyval.pfnsymbol)->insertFormalAtHead(new DefExpr((yyval.pfnsymbol)->_this));
      (yyval.pfnsymbol)->insertFormalAtHead(new DefExpr(new ArgSymbol(INTENT_BLANK, "_mt", dtMethodToken)));
    ;}
    break;

  case 104:
#line 430 "chapel.ypp"
    { (yyval.pch) = astr("~", (yyvsp[(2) - (2)].pch)); ;}
    break;

  case 105:
#line 431 "chapel.ypp"
    { (yyval.pch) = "="; ;}
    break;

  case 106:
#line 432 "chapel.ypp"
    { (yyval.pch) = "&"; ;}
    break;

  case 107:
#line 433 "chapel.ypp"
    { (yyval.pch) = "|"; ;}
    break;

  case 108:
#line 434 "chapel.ypp"
    { (yyval.pch) = "^"; ;}
    break;

  case 109:
#line 435 "chapel.ypp"
    { (yyval.pch) = "~"; ;}
    break;

  case 110:
#line 436 "chapel.ypp"
    { (yyval.pch) = "=="; ;}
    break;

  case 111:
#line 437 "chapel.ypp"
    { (yyval.pch) = "!="; ;}
    break;

  case 112:
#line 438 "chapel.ypp"
    { (yyval.pch) = "<="; ;}
    break;

  case 113:
#line 439 "chapel.ypp"
    { (yyval.pch) = ">="; ;}
    break;

  case 114:
#line 440 "chapel.ypp"
    { (yyval.pch) = "<"; ;}
    break;

  case 115:
#line 441 "chapel.ypp"
    { (yyval.pch) = ">"; ;}
    break;

  case 116:
#line 442 "chapel.ypp"
    { (yyval.pch) = "+"; ;}
    break;

  case 117:
#line 443 "chapel.ypp"
    { (yyval.pch) = "-"; ;}
    break;

  case 118:
#line 444 "chapel.ypp"
    { (yyval.pch) = "*"; ;}
    break;

  case 119:
#line 445 "chapel.ypp"
    { (yyval.pch) = "/"; ;}
    break;

  case 120:
#line 446 "chapel.ypp"
    { (yyval.pch) = "<<"; ;}
    break;

  case 121:
#line 447 "chapel.ypp"
    { (yyval.pch) = ">>"; ;}
    break;

  case 122:
#line 448 "chapel.ypp"
    { (yyval.pch) = "%"; ;}
    break;

  case 123:
#line 449 "chapel.ypp"
    { (yyval.pch) = "**"; ;}
    break;

  case 124:
#line 450 "chapel.ypp"
    { (yyval.pch) = "!"; ;}
    break;

  case 125:
#line 451 "chapel.ypp"
    { (yyval.pch) = "by"; ;}
    break;

  case 126:
#line 452 "chapel.ypp"
    { (yyval.pch) = "#"; ;}
    break;

  case 127:
#line 456 "chapel.ypp"
    { (yyval.pfnsymbol) = new FnSymbol("_"); (yyval.pfnsymbol)->addFlag(FLAG_NO_PARENS); ;}
    break;

  case 128:
#line 457 "chapel.ypp"
    { (yyval.pfnsymbol) = (yyvsp[(2) - (3)].pfnsymbol); ;}
    break;

  case 129:
#line 461 "chapel.ypp"
    { (yyval.pfnsymbol) = buildFunctionFormal(NULL, NULL); ;}
    break;

  case 130:
#line 462 "chapel.ypp"
    { (yyval.pfnsymbol) = buildFunctionFormal(NULL, (yyvsp[(1) - (1)].pdefexpr)); ;}
    break;

  case 131:
#line 463 "chapel.ypp"
    { (yyval.pfnsymbol) = buildFunctionFormal((yyvsp[(1) - (3)].pfnsymbol), (yyvsp[(3) - (3)].pdefexpr)); ;}
    break;

  case 132:
#line 468 "chapel.ypp"
    { (yyval.pdefexpr) = buildArgDefExpr((yyvsp[(1) - (4)].pt), (yyvsp[(2) - (4)].pch), (yyvsp[(3) - (4)].pexpr), (yyvsp[(4) - (4)].pexpr), NULL); ;}
    break;

  case 133:
#line 470 "chapel.ypp"
    { (yyval.pdefexpr) = buildArgDefExpr((yyvsp[(1) - (4)].pt), (yyvsp[(2) - (4)].pch), (yyvsp[(3) - (4)].pexpr), NULL, (yyvsp[(4) - (4)].pexpr)); ;}
    break;

  case 134:
#line 472 "chapel.ypp"
    { (yyval.pdefexpr) = buildTupleArgDefExpr((yyvsp[(1) - (6)].pt), (yyvsp[(3) - (6)].pblockstmt), (yyvsp[(5) - (6)].pexpr), (yyvsp[(6) - (6)].pexpr)); ;}
    break;

  case 135:
#line 474 "chapel.ypp"
    { USR_FATAL("variable-length argument may not be grouped in a tuple"); ;}
    break;

  case 136:
#line 478 "chapel.ypp"
    { (yyval.pt) = INTENT_BLANK; ;}
    break;

  case 137:
#line 479 "chapel.ypp"
    { (yyval.pt) = INTENT_IN; ;}
    break;

  case 138:
#line 480 "chapel.ypp"
    { (yyval.pt) = INTENT_INOUT; ;}
    break;

  case 139:
#line 481 "chapel.ypp"
    { (yyval.pt) = INTENT_OUT; ;}
    break;

  case 140:
#line 482 "chapel.ypp"
    { (yyval.pt) = INTENT_CONST; ;}
    break;

  case 141:
#line 483 "chapel.ypp"
    { (yyval.pt) = INTENT_PARAM; ;}
    break;

  case 142:
#line 484 "chapel.ypp"
    { (yyval.pt) = INTENT_TYPE; ;}
    break;

  case 143:
#line 488 "chapel.ypp"
    { (yyval.retTag) = RET_VALUE; ;}
    break;

  case 144:
#line 489 "chapel.ypp"
    { (yyval.retTag) = RET_VALUE; ;}
    break;

  case 145:
#line 490 "chapel.ypp"
    { (yyval.retTag) = RET_VAR; ;}
    break;

  case 146:
#line 491 "chapel.ypp"
    { (yyval.retTag) = RET_PARAM; ;}
    break;

  case 147:
#line 492 "chapel.ypp"
    { (yyval.retTag) = RET_TYPE; ;}
    break;

  case 149:
#line 497 "chapel.ypp"
    { (yyval.pblockstmt) = new BlockStmt((yyvsp[(1) - (1)].pblockstmt)); ;}
    break;

  case 150:
#line 502 "chapel.ypp"
    { (yyval.pdefexpr) = new DefExpr(new VarSymbol((yyvsp[(2) - (2)].pch))); ;}
    break;

  case 151:
#line 504 "chapel.ypp"
    { (yyval.pdefexpr) = new DefExpr(new VarSymbol(astr("chpl__query", istr(query_uid++)))); ;}
    break;

  case 152:
#line 508 "chapel.ypp"
    { (yyval.pdefexpr) = new DefExpr(new VarSymbol(astr("chpl__query", istr(query_uid++)))); ;}
    break;

  case 154:
#line 513 "chapel.ypp"
    { (yyval.pexpr) = (yyvsp[(2) - (2)].pexpr); ;}
    break;

  case 155:
#line 514 "chapel.ypp"
    { (yyvsp[(2) - (2)].pdefexpr)->sym->addFlag(FLAG_PARAM); (yyval.pexpr) = (yyvsp[(2) - (2)].pdefexpr); ;}
    break;

  case 156:
#line 518 "chapel.ypp"
    { (yyval.pexpr) = NULL; ;}
    break;

  case 157:
#line 519 "chapel.ypp"
    { (yyval.pexpr) = (yyvsp[(2) - (2)].pexpr); ;}
    break;

  case 158:
#line 524 "chapel.ypp"
    { (yyval.pblockstmt) = buildChapelStmt(new DefExpr(buildModule((yyvsp[(2) - (5)].pch), (yyvsp[(4) - (5)].pblockstmt), yyfilename))); ;}
    break;

  case 159:
#line 528 "chapel.ypp"
    { (yyval.pblockstmt) = (yyvsp[(2) - (3)].pblockstmt); ;}
    break;

  case 160:
#line 533 "chapel.ypp"
    {
      VarSymbol* var = new VarSymbol((yyvsp[(1) - (2)].pch));
      var->addFlag(FLAG_TYPE_VARIABLE);
      DefExpr* def = new DefExpr(var, (yyvsp[(2) - (2)].pexpr));
      (yyval.pblockstmt) = buildChapelStmt(def);
    ;}
    break;

  case 161:
#line 540 "chapel.ypp"
    {
      VarSymbol* var = new VarSymbol((yyvsp[(1) - (4)].pch));
      var->addFlag(FLAG_TYPE_VARIABLE);
      DefExpr* def = new DefExpr(var, (yyvsp[(2) - (4)].pexpr));
      (yyvsp[(4) - (4)].pblockstmt)->insertAtHead(def);
      (yyval.pblockstmt) = buildChapelStmt((yyvsp[(4) - (4)].pblockstmt));
    ;}
    break;

  case 162:
#line 550 "chapel.ypp"
    { (yyval.pexpr) = NULL; ;}
    break;

  case 163:
#line 551 "chapel.ypp"
    { (yyval.pexpr) = (yyvsp[(2) - (2)].pexpr); ;}
    break;

  case 164:
#line 556 "chapel.ypp"
    { (yyval.pblockstmt) = buildVarDecls((yyvsp[(3) - (4)].pblockstmt), (yyvsp[(1) - (4)].b), true, false); ;}
    break;

  case 165:
#line 558 "chapel.ypp"
    { (yyval.pblockstmt) = buildVarDecls((yyvsp[(3) - (4)].pblockstmt), (yyvsp[(1) - (4)].b), false, true); ;}
    break;

  case 166:
#line 560 "chapel.ypp"
    { (yyval.pblockstmt) = buildVarDecls((yyvsp[(3) - (4)].pblockstmt), (yyvsp[(1) - (4)].b), false, false); ;}
    break;

  case 167:
#line 564 "chapel.ypp"
    { (yyval.b) = false; ;}
    break;

  case 168:
#line 565 "chapel.ypp"
    { (yyval.b) = true; ;}
    break;

  case 170:
#line 571 "chapel.ypp"
    {
      for_alist(expr, (yyvsp[(3) - (3)].pblockstmt)->body)
        (yyvsp[(1) - (3)].pblockstmt)->insertAtTail(expr->remove());
    ;}
    break;

  case 171:
#line 579 "chapel.ypp"
    {
      VarSymbol* var = new VarSymbol((yyvsp[(1) - (3)].pch));
      (yyval.pblockstmt) = buildChapelStmt(new DefExpr(var, (yyvsp[(3) - (3)].pexpr), (yyvsp[(2) - (3)].pexpr)));
    ;}
    break;

  case 172:
#line 584 "chapel.ypp"
    {
      VarSymbol* var = new VarSymbol((yyvsp[(1) - (4)].pch));
      var->addFlag(FLAG_ARRAY_ALIAS);
      (yyval.pblockstmt) = buildChapelStmt(new DefExpr(var, (yyvsp[(4) - (4)].pexpr), (yyvsp[(2) - (4)].pexpr)));
    ;}
    break;

  case 173:
#line 590 "chapel.ypp"
    { (yyval.pblockstmt) = buildTupleVarDeclStmt((yyvsp[(2) - (5)].pblockstmt), (yyvsp[(4) - (5)].pexpr), (yyvsp[(5) - (5)].pexpr)); ;}
    break;

  case 174:
#line 594 "chapel.ypp"
    { (yyval.pblockstmt) = buildChapelStmt(new DefExpr(new VarSymbol("chpl__tuple_blank"))); ;}
    break;

  case 175:
#line 596 "chapel.ypp"
    { (yyval.pblockstmt) = buildChapelStmt(new DefExpr(new VarSymbol((yyvsp[(1) - (1)].pch)))); ;}
    break;

  case 176:
#line 598 "chapel.ypp"
    { (yyval.pblockstmt) = buildChapelStmt((yyvsp[(2) - (3)].pblockstmt)); ;}
    break;

  case 177:
#line 600 "chapel.ypp"
    { (yyvsp[(1) - (2)].pblockstmt)->insertAtTail(new DefExpr(new VarSymbol("chpl__tuple_blank"))); ;}
    break;

  case 178:
#line 602 "chapel.ypp"
    { (yyvsp[(1) - (3)].pblockstmt)->insertAtTail(new DefExpr(new VarSymbol((yyvsp[(3) - (3)].pch)))); ;}
    break;

  case 179:
#line 604 "chapel.ypp"
    { (yyvsp[(1) - (5)].pblockstmt)->insertAtTail((yyvsp[(4) - (5)].pblockstmt)); ;}
    break;

  case 180:
#line 610 "chapel.ypp"
    { (yyval.pexpr) = NULL; ;}
    break;

  case 181:
#line 611 "chapel.ypp"
    { (yyval.pexpr) = (yyvsp[(2) - (2)].pexpr); ;}
    break;

  case 182:
#line 615 "chapel.ypp"
    { (yyval.pexpr) = NULL; ;}
    break;

  case 183:
#line 617 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("chpl__buildDomainExpr", (yyvsp[(3) - (4)].pcallexpr)); ;}
    break;

  case 184:
#line 621 "chapel.ypp"
    { (yyval.pexpr) = NULL; ;}
    break;

  case 185:
#line 622 "chapel.ypp"
    { (yyval.pexpr) = (yyvsp[(2) - (2)].pexpr); ;}
    break;

  case 186:
#line 623 "chapel.ypp"
    { (yyval.pexpr) = (yyvsp[(2) - (2)].pexpr); ;}
    break;

  case 187:
#line 628 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("chpl__buildArrayRuntimeType",
             new CallExpr("chpl__buildDomainExpr", (yyvsp[(2) - (4)].pcallexpr)), (yyvsp[(4) - (4)].pexpr)); ;}
    break;

  case 188:
#line 631 "chapel.ypp"
    { 
      if ((yyvsp[(2) - (6)].pcallexpr)->argList.length != 1)
        USR_FATAL((yyvsp[(4) - (6)].pexpr), "invalid index expression");
      (yyval.pexpr) = new CallExpr("chpl__buildArrayRuntimeType",
             new CallExpr("chpl__buildDomainExpr", (yyvsp[(4) - (6)].pexpr)), (yyvsp[(6) - (6)].pexpr), (yyvsp[(2) - (6)].pcallexpr)->get(1)->remove(),
             new CallExpr("chpl__buildDomainExpr", (yyvsp[(4) - (6)].pexpr)->copy()));
    ;}
    break;

  case 189:
#line 641 "chapel.ypp"
    { (yyval.pexpr) = NULL; ;}
    break;

  case 190:
#line 642 "chapel.ypp"
    { (yyval.pexpr) = (yyvsp[(1) - (1)].pexpr); ;}
    break;

  case 191:
#line 643 "chapel.ypp"
    { (yyval.pexpr) = (yyvsp[(1) - (1)].pdefexpr); ;}
    break;

  case 192:
#line 648 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("chpl__buildArrayRuntimeType", gNil, (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 193:
#line 650 "chapel.ypp"
    { (yyval.pexpr) = buildFormalArrayType((yyvsp[(2) - (4)].pcallexpr), (yyvsp[(4) - (4)].pexpr)); ;}
    break;

  case 194:
#line 652 "chapel.ypp"
    { (yyval.pexpr) = buildFormalArrayType((yyvsp[(4) - (6)].pexpr), (yyvsp[(6) - (6)].pexpr), (yyvsp[(2) - (6)].pcallexpr)); ;}
    break;

  case 195:
#line 656 "chapel.ypp"
    { (yyval.pexpr) = NULL; ;}
    break;

  case 196:
#line 657 "chapel.ypp"
    { (yyval.pexpr) = (yyvsp[(2) - (2)].pexpr); ;}
    break;

  case 197:
#line 658 "chapel.ypp"
    { (yyval.pexpr) = (yyvsp[(2) - (2)].pdefexpr); ;}
    break;

  case 198:
#line 659 "chapel.ypp"
    { (yyval.pexpr) = new UnresolvedSymExpr("_domain"); ;}
    break;

  case 199:
#line 660 "chapel.ypp"
    { (yyval.pexpr) = new UnresolvedSymExpr( "_singlevar"); ;}
    break;

  case 200:
#line 661 "chapel.ypp"
    { (yyval.pexpr) = new UnresolvedSymExpr( "_syncvar"); ;}
    break;

  case 201:
#line 662 "chapel.ypp"
    { (yyval.pexpr) = (yyvsp[(2) - (2)].pexpr); ;}
    break;

  case 202:
#line 668 "chapel.ypp"
    { (yyval.pcallexpr) = new CallExpr(PRIM_ACTUALS_LIST, (yyvsp[(1) - (1)].pexpr)); ;}
    break;

  case 203:
#line 669 "chapel.ypp"
    { (yyval.pcallexpr) = new CallExpr(PRIM_ACTUALS_LIST, (yyvsp[(1) - (1)].pdefexpr)); ;}
    break;

  case 204:
#line 670 "chapel.ypp"
    { (yyvsp[(1) - (3)].pcallexpr)->insertAtTail((yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 205:
#line 671 "chapel.ypp"
    { (yyvsp[(1) - (3)].pcallexpr)->insertAtTail((yyvsp[(3) - (3)].pdefexpr)); ;}
    break;

  case 206:
#line 675 "chapel.ypp"
    { (yyval.pcallexpr) = new CallExpr(PRIM_ACTUALS_LIST,
                                            new UnresolvedSymExpr("chpl__tuple_blank")); ;}
    break;

  case 207:
#line 677 "chapel.ypp"
    { (yyval.pcallexpr) = new CallExpr(PRIM_ACTUALS_LIST, (yyvsp[(1) - (1)].pexpr)); ;}
    break;

  case 208:
#line 678 "chapel.ypp"
    { (yyval.pcallexpr) = new CallExpr(PRIM_ACTUALS_LIST, (yyvsp[(1) - (1)].pdefexpr)); ;}
    break;

  case 209:
#line 679 "chapel.ypp"
    { (yyvsp[(1) - (2)].pcallexpr)->insertAtTail(
                                           new UnresolvedSymExpr("chpl__tuple_blank")); ;}
    break;

  case 210:
#line 681 "chapel.ypp"
    { (yyvsp[(1) - (3)].pcallexpr)->insertAtTail((yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 211:
#line 682 "chapel.ypp"
    { (yyvsp[(1) - (3)].pcallexpr)->insertAtTail((yyvsp[(3) - (3)].pdefexpr)); ;}
    break;

  case 212:
#line 686 "chapel.ypp"
    { (yyval.pcallexpr) = new CallExpr(PRIM_ACTUALS_LIST); ;}
    break;

  case 214:
#line 692 "chapel.ypp"
    { (yyval.pcallexpr) = new CallExpr(PRIM_ACTUALS_LIST, (yyvsp[(1) - (1)].pexpr)); ;}
    break;

  case 215:
#line 694 "chapel.ypp"
    { (yyvsp[(1) - (3)].pcallexpr)->insertAtTail((yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 216:
#line 698 "chapel.ypp"
    { (yyval.pexpr) = buildNamedActual((yyvsp[(1) - (3)].pch), (yyvsp[(3) - (3)].pdefexpr)); ;}
    break;

  case 217:
#line 699 "chapel.ypp"
    { (yyval.pexpr) = buildNamedActual((yyvsp[(1) - (3)].pch), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 218:
#line 700 "chapel.ypp"
    { (yyval.pexpr) = buildNamedAliasActual((yyvsp[(1) - (3)].pch), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 219:
#line 701 "chapel.ypp"
    { (yyval.pexpr) = (yyvsp[(1) - (1)].pdefexpr); ;}
    break;

  case 222:
#line 708 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("chpl__buildDomainExpr", (yyvsp[(2) - (3)].pcallexpr)); ;}
    break;

  case 223:
#line 710 "chapel.ypp"
    {
      if ((yyvsp[(2) - (6)].pcallexpr)->argList.length != 1)
        USR_FATAL((yyvsp[(4) - (6)].pexpr), "invalid index expression");
      (yyval.pexpr) = buildForallLoopExpr((yyvsp[(2) - (6)].pcallexpr)->get(1)->remove(), (yyvsp[(4) - (6)].pexpr), (yyvsp[(6) - (6)].pexpr), NULL, true);
    ;}
    break;

  case 224:
#line 716 "chapel.ypp"
    {
      if ((yyvsp[(2) - (4)].pcallexpr)->argList.length > 1)
        (yyval.pexpr) = buildForallLoopExpr(NULL, new CallExpr("chpl__buildDomainExpr", (yyvsp[(2) - (4)].pcallexpr)), (yyvsp[(4) - (4)].pexpr), NULL, true);
      else
        (yyval.pexpr) = buildForallLoopExpr(NULL, (yyvsp[(2) - (4)].pcallexpr)->get(1)->remove(), (yyvsp[(4) - (4)].pexpr), NULL, true);
    ;}
    break;

  case 225:
#line 723 "chapel.ypp"
    {
      if ((yyvsp[(2) - (9)].pcallexpr)->argList.length != 1)
        USR_FATAL((yyvsp[(4) - (9)].pexpr), "invalid index expression");
      (yyval.pexpr) = buildForallLoopExpr((yyvsp[(2) - (9)].pcallexpr)->get(1)->remove(), (yyvsp[(4) - (9)].pexpr), (yyvsp[(9) - (9)].pexpr), (yyvsp[(7) - (9)].pexpr));
    ;}
    break;

  case 226:
#line 729 "chapel.ypp"
    {
      if ((yyvsp[(2) - (7)].pcallexpr)->argList.length > 1)
        (yyval.pexpr) = buildForallLoopExpr(NULL, new CallExpr("chpl__buildDomainExpr", (yyvsp[(2) - (7)].pcallexpr)), (yyvsp[(7) - (7)].pexpr), (yyvsp[(5) - (7)].pexpr));
      else
        (yyval.pexpr) = buildForallLoopExpr(NULL, (yyvsp[(2) - (7)].pcallexpr)->get(1)->remove(), (yyvsp[(7) - (7)].pexpr), (yyvsp[(5) - (7)].pexpr));
    ;}
    break;

  case 228:
#line 740 "chapel.ypp"
    { (yyval.pexpr) = buildForLoopExpr((yyvsp[(2) - (6)].pexpr), (yyvsp[(4) - (6)].pexpr), (yyvsp[(6) - (6)].pexpr)); ;}
    break;

  case 229:
#line 742 "chapel.ypp"
    { (yyval.pexpr) = buildForLoopExpr(NULL, (yyvsp[(2) - (4)].pexpr), (yyvsp[(4) - (4)].pexpr)); ;}
    break;

  case 230:
#line 744 "chapel.ypp"
    { (yyval.pexpr) = buildForLoopExpr((yyvsp[(2) - (9)].pexpr), (yyvsp[(4) - (9)].pexpr), (yyvsp[(9) - (9)].pexpr), (yyvsp[(7) - (9)].pexpr)); ;}
    break;

  case 231:
#line 746 "chapel.ypp"
    { (yyval.pexpr) = buildForLoopExpr(NULL, (yyvsp[(2) - (7)].pexpr), (yyvsp[(7) - (7)].pexpr), (yyvsp[(5) - (7)].pexpr)); ;}
    break;

  case 232:
#line 748 "chapel.ypp"
    { (yyval.pexpr) = buildForallLoopExpr((yyvsp[(2) - (6)].pexpr), (yyvsp[(4) - (6)].pexpr), (yyvsp[(6) - (6)].pexpr)); ;}
    break;

  case 233:
#line 750 "chapel.ypp"
    { (yyval.pexpr) = buildForallLoopExpr(NULL, (yyvsp[(2) - (4)].pexpr), (yyvsp[(4) - (4)].pexpr)); ;}
    break;

  case 234:
#line 752 "chapel.ypp"
    { (yyval.pexpr) = buildForallLoopExpr((yyvsp[(2) - (9)].pexpr), (yyvsp[(4) - (9)].pexpr), (yyvsp[(9) - (9)].pexpr), (yyvsp[(7) - (9)].pexpr)); ;}
    break;

  case 235:
#line 754 "chapel.ypp"
    { (yyval.pexpr) = buildForallLoopExpr(NULL, (yyvsp[(2) - (7)].pexpr), (yyvsp[(7) - (7)].pexpr), (yyvsp[(5) - (7)].pexpr)); ;}
    break;

  case 236:
#line 756 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr(new DefExpr(buildIfExpr((yyvsp[(2) - (6)].pexpr), (yyvsp[(4) - (6)].pexpr), (yyvsp[(6) - (6)].pexpr)))); ;}
    break;

  case 237:
#line 758 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr( "_syncvar", (yyvsp[(2) - (2)].pexpr)); ;}
    break;

  case 242:
#line 767 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("chpl__buildDomainRuntimeType", new UnresolvedSymExpr("defaultDist"), (yyvsp[(3) - (4)].pcallexpr)); ;}
    break;

  case 243:
#line 769 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("chpl__buildSubDomainType", (yyvsp[(3) - (4)].pcallexpr)); ;}
    break;

  case 244:
#line 771 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("chpl__buildSparseDomainRuntimeType", new UnresolvedSymExpr("defaultDist"), (yyvsp[(4) - (5)].pcallexpr)); ;}
    break;

  case 245:
#line 773 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("chpl__buildIndexType", (yyvsp[(3) - (4)].pcallexpr)); ;}
    break;

  case 246:
#line 775 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr( "_singlevar", (yyvsp[(2) - (2)].pexpr)); ;}
    break;

  case 247:
#line 777 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr(PRIM_NEW, (yyvsp[(2) - (2)].pexpr)); ;}
    break;

  case 248:
#line 779 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr(PRIM_TUPLE_EXPAND, (yyvsp[(3) - (4)].pexpr)); ;}
    break;

  case 249:
#line 781 "chapel.ypp"
    { (yyval.pexpr) = new SymExpr(gNil); ;}
    break;

  case 250:
#line 783 "chapel.ypp"
    { (yyval.pexpr) = buildLetExpr((yyvsp[(2) - (4)].pblockstmt), (yyvsp[(4) - (4)].pexpr)); ;}
    break;

  case 253:
#line 787 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("_cast", (yyvsp[(3) - (3)].pexpr), (yyvsp[(1) - (3)].pexpr)); ;}
    break;

  case 254:
#line 789 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("_build_range", (yyvsp[(1) - (3)].pexpr), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 255:
#line 791 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("_build_range", buildDotExpr("BoundedRangeType", "boundedLow"), (yyvsp[(1) - (2)].pexpr)); ;}
    break;

  case 256:
#line 793 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("_build_range", buildDotExpr("BoundedRangeType", "boundedHigh"), (yyvsp[(2) - (2)].pexpr)); ;}
    break;

  case 257:
#line 795 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("_build_range", buildDotExpr("BoundedRangeType", "boundedNone")); ;}
    break;

  case 258:
#line 799 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("+", (yyvsp[(1) - (3)].pexpr), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 259:
#line 800 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("-", (yyvsp[(1) - (3)].pexpr), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 260:
#line 801 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("*", (yyvsp[(1) - (3)].pexpr), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 261:
#line 802 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("/", (yyvsp[(1) - (3)].pexpr), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 262:
#line 803 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("<<", (yyvsp[(1) - (3)].pexpr), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 263:
#line 804 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr(">>", (yyvsp[(1) - (3)].pexpr), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 264:
#line 805 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("%", (yyvsp[(1) - (3)].pexpr), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 265:
#line 806 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("==", (yyvsp[(1) - (3)].pexpr), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 266:
#line 807 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("!=", (yyvsp[(1) - (3)].pexpr), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 267:
#line 808 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("<=", (yyvsp[(1) - (3)].pexpr), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 268:
#line 809 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr(">=", (yyvsp[(1) - (3)].pexpr), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 269:
#line 810 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("<", (yyvsp[(1) - (3)].pexpr), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 270:
#line 811 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr(">", (yyvsp[(1) - (3)].pexpr), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 271:
#line 812 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("&", (yyvsp[(1) - (3)].pexpr), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 272:
#line 813 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("|", (yyvsp[(1) - (3)].pexpr), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 273:
#line 814 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("^", (yyvsp[(1) - (3)].pexpr), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 274:
#line 815 "chapel.ypp"
    { (yyval.pexpr) = buildLogicalAndExpr((yyvsp[(1) - (3)].pexpr), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 275:
#line 816 "chapel.ypp"
    { (yyval.pexpr) = buildLogicalOrExpr((yyvsp[(1) - (3)].pexpr), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 276:
#line 817 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("**", (yyvsp[(1) - (3)].pexpr), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 277:
#line 818 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("by", (yyvsp[(1) - (3)].pexpr), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 278:
#line 819 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("#", (yyvsp[(1) - (3)].pexpr), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 279:
#line 820 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("chpl__distributed", (yyvsp[(3) - (3)].pexpr), (yyvsp[(1) - (3)].pexpr)); ;}
    break;

  case 280:
#line 824 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("+", (yyvsp[(2) - (2)].pexpr)); ;}
    break;

  case 281:
#line 825 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("-", (yyvsp[(2) - (2)].pexpr)); ;}
    break;

  case 282:
#line 826 "chapel.ypp"
    { (yyval.pexpr) = buildPreDecIncWarning((yyvsp[(2) - (2)].pexpr), '-'); ;}
    break;

  case 283:
#line 827 "chapel.ypp"
    { (yyval.pexpr) = buildPreDecIncWarning((yyvsp[(2) - (2)].pexpr), '+'); ;}
    break;

  case 284:
#line 828 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("!", (yyvsp[(2) - (2)].pexpr)); ;}
    break;

  case 285:
#line 829 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("~", (yyvsp[(2) - (2)].pexpr)); ;}
    break;

  case 286:
#line 833 "chapel.ypp"
    { (yyval.pexpr) = new UnresolvedSymExpr((yyvsp[(1) - (1)].pch)); ;}
    break;

  case 290:
#line 840 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr((yyvsp[(1) - (4)].pexpr), (yyvsp[(3) - (4)].pcallexpr)); ;}
    break;

  case 291:
#line 841 "chapel.ypp"
    { (yyval.pexpr) = buildSquareCallExpr((yyvsp[(1) - (4)].pexpr), (yyvsp[(3) - (4)].pcallexpr)); ;}
    break;

  case 292:
#line 842 "chapel.ypp"
    { (yyval.pexpr) = buildPrimitiveExpr((yyvsp[(3) - (4)].pcallexpr)); ;}
    break;

  case 293:
#line 846 "chapel.ypp"
    { (yyval.pexpr) = buildDotExpr((yyvsp[(1) - (3)].pexpr), (yyvsp[(3) - (3)].pch)); ;}
    break;

  case 294:
#line 847 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr(PRIM_TYPEOF, (yyvsp[(1) - (3)].pexpr)); ;}
    break;

  case 295:
#line 848 "chapel.ypp"
    { (yyval.pexpr) = buildDotExpr((yyvsp[(1) - (3)].pexpr), "_dom"); ;}
    break;

  case 296:
#line 852 "chapel.ypp"
    { (yyval.pexpr) = buildParenExpr((yyvsp[(2) - (3)].pcallexpr)); ;}
    break;

  case 297:
#line 856 "chapel.ypp"
    { (yyval.pexpr) = buildIntLiteral(yytext); ;}
    break;

  case 298:
#line 857 "chapel.ypp"
    { (yyval.pexpr) = buildRealLiteral(yytext); ;}
    break;

  case 299:
#line 858 "chapel.ypp"
    { (yyval.pexpr) = buildImagLiteral(yytext); ;}
    break;

  case 300:
#line 859 "chapel.ypp"
    { (yyval.pexpr) = buildStringLiteral((yyvsp[(1) - (1)].pch)); ;}
    break;

  case 301:
#line 863 "chapel.ypp"
    { (yyval.pexpr) = buildReduceExpr((yyvsp[(1) - (3)].pexpr), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 302:
#line 864 "chapel.ypp"
    { (yyval.pexpr) = buildReduceExpr((yyvsp[(1) - (3)].pexpr), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 303:
#line 868 "chapel.ypp"
    { (yyval.pexpr) = buildScanExpr((yyvsp[(1) - (3)].pexpr), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 304:
#line 869 "chapel.ypp"
    { (yyval.pexpr) = buildScanExpr((yyvsp[(1) - (3)].pexpr), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 305:
#line 873 "chapel.ypp"
    { (yyval.pexpr) = new UnresolvedSymExpr("SumReduceScanOp"); ;}
    break;

  case 306:
#line 874 "chapel.ypp"
    { (yyval.pexpr) = new UnresolvedSymExpr("ProductReduceScanOp"); ;}
    break;

  case 307:
#line 875 "chapel.ypp"
    { (yyval.pexpr) = new UnresolvedSymExpr("LogicalAndReduceScanOp"); ;}
    break;

  case 308:
#line 876 "chapel.ypp"
    { (yyval.pexpr) = new UnresolvedSymExpr("LogicalOrReduceScanOp"); ;}
    break;

  case 309:
#line 877 "chapel.ypp"
    { (yyval.pexpr) = new UnresolvedSymExpr("BitwiseAndReduceScanOp"); ;}
    break;

  case 310:
#line 878 "chapel.ypp"
    { (yyval.pexpr) = new UnresolvedSymExpr("BitwiseOrReduceScanOp"); ;}
    break;

  case 311:
#line 879 "chapel.ypp"
    { (yyval.pexpr) = new UnresolvedSymExpr("BitwiseXorReduceScanOp"); ;}
    break;


/* Line 1267 of yacc.c.  */
#line 5016 "chapel.tab.cpp"
      default: break;
    }
  YY_SYMBOL_PRINT ("-> $$ =", yyr1[yyn], &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;
  *++yylsp = yyloc;

  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if ! YYERROR_VERBOSE
      yyerror (YY_("syntax error"));
#else
      {
	YYSIZE_T yysize = yysyntax_error (0, yystate, yychar);
	if (yymsg_alloc < yysize && yymsg_alloc < YYSTACK_ALLOC_MAXIMUM)
	  {
	    YYSIZE_T yyalloc = 2 * yysize;
	    if (! (yysize <= yyalloc && yyalloc <= YYSTACK_ALLOC_MAXIMUM))
	      yyalloc = YYSTACK_ALLOC_MAXIMUM;
	    if (yymsg != yymsgbuf)
	      YYSTACK_FREE (yymsg);
	    yymsg = (char *) YYSTACK_ALLOC (yyalloc);
	    if (yymsg)
	      yymsg_alloc = yyalloc;
	    else
	      {
		yymsg = yymsgbuf;
		yymsg_alloc = sizeof yymsgbuf;
	      }
	  }

	if (0 < yysize && yysize <= yymsg_alloc)
	  {
	    (void) yysyntax_error (yymsg, yystate, yychar);
	    yyerror (yymsg);
	  }
	else
	  {
	    yyerror (YY_("syntax error"));
	    if (yysize != 0)
	      goto yyexhaustedlab;
	  }
      }
#endif
    }

  yyerror_range[0] = yylloc;

  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse look-ahead token after an
	 error, discard it.  */

      if (yychar <= YYEOF)
	{
	  /* Return failure if at end of input.  */
	  if (yychar == YYEOF)
	    YYABORT;
	}
      else
	{
	  yydestruct ("Error: discarding",
		      yytoken, &yylval, &yylloc);
	  yychar = YYEMPTY;
	}
    }

  /* Else will try to reuse look-ahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

  /* Pacify compilers like GCC when the user code never invokes
     YYERROR and the label yyerrorlab therefore never appears in user
     code.  */
  if (/*CONSTCOND*/ 0)
     goto yyerrorlab;

  yyerror_range[0] = yylsp[1-yylen];
  /* Do not reclaim the symbols of the rule which action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;	/* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (yyn != YYPACT_NINF)
	{
	  yyn += YYTERROR;
	  if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
	    {
	      yyn = yytable[yyn];
	      if (0 < yyn)
		break;
	    }
	}

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
	YYABORT;

      yyerror_range[0] = *yylsp;
      yydestruct ("Error: popping",
		  yystos[yystate], yyvsp, yylsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  *++yyvsp = yylval;

  yyerror_range[1] = yylloc;
  /* Using YYLLOC is tempting, but would change the location of
     the look-ahead.  YYLOC is available though.  */
  YYLLOC_DEFAULT (yyloc, (yyerror_range - 1), 2);
  *++yylsp = yyloc;

  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#ifndef yyoverflow
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
  if (yychar != YYEOF && yychar != YYEMPTY)
     yydestruct ("Cleanup: discarding lookahead",
		 yytoken, &yylval, &yylloc);
  /* Do not reclaim the symbols of the rule which action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
		  yystos[*yyssp], yyvsp, yylsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
#if YYERROR_VERBOSE
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
#endif
  /* Make sure YYID is used.  */
  return YYID (yyresult);
}


#line 882 "chapel.ypp"


