/**************************************************************************
  Copyright (c) 2004-2010 Cray Inc.  (See LICENSE file for more details)
**************************************************************************/


#include <cstdio>
#include <cstdlib>
#include "yy.h"


void yyerror(const char *str) {
  fprintf(stderr, "%s:%d %s", yyfilename, chplLineno, str);
  if (strlen(yytext) > 0) {
    fprintf(stderr, ": near '%s'", yytext);
  }
  fprintf(stderr, "\n");
  clean_exit(1);
}
