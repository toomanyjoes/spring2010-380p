/**************************************************************************
  Copyright (c) 2004-2010 Cray Inc.  (See LICENSE file for more details)
**************************************************************************/


#ifndef _FREEBSD_STDINT_H_
#define _FREEBSD_STDINT_H_

// The existence of this file is a stupid hack because our FreeBSD
// platform doesn't seem to support stdint.h

#include <inttypes.h>

#endif
