/**************************************************************************
  Copyright (c) 2004-2010 Cray Inc.  (See LICENSE file for more details)
**************************************************************************/


#define IFA_EXTERN
#define IFA_EXTERN_INIT(_x) = _x
#include "log.h"
#include "num.h"

/* This file makes sure that global ifa variables are defined */
