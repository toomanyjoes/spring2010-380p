

typedef struct {
	int *data;
	int size;
} intArray;

intArray *readArray(char *fname);
