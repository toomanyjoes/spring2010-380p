/**************************************************************************
  Copyright (c) 2004-2009 Cray Inc.  (See LICENSE file for more details)
**************************************************************************/


#include <stdio.h>
#include "chplrt.h"
#include "gdb.h"

void gdbShouldBreakHere(void) {printf("%s", "");}
