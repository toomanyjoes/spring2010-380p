/**************************************************************************
  Copyright (c) 2004-2009 Cray Inc.  (See LICENSE file for more details)
**************************************************************************/


#ifndef _chplcomm_plat_md_h_
#define _chplcomm_plat_md_h_

#define GASNET_NEEDS_MAX_SEGSIZE

#endif
