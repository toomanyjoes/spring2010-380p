/**************************************************************************
  Copyright (c) 2004-2009 Cray Inc.  (See LICENSE file for more details)
**************************************************************************/


#ifndef _CHPL_MD_H_
#define _CHPL_MD_H_

#define DEFINE_32_BIT_MATH_FNS

#endif

