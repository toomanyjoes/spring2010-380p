/**************************************************************************
  Copyright (c) 2004-2009 Cray Inc.  (See LICENSE file for more details)
**************************************************************************/


#ifndef CHPLIO_MD_H
#define CHPLIO_MD_H

#define PRINTF_DEF printf

#endif
