/**************************************************************************
  Copyright (c) 2004-2009 Cray Inc.  (See LICENSE file for more details)
**************************************************************************/


#ifndef _GDB_H_
#define _GDB_H_

void gdbShouldBreakHere(void);  // must be in separate file to avoid elimination

#endif
