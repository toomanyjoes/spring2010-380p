/**************************************************************************
  Copyright (c) 2004-2009 Cray Inc.  (See LICENSE file for more details)
**************************************************************************/


#ifndef _chplcomm_comm_md_h_
#define _chplcomm_comm_md_h_


void chpl_comm_gasnet_help_register_global_var(int i, void* wide);

#define CHPL_HEAP_REGISTER_GLOBAL_VAR_EXTRA(i, wide) \
  chpl_comm_gasnet_help_register_global_var(i, (wide).addr);

#endif

