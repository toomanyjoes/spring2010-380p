/**************************************************************************
  Copyright (c) 2004-2009 Cray Inc.  (See LICENSE file for more details)
**************************************************************************/


#ifndef _CHPL_MD_H_
#define _CHPL_MD_H_

/* Any platform-specific settings should be made in versions of this
   file pushed down one level. */

#endif
