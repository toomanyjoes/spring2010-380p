/* A Bison parser, made by GNU Bison 2.3.  */

/* Skeleton interface for Bison's Yacc-like parsers in C

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     TATOMIC = 258,
     TBEGIN = 259,
     TBREAK = 260,
     TCLASS = 261,
     TCOBEGIN = 262,
     TCOFORALL = 263,
     TCONFIG = 264,
     TCONST = 265,
     TCONTINUE = 266,
     TDEF = 267,
     TDELETE = 268,
     TDISTRIBUTED = 269,
     TDO = 270,
     TDOMAIN = 271,
     TENUM = 272,
     TEXTERN = 273,
     TFOR = 274,
     TFORALL = 275,
     TGOTO = 276,
     TIF = 277,
     TIN = 278,
     TINDEX = 279,
     TINOUT = 280,
     TITERATOR = 281,
     TLABEL = 282,
     TLET = 283,
     TLOCAL = 284,
     TMINUSMINUS = 285,
     TMODULE = 286,
     TNEW = 287,
     TNIL = 288,
     TON = 289,
     TOTHERWISE = 290,
     TOUT = 291,
     TPARAM = 292,
     TPLUSPLUS = 293,
     TPRAGMA = 294,
     TPRIMITIVE = 295,
     TRECORD = 296,
     TRETURN = 297,
     TSELECT = 298,
     TSINGLE = 299,
     TSERIAL = 300,
     TSPARSE = 301,
     TSUBDOMAIN = 302,
     TSYNC = 303,
     TTHEN = 304,
     TTYPE = 305,
     TUNION = 306,
     TUSE = 307,
     TVAL = 308,
     TVAR = 309,
     TWHEN = 310,
     TWHERE = 311,
     TWHILE = 312,
     TYIELD = 313,
     TIDENT = 314,
     INTLITERAL = 315,
     REALLITERAL = 316,
     IMAGLITERAL = 317,
     STRINGLITERAL = 318,
     TALIAS = 319,
     TASSIGN = 320,
     TSWAP = 321,
     TASSIGNBAND = 322,
     TASSIGNBOR = 323,
     TASSIGNBXOR = 324,
     TASSIGNDIVIDE = 325,
     TASSIGNEXP = 326,
     TASSIGNLAND = 327,
     TASSIGNLOR = 328,
     TASSIGNMINUS = 329,
     TASSIGNMOD = 330,
     TASSIGNMULTIPLY = 331,
     TASSIGNPLUS = 332,
     TASSIGNSR = 333,
     TASSIGNSL = 334,
     TCOLON = 335,
     TCOMMA = 336,
     TDOT = 337,
     TDOTDOTDOT = 338,
     TQUESTION = 339,
     TLCBR = 340,
     TRCBR = 341,
     TLP = 342,
     TRP = 343,
     TLSBR = 344,
     TRSBR = 345,
     TSEMI = 346,
     TNOELSE = 347,
     TELSE = 348,
     THASH = 349,
     TBY = 350,
     TDOTDOT = 351,
     TOR = 352,
     TAND = 353,
     TBOR = 354,
     TBXOR = 355,
     TBAND = 356,
     TNOTEQUAL = 357,
     TEQUAL = 358,
     TGREATER = 359,
     TLESS = 360,
     TGREATEREQUAL = 361,
     TLESSEQUAL = 362,
     TSHIFTRIGHT = 363,
     TSHIFTLEFT = 364,
     TMINUS = 365,
     TPLUS = 366,
     TUMINUS = 367,
     TUPLUS = 368,
     TMOD = 369,
     TDIVIDE = 370,
     TSTAR = 371,
     TNOT = 372,
     TBNOT = 373,
     TSCAN = 374,
     TREDUCE = 375,
     TEXP = 376
   };
#endif
/* Tokens.  */
#define TATOMIC 258
#define TBEGIN 259
#define TBREAK 260
#define TCLASS 261
#define TCOBEGIN 262
#define TCOFORALL 263
#define TCONFIG 264
#define TCONST 265
#define TCONTINUE 266
#define TDEF 267
#define TDELETE 268
#define TDISTRIBUTED 269
#define TDO 270
#define TDOMAIN 271
#define TENUM 272
#define TEXTERN 273
#define TFOR 274
#define TFORALL 275
#define TGOTO 276
#define TIF 277
#define TIN 278
#define TINDEX 279
#define TINOUT 280
#define TITERATOR 281
#define TLABEL 282
#define TLET 283
#define TLOCAL 284
#define TMINUSMINUS 285
#define TMODULE 286
#define TNEW 287
#define TNIL 288
#define TON 289
#define TOTHERWISE 290
#define TOUT 291
#define TPARAM 292
#define TPLUSPLUS 293
#define TPRAGMA 294
#define TPRIMITIVE 295
#define TRECORD 296
#define TRETURN 297
#define TSELECT 298
#define TSINGLE 299
#define TSERIAL 300
#define TSPARSE 301
#define TSUBDOMAIN 302
#define TSYNC 303
#define TTHEN 304
#define TTYPE 305
#define TUNION 306
#define TUSE 307
#define TVAL 308
#define TVAR 309
#define TWHEN 310
#define TWHERE 311
#define TWHILE 312
#define TYIELD 313
#define TIDENT 314
#define INTLITERAL 315
#define REALLITERAL 316
#define IMAGLITERAL 317
#define STRINGLITERAL 318
#define TALIAS 319
#define TASSIGN 320
#define TSWAP 321
#define TASSIGNBAND 322
#define TASSIGNBOR 323
#define TASSIGNBXOR 324
#define TASSIGNDIVIDE 325
#define TASSIGNEXP 326
#define TASSIGNLAND 327
#define TASSIGNLOR 328
#define TASSIGNMINUS 329
#define TASSIGNMOD 330
#define TASSIGNMULTIPLY 331
#define TASSIGNPLUS 332
#define TASSIGNSR 333
#define TASSIGNSL 334
#define TCOLON 335
#define TCOMMA 336
#define TDOT 337
#define TDOTDOTDOT 338
#define TQUESTION 339
#define TLCBR 340
#define TRCBR 341
#define TLP 342
#define TRP 343
#define TLSBR 344
#define TRSBR 345
#define TSEMI 346
#define TNOELSE 347
#define TELSE 348
#define THASH 349
#define TBY 350
#define TDOTDOT 351
#define TOR 352
#define TAND 353
#define TBOR 354
#define TBXOR 355
#define TBAND 356
#define TNOTEQUAL 357
#define TEQUAL 358
#define TGREATER 359
#define TLESS 360
#define TGREATEREQUAL 361
#define TLESSEQUAL 362
#define TSHIFTRIGHT 363
#define TSHIFTLEFT 364
#define TMINUS 365
#define TPLUS 366
#define TUMINUS 367
#define TUPLUS 368
#define TMOD 369
#define TDIVIDE 370
#define TSTAR 371
#define TNOT 372
#define TBNOT 373
#define TSCAN 374
#define TREDUCE 375
#define TEXP 376




#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
#line 45 "chapel.ypp"
{
  const char* pch;
  Vec<const char*>* vpch;

  RetTag retTag;

  bool b;
  IntentTag pt;

  Expr* pexpr;
  DefExpr* pdefexpr;
  CallExpr* pcallexpr;
  BlockStmt* pblockstmt;


  Type* ptype;
  EnumType* pet;

  Symbol* psym;
  FnSymbol* pfnsym;
  ModuleSymbol* pmodsym;
  EnumSymbol* penumsym;
}
/* Line 1489 of yacc.c.  */
#line 315 "chapel.tab.h"
	YYSTYPE;
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif

extern YYSTYPE yylval;

#if ! defined YYLTYPE && ! defined YYLTYPE_IS_DECLARED
typedef struct YYLTYPE
{
  int first_line;
  int first_column;
  int last_line;
  int last_column;
} YYLTYPE;
# define yyltype YYLTYPE /* obsolescent; will be withdrawn */
# define YYLTYPE_IS_DECLARED 1
# define YYLTYPE_IS_TRIVIAL 1
#endif

extern YYLTYPE yylloc;
