/**************************************************************************
  Copyright (c) 2004-2009 Cray Inc.  (See LICENSE file for more details)
**************************************************************************/


// This is a dummy file to generate dependences for lexyacc.h
#include "lexyacc.h"
