/* A Bison parser, made by GNU Bison 2.3.  */

/* Skeleton implementation for Bison's Yacc-like parsers in C

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "2.3"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Using locations.  */
#define YYLSP_NEEDED 1



/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     TATOMIC = 258,
     TBEGIN = 259,
     TBREAK = 260,
     TCLASS = 261,
     TCOBEGIN = 262,
     TCOFORALL = 263,
     TCONFIG = 264,
     TCONST = 265,
     TCONTINUE = 266,
     TDEF = 267,
     TDELETE = 268,
     TDISTRIBUTED = 269,
     TDO = 270,
     TDOMAIN = 271,
     TENUM = 272,
     TEXTERN = 273,
     TFOR = 274,
     TFORALL = 275,
     TGOTO = 276,
     TIF = 277,
     TIN = 278,
     TINDEX = 279,
     TINOUT = 280,
     TITERATOR = 281,
     TLABEL = 282,
     TLET = 283,
     TLOCAL = 284,
     TMINUSMINUS = 285,
     TMODULE = 286,
     TNEW = 287,
     TNIL = 288,
     TON = 289,
     TOTHERWISE = 290,
     TOUT = 291,
     TPARAM = 292,
     TPLUSPLUS = 293,
     TPRAGMA = 294,
     TPRIMITIVE = 295,
     TRECORD = 296,
     TRETURN = 297,
     TSELECT = 298,
     TSINGLE = 299,
     TSERIAL = 300,
     TSPARSE = 301,
     TSUBDOMAIN = 302,
     TSYNC = 303,
     TTHEN = 304,
     TTYPE = 305,
     TUNION = 306,
     TUSE = 307,
     TVAL = 308,
     TVAR = 309,
     TWHEN = 310,
     TWHERE = 311,
     TWHILE = 312,
     TYIELD = 313,
     TIDENT = 314,
     INTLITERAL = 315,
     REALLITERAL = 316,
     IMAGLITERAL = 317,
     STRINGLITERAL = 318,
     TALIAS = 319,
     TASSIGN = 320,
     TSWAP = 321,
     TASSIGNBAND = 322,
     TASSIGNBOR = 323,
     TASSIGNBXOR = 324,
     TASSIGNDIVIDE = 325,
     TASSIGNEXP = 326,
     TASSIGNLAND = 327,
     TASSIGNLOR = 328,
     TASSIGNMINUS = 329,
     TASSIGNMOD = 330,
     TASSIGNMULTIPLY = 331,
     TASSIGNPLUS = 332,
     TASSIGNSR = 333,
     TASSIGNSL = 334,
     TCOLON = 335,
     TCOMMA = 336,
     TDOT = 337,
     TDOTDOTDOT = 338,
     TQUESTION = 339,
     TLCBR = 340,
     TRCBR = 341,
     TLP = 342,
     TRP = 343,
     TLSBR = 344,
     TRSBR = 345,
     TSEMI = 346,
     TNOELSE = 347,
     TELSE = 348,
     THASH = 349,
     TBY = 350,
     TDOTDOT = 351,
     TOR = 352,
     TAND = 353,
     TBOR = 354,
     TBXOR = 355,
     TBAND = 356,
     TNOTEQUAL = 357,
     TEQUAL = 358,
     TGREATER = 359,
     TLESS = 360,
     TGREATEREQUAL = 361,
     TLESSEQUAL = 362,
     TSHIFTRIGHT = 363,
     TSHIFTLEFT = 364,
     TMINUS = 365,
     TPLUS = 366,
     TUMINUS = 367,
     TUPLUS = 368,
     TMOD = 369,
     TDIVIDE = 370,
     TSTAR = 371,
     TNOT = 372,
     TBNOT = 373,
     TSCAN = 374,
     TREDUCE = 375,
     TEXP = 376
   };
#endif
/* Tokens.  */
#define TATOMIC 258
#define TBEGIN 259
#define TBREAK 260
#define TCLASS 261
#define TCOBEGIN 262
#define TCOFORALL 263
#define TCONFIG 264
#define TCONST 265
#define TCONTINUE 266
#define TDEF 267
#define TDELETE 268
#define TDISTRIBUTED 269
#define TDO 270
#define TDOMAIN 271
#define TENUM 272
#define TEXTERN 273
#define TFOR 274
#define TFORALL 275
#define TGOTO 276
#define TIF 277
#define TIN 278
#define TINDEX 279
#define TINOUT 280
#define TITERATOR 281
#define TLABEL 282
#define TLET 283
#define TLOCAL 284
#define TMINUSMINUS 285
#define TMODULE 286
#define TNEW 287
#define TNIL 288
#define TON 289
#define TOTHERWISE 290
#define TOUT 291
#define TPARAM 292
#define TPLUSPLUS 293
#define TPRAGMA 294
#define TPRIMITIVE 295
#define TRECORD 296
#define TRETURN 297
#define TSELECT 298
#define TSINGLE 299
#define TSERIAL 300
#define TSPARSE 301
#define TSUBDOMAIN 302
#define TSYNC 303
#define TTHEN 304
#define TTYPE 305
#define TUNION 306
#define TUSE 307
#define TVAL 308
#define TVAR 309
#define TWHEN 310
#define TWHERE 311
#define TWHILE 312
#define TYIELD 313
#define TIDENT 314
#define INTLITERAL 315
#define REALLITERAL 316
#define IMAGLITERAL 317
#define STRINGLITERAL 318
#define TALIAS 319
#define TASSIGN 320
#define TSWAP 321
#define TASSIGNBAND 322
#define TASSIGNBOR 323
#define TASSIGNBXOR 324
#define TASSIGNDIVIDE 325
#define TASSIGNEXP 326
#define TASSIGNLAND 327
#define TASSIGNLOR 328
#define TASSIGNMINUS 329
#define TASSIGNMOD 330
#define TASSIGNMULTIPLY 331
#define TASSIGNPLUS 332
#define TASSIGNSR 333
#define TASSIGNSL 334
#define TCOLON 335
#define TCOMMA 336
#define TDOT 337
#define TDOTDOTDOT 338
#define TQUESTION 339
#define TLCBR 340
#define TRCBR 341
#define TLP 342
#define TRP 343
#define TLSBR 344
#define TRSBR 345
#define TSEMI 346
#define TNOELSE 347
#define TELSE 348
#define THASH 349
#define TBY 350
#define TDOTDOT 351
#define TOR 352
#define TAND 353
#define TBOR 354
#define TBXOR 355
#define TBAND 356
#define TNOTEQUAL 357
#define TEQUAL 358
#define TGREATER 359
#define TLESS 360
#define TGREATEREQUAL 361
#define TLESSEQUAL 362
#define TSHIFTRIGHT 363
#define TSHIFTLEFT 364
#define TMINUS 365
#define TPLUS 366
#define TUMINUS 367
#define TUPLUS 368
#define TMOD 369
#define TDIVIDE 370
#define TSTAR 371
#define TNOT 372
#define TBNOT 373
#define TSCAN 374
#define TREDUCE 375
#define TEXP 376




/* Copy the first part of user declarations.  */
#line 20 "chapel.ypp"


#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <stdint.h>
#include "lexyacc.h" // all #includes here, for make depend

  static int query_uid = 1;
  int captureTokens;
  char captureString[1024];

#define YYLLOC_DEFAULT(Current, Rhs, N)          \
  if (N) { \
    (Current).first_line   = (Rhs)[1].first_line;      \
    if ((Current).first_line) yystartlineno = (Current).first_line; \
    (Current).first_column = (Rhs)[1].first_column;    \
    (Current).last_line    = (Rhs)[N].last_line;       \
    (Current).last_column  = (Rhs)[N].last_column; \
  } else (Current) = yylloc;



/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 1
#endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

/* Enabling the token table.  */
#ifndef YYTOKEN_TABLE
# define YYTOKEN_TABLE 0
#endif

#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
#line 45 "chapel.ypp"
{
  const char* pch;
  Vec<const char*>* vpch;

  RetTag retTag;

  bool b;
  IntentTag pt;

  Expr* pexpr;
  DefExpr* pdefexpr;
  CallExpr* pcallexpr;
  BlockStmt* pblockstmt;


  Type* ptype;
  EnumType* pet;

  Symbol* psym;
  FnSymbol* pfnsym;
  ModuleSymbol* pmodsym;
  EnumSymbol* penumsym;
}
/* Line 187 of yacc.c.  */
#line 385 "chapel.tab.cpp"
	YYSTYPE;
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif

#if ! defined YYLTYPE && ! defined YYLTYPE_IS_DECLARED
typedef struct YYLTYPE
{
  int first_line;
  int first_column;
  int last_line;
  int last_column;
} YYLTYPE;
# define yyltype YYLTYPE /* obsolescent; will be withdrawn */
# define YYLTYPE_IS_DECLARED 1
# define YYLTYPE_IS_TRIVIAL 1
#endif


/* Copy the second part of user declarations.  */


/* Line 216 of yacc.c.  */
#line 410 "chapel.tab.cpp"

#ifdef short
# undef short
#endif

#ifdef YYTYPE_UINT8
typedef YYTYPE_UINT8 yytype_uint8;
#else
typedef unsigned char yytype_uint8;
#endif

#ifdef YYTYPE_INT8
typedef YYTYPE_INT8 yytype_int8;
#elif (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
typedef signed char yytype_int8;
#else
typedef short int yytype_int8;
#endif

#ifdef YYTYPE_UINT16
typedef YYTYPE_UINT16 yytype_uint16;
#else
typedef unsigned short int yytype_uint16;
#endif

#ifdef YYTYPE_INT16
typedef YYTYPE_INT16 yytype_int16;
#else
typedef short int yytype_int16;
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif ! defined YYSIZE_T && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned int
# endif
#endif

#define YYSIZE_MAXIMUM ((YYSIZE_T) -1)

#ifndef YY_
# if YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YYUSE(e) ((void) (e))
#else
# define YYUSE(e) /* empty */
#endif

/* Identity function, used to suppress warnings about constant conditions.  */
#ifndef lint
# define YYID(n) (n)
#else
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static int
YYID (int i)
#else
static int
YYID (i)
    int i;
#endif
{
  return i;
}
#endif

#if ! defined yyoverflow || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#     ifndef _STDLIB_H
#      define _STDLIB_H 1
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (YYID (0))
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined _STDLIB_H \
       && ! ((defined YYMALLOC || defined malloc) \
	     && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef _STDLIB_H
#    define _STDLIB_H 1
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* ! defined yyoverflow || YYERROR_VERBOSE */


#if (! defined yyoverflow \
     && (! defined __cplusplus \
	 || (defined YYLTYPE_IS_TRIVIAL && YYLTYPE_IS_TRIVIAL \
	     && defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yytype_int16 yyss;
  YYSTYPE yyvs;
    YYLTYPE yyls;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (yytype_int16) + sizeof (YYSTYPE) + sizeof (YYLTYPE)) \
      + 2 * YYSTACK_GAP_MAXIMUM)

/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  YYSIZE_T yyi;				\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (YYID (0))
#  endif
# endif

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack)					\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack, Stack, yysize);				\
	Stack = &yyptr->Stack;						\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (YYID (0))

#endif

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  3
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   5772

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  122
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  105
/* YYNRULES -- Number of rules.  */
#define YYNRULES  364
/* YYNRULES -- Number of states.  */
#define YYNSTATES  719

/* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   376

#define YYTRANSLATE(YYX)						\
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[YYLEX] -- Bison symbol number corresponding to YYLEX.  */
static const yytype_uint8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81,    82,    83,    84,
      85,    86,    87,    88,    89,    90,    91,    92,    93,    94,
      95,    96,    97,    98,    99,   100,   101,   102,   103,   104,
     105,   106,   107,   108,   109,   110,   111,   112,   113,   114,
     115,   116,   117,   118,   119,   120,   121
};

#if YYDEBUG
/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
static const yytype_uint16 yyprhs[] =
{
       0,     0,     3,     5,     6,     9,    12,    13,    17,    19,
      21,    23,    25,    27,    29,    31,    33,    35,    37,    39,
      41,    43,    45,    47,    49,    51,    53,    55,    57,    59,
      61,    63,    65,    67,    69,    71,    73,    75,    77,    79,
      81,    83,    85,    87,    89,    91,    95,    96,   100,   102,
     104,   106,   108,   110,   112,   116,   120,   124,   127,   131,
     136,   142,   149,   157,   164,   170,   177,   181,   186,   192,
     199,   203,   208,   215,   220,   226,   233,   237,   242,   247,
     251,   257,   264,   270,   271,   274,   279,   283,   286,   290,
     294,   298,   299,   301,   306,   311,   316,   321,   326,   331,
     336,   341,   346,   351,   356,   361,   366,   371,   376,   380,
     383,   386,   389,   394,   398,   401,   404,   408,   413,   417,
     419,   423,   429,   430,   432,   436,   440,   446,   447,   451,
     454,   459,   460,   462,   464,   466,   468,   469,   470,   479,
     481,   483,   489,   492,   494,   497,   500,   505,   510,   511,
     513,   515,   517,   519,   521,   523,   525,   528,   530,   532,
     534,   536,   538,   540,   542,   544,   546,   548,   550,   552,
     554,   556,   558,   560,   562,   564,   566,   568,   570,   572,
     573,   576,   578,   585,   587,   589,   591,   592,   595,   602,
     604,   608,   610,   614,   618,   624,   628,   629,   632,   637,
     642,   647,   652,   653,   655,   657,   661,   665,   669,   675,
     677,   681,   685,   691,   692,   695,   702,   707,   709,   711,
     713,   719,   724,   731,   734,   737,   740,   741,   744,   745,
     750,   751,   754,   755,   758,   761,   764,   767,   770,   773,
     778,   784,   788,   793,   798,   803,   809,   815,   817,   819,
     821,   825,   827,   829,   830,   832,   834,   838,   842,   844,
     846,   850,   855,   860,   865,   869,   873,   877,   878,   880,
     882,   886,   890,   892,   894,   896,   898,   900,   902,   903,
     905,   909,   914,   919,   924,   929,   933,   937,   941,   943,
     945,   947,   949,   951,   955,   957,   959,   961,   968,   973,
     983,   991,   998,  1003,  1013,  1021,  1028,  1033,  1043,  1051,
    1058,  1060,  1063,  1068,  1070,  1075,  1077,  1079,  1083,  1087,
    1090,  1093,  1095,  1098,  1101,  1104,  1107,  1110,  1113,  1117,
    1121,  1125,  1129,  1133,  1137,  1141,  1145,  1149,  1153,  1157,
    1161,  1165,  1169,  1173,  1177,  1181,  1185,  1189,  1193,  1197,
    1201,  1205,  1209,  1213,  1217,  1221,  1225,  1229,  1233,  1237,
    1241,  1245,  1249,  1253,  1257
};

/* YYRHS -- A `-1'-separated list of the rules' RHS.  */
static const yytype_int16 yyrhs[] =
{
     123,     0,    -1,   126,    -1,    -1,   124,   125,    -1,    39,
      63,    -1,    -1,   126,   124,   127,    -1,   132,    -1,   128,
      -1,   133,    -1,   134,    -1,   135,    -1,   136,    -1,   137,
      -1,   138,    -1,   139,    -1,   140,    -1,   141,    -1,   142,
      -1,   143,    -1,   145,    -1,   144,    -1,   148,    -1,   149,
      -1,   150,    -1,   152,    -1,   153,    -1,   161,    -1,   163,
      -1,   168,    -1,   172,    -1,   180,    -1,   183,    -1,   187,
      -1,   190,    -1,   157,    -1,   159,    -1,   160,    -1,   156,
      -1,   154,    -1,   155,    -1,   158,    -1,   129,    -1,     1,
      -1,   221,   199,    91,    -1,    -1,   130,   124,   131,    -1,
     168,    -1,   180,    -1,   183,    -1,   189,    -1,   190,    -1,
      91,    -1,    27,   215,   127,    -1,     5,   216,    91,    -1,
      11,   216,    91,    -1,   224,    91,    -1,    22,   223,   153,
      -1,    22,   223,    49,   127,    -1,    22,   223,   153,    93,
     127,    -1,    22,   223,    49,   127,    93,   127,    -1,    19,
      37,   215,    23,   223,    15,   127,    -1,    19,    37,   215,
      23,   223,   153,    -1,    19,   223,    23,   223,   153,    -1,
      19,   223,    23,   223,    15,   127,    -1,    19,   223,   153,
      -1,    19,   223,    15,   127,    -1,    20,   223,    23,   223,
     153,    -1,    20,   223,    23,   223,    15,   127,    -1,    20,
     223,   153,    -1,    20,   223,    15,   127,    -1,    89,   212,
      23,   223,    90,   127,    -1,    89,   212,    90,   128,    -1,
       8,   223,    23,   223,   153,    -1,     8,   223,    23,   223,
      15,   127,    -1,     8,   223,   153,    -1,     8,   223,    15,
     127,    -1,    57,   223,    15,   127,    -1,    57,   223,   153,
      -1,    15,   127,    57,   223,    91,    -1,    50,    43,   212,
      85,   146,    86,    -1,    43,   223,    85,   146,    86,    -1,
      -1,   146,   147,    -1,    55,   212,    15,   127,    -1,    55,
     212,   153,    -1,    35,   127,    -1,    42,   151,    91,    -1,
      58,   151,    91,    -1,    13,   223,    91,    -1,    -1,   223,
      -1,   222,    65,   223,    91,    -1,   222,    77,   223,    91,
      -1,   222,    74,   223,    91,    -1,   222,    76,   223,    91,
      -1,   222,    70,   223,    91,    -1,   222,    75,   223,    91,
      -1,   222,    71,   223,    91,    -1,   222,    67,   223,    91,
      -1,   222,    68,   223,    91,    -1,   222,    69,   223,    91,
      -1,   222,    72,   223,    91,    -1,   222,    73,   223,    91,
      -1,   222,    78,   223,    91,    -1,   222,    79,   223,    91,
      -1,   222,    66,   223,    91,    -1,    85,   126,    86,    -1,
       7,   153,    -1,     3,   127,    -1,     4,   127,    -1,    34,
     223,    15,   127,    -1,    34,   223,   153,    -1,    29,   127,
      -1,    48,   127,    -1,    45,   223,   153,    -1,    45,   223,
      15,   127,    -1,    52,   162,    91,    -1,   222,    -1,   162,
      81,   222,    -1,    31,   215,    85,   126,    86,    -1,    -1,
     175,    -1,    87,   194,    88,    -1,   164,    81,   175,    -1,
     164,    81,    87,   194,    88,    -1,    -1,    87,   164,    88,
      -1,   177,   165,    -1,   179,    82,   177,   165,    -1,    -1,
      10,    -1,    54,    -1,    37,    -1,    50,    -1,    -1,    -1,
      12,   169,   166,   170,   167,   202,   178,   171,    -1,   153,
      -1,   148,    -1,    18,    12,   166,   202,    91,    -1,    84,
     215,    -1,    84,    -1,    83,   223,    -1,    83,   173,    -1,
     176,   215,   203,   200,    -1,   176,   215,   203,   174,    -1,
      -1,    23,    -1,    25,    -1,    36,    -1,    10,    -1,    37,
      -1,    50,    -1,   215,    -1,   118,   215,    -1,    65,    -1,
     101,    -1,    99,    -1,   100,    -1,   118,    -1,   103,    -1,
     102,    -1,   107,    -1,   106,    -1,   105,    -1,   104,    -1,
     111,    -1,   110,    -1,   116,    -1,   115,    -1,   109,    -1,
     108,    -1,   114,    -1,   121,    -1,   117,    -1,    95,    -1,
      94,    -1,    -1,    56,   223,    -1,   220,    -1,   181,   215,
     182,    85,   130,    86,    -1,     6,    -1,    41,    -1,    51,
      -1,    -1,    80,   212,    -1,    17,   215,    85,   184,    86,
      91,    -1,   185,    -1,   184,    81,   185,    -1,   215,    -1,
     215,    65,   223,    -1,   215,    65,   197,    -1,   215,    65,
     197,    81,   186,    -1,    50,   186,    91,    -1,    -1,    65,
     197,    -1,    50,   215,   188,    91,    -1,   191,    37,   192,
      91,    -1,   191,    10,   192,    91,    -1,   191,    54,   192,
      91,    -1,    -1,     9,    -1,   193,    -1,   192,    81,   193,
      -1,   215,   202,   200,    -1,   215,   201,   199,    -1,    87,
     194,    88,   202,   200,    -1,   215,    -1,    87,   194,    88,
      -1,   194,    81,   215,    -1,   194,    81,    87,   194,    88,
      -1,    -1,    14,   223,    -1,    89,   212,    23,   223,    90,
     197,    -1,    89,   212,    90,   197,    -1,   224,    -1,   198,
      -1,   196,    -1,    16,    87,   211,    88,   195,    -1,    47,
      87,   211,    88,    -1,    46,    47,    87,   211,    88,   195,
      -1,    44,   197,    -1,    48,   197,    -1,    64,   223,    -1,
      -1,    65,   223,    -1,    -1,    80,    89,   212,    90,    -1,
      -1,    80,   197,    -1,    -1,    80,   204,    -1,    80,   198,
      -1,    80,   173,    -1,    80,    16,    -1,    80,    44,    -1,
      80,    48,    -1,    80,    89,    90,   197,    -1,    80,    89,
     173,    90,   197,    -1,    80,    89,    90,    -1,    80,    89,
     173,    90,    -1,    80,    89,   212,    90,    -1,    80,    89,
      90,   173,    -1,    80,    89,   173,    90,   173,    -1,    80,
      89,   212,    90,   173,    -1,   208,    -1,   209,    -1,   210,
      -1,   204,   116,   204,    -1,   220,    -1,   214,    -1,    -1,
     206,    -1,   207,    -1,   206,    81,   207,    -1,   215,    65,
     207,    -1,   173,    -1,   223,    -1,    87,   206,    88,    -1,
     204,    87,   205,    88,    -1,   204,    89,   205,    90,    -1,
      24,    87,   211,    88,    -1,   204,    82,   215,    -1,   204,
      82,    50,    -1,   204,    82,    16,    -1,    -1,   212,    -1,
     213,    -1,   212,    81,   213,    -1,   215,    65,   223,    -1,
     223,    -1,    60,    -1,    61,    -1,    62,    -1,    63,    -1,
      59,    -1,    -1,   215,    -1,    87,   212,    88,    -1,   222,
      87,   211,    88,    -1,   222,    89,   211,    90,    -1,    40,
      87,   211,    88,    -1,    24,    87,   211,    88,    -1,   222,
      82,   215,    -1,   222,    82,    50,    -1,   222,    82,    16,
      -1,   215,    -1,   214,    -1,   220,    -1,   218,    -1,   219,
      -1,    89,   212,    90,    -1,   221,    -1,   217,    -1,   224,
      -1,    89,   212,    23,   223,    90,   223,    -1,    89,   212,
      90,   223,    -1,    89,   212,    23,   223,    90,    22,   223,
      49,   223,    -1,    89,   212,    90,    22,   223,    49,   223,
      -1,    19,   223,    23,   223,    15,   223,    -1,    19,   223,
      15,   223,    -1,    19,   223,    23,   223,    15,    22,   223,
      49,   223,    -1,    19,   223,    15,    22,   223,    49,   223,
      -1,    20,   223,    23,   223,    15,   223,    -1,    20,   223,
      15,   223,    -1,    20,   223,    23,   223,    15,    22,   223,
      49,   223,    -1,    20,   223,    15,    22,   223,    49,   223,
      -1,    22,   223,    49,   223,    93,   223,    -1,   222,    -1,
      32,   218,    -1,    87,    83,   223,    88,    -1,    33,    -1,
      28,   192,    23,   223,    -1,   225,    -1,   226,    -1,   223,
      80,   223,    -1,   223,    96,   223,    -1,   223,    96,    -1,
      96,   223,    -1,    96,    -1,   111,   223,    -1,   110,   223,
      -1,    30,   223,    -1,    38,   223,    -1,   117,   223,    -1,
     118,   223,    -1,   223,   111,   223,    -1,   223,   110,   223,
      -1,   223,   116,   223,    -1,   223,   115,   223,    -1,   223,
     109,   223,    -1,   223,   108,   223,    -1,   223,   114,   223,
      -1,   223,   103,   223,    -1,   223,   102,   223,    -1,   223,
     107,   223,    -1,   223,   106,   223,    -1,   223,   105,   223,
      -1,   223,   104,   223,    -1,   223,   101,   223,    -1,   223,
      99,   223,    -1,   223,   100,   223,    -1,   223,    98,   223,
      -1,   223,    97,   223,    -1,   223,   121,   223,    -1,   223,
      95,   223,    -1,   223,    94,   223,    -1,   223,   120,   223,
      -1,   111,   120,   223,    -1,   116,   120,   223,    -1,    98,
     120,   223,    -1,    97,   120,   223,    -1,   101,   120,   223,
      -1,    99,   120,   223,    -1,   100,   120,   223,    -1,   223,
     119,   223,    -1,   111,   119,   223,    -1,   116,   119,   223,
      -1,    98,   119,   223,    -1,    97,   119,   223,    -1,   101,
     119,   223,    -1,    99,   119,   223,    -1,   100,   119,   223,
      -1
};

/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const yytype_uint16 yyrline[] =
{
       0,   243,   243,   252,   253,   259,   269,   270,   281,   282,
     287,   288,   289,   290,   291,   292,   293,   294,   295,   296,
     297,   298,   299,   300,   301,   302,   303,   304,   305,   306,
     307,   308,   309,   310,   311,   312,   313,   314,   315,   316,
     317,   318,   319,   320,   321,   326,   334,   335,   346,   347,
     348,   349,   350,   355,   361,   367,   373,   379,   385,   387,
     389,   391,   397,   399,   405,   407,   409,   411,   417,   419,
     421,   423,   425,   431,   441,   443,   445,   447,   453,   455,
     461,   467,   473,   480,   481,   487,   489,   491,   497,   503,
     509,   518,   519,   524,   526,   528,   530,   532,   534,   536,
     538,   540,   542,   544,   546,   548,   550,   552,   558,   564,
     574,   580,   586,   588,   594,   602,   608,   610,   620,   626,
     628,   634,   641,   642,   647,   652,   654,   660,   661,   667,
     677,   695,   696,   698,   700,   702,   709,   714,   708,   734,
     735,   741,   755,   759,   767,   769,   778,   780,   787,   788,
     790,   792,   794,   796,   798,   804,   805,   807,   809,   811,
     813,   815,   817,   819,   821,   823,   825,   827,   829,   831,
     833,   835,   837,   839,   841,   843,   845,   847,   849,   856,
     857,   863,   868,   879,   881,   883,   890,   891,   897,   908,
     915,   924,   926,   932,   939,   950,   957,   958,   964,   975,
     981,   987,   998,   999,  1005,  1007,  1017,  1022,  1028,  1034,
    1036,  1038,  1043,  1056,  1057,  1063,  1071,  1077,  1078,  1083,
    1084,  1090,  1092,  1098,  1100,  1106,  1113,  1114,  1121,  1122,
    1129,  1130,  1137,  1138,  1140,  1142,  1144,  1146,  1148,  1150,
    1152,  1154,  1156,  1158,  1160,  1162,  1164,  1170,  1171,  1172,
    1173,  1175,  1176,  1182,  1183,  1188,  1190,  1196,  1198,  1200,
    1205,  1218,  1220,  1226,  1231,  1233,  1235,  1245,  1246,  1251,
    1253,  1259,  1261,  1266,  1282,  1284,  1289,  1295,  1302,  1303,
    1308,  1321,  1323,  1329,  1331,  1337,  1339,  1341,  1347,  1353,
    1354,  1355,  1356,  1357,  1363,  1364,  1369,  1370,  1376,  1382,
    1388,  1394,  1396,  1398,  1400,  1402,  1404,  1406,  1408,  1410,
    1416,  1417,  1419,  1421,  1423,  1425,  1426,  1427,  1429,  1431,
    1433,  1435,  1437,  1439,  1441,  1443,  1445,  1447,  1449,  1451,
    1453,  1455,  1457,  1459,  1461,  1463,  1465,  1467,  1469,  1471,
    1473,  1475,  1477,  1479,  1481,  1483,  1485,  1487,  1489,  1495,
    1497,  1499,  1501,  1503,  1505,  1507,  1509,  1515,  1517,  1519,
    1521,  1523,  1525,  1527,  1529
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || YYTOKEN_TABLE
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "TATOMIC", "TBEGIN", "TBREAK", "TCLASS",
  "TCOBEGIN", "TCOFORALL", "TCONFIG", "TCONST", "TCONTINUE", "TDEF",
  "TDELETE", "TDISTRIBUTED", "TDO", "TDOMAIN", "TENUM", "TEXTERN", "TFOR",
  "TFORALL", "TGOTO", "TIF", "TIN", "TINDEX", "TINOUT", "TITERATOR",
  "TLABEL", "TLET", "TLOCAL", "TMINUSMINUS", "TMODULE", "TNEW", "TNIL",
  "TON", "TOTHERWISE", "TOUT", "TPARAM", "TPLUSPLUS", "TPRAGMA",
  "TPRIMITIVE", "TRECORD", "TRETURN", "TSELECT", "TSINGLE", "TSERIAL",
  "TSPARSE", "TSUBDOMAIN", "TSYNC", "TTHEN", "TTYPE", "TUNION", "TUSE",
  "TVAL", "TVAR", "TWHEN", "TWHERE", "TWHILE", "TYIELD", "TIDENT",
  "INTLITERAL", "REALLITERAL", "IMAGLITERAL", "STRINGLITERAL", "TALIAS",
  "TASSIGN", "TSWAP", "TASSIGNBAND", "TASSIGNBOR", "TASSIGNBXOR",
  "TASSIGNDIVIDE", "TASSIGNEXP", "TASSIGNLAND", "TASSIGNLOR",
  "TASSIGNMINUS", "TASSIGNMOD", "TASSIGNMULTIPLY", "TASSIGNPLUS",
  "TASSIGNSR", "TASSIGNSL", "TCOLON", "TCOMMA", "TDOT", "TDOTDOTDOT",
  "TQUESTION", "TLCBR", "TRCBR", "TLP", "TRP", "TLSBR", "TRSBR", "TSEMI",
  "TNOELSE", "TELSE", "THASH", "TBY", "TDOTDOT", "TOR", "TAND", "TBOR",
  "TBXOR", "TBAND", "TNOTEQUAL", "TEQUAL", "TGREATER", "TLESS",
  "TGREATEREQUAL", "TLESSEQUAL", "TSHIFTRIGHT", "TSHIFTLEFT", "TMINUS",
  "TPLUS", "TUMINUS", "TUPLUS", "TMOD", "TDIVIDE", "TSTAR", "TNOT",
  "TBNOT", "TSCAN", "TREDUCE", "TEXP", "$accept", "program", "pragma_ls",
  "pragma", "stmt_ls", "stmt", "non_empty_stmt", "array_alias_stmt",
  "class_body_stmt_ls", "class_body_stmt", "empty_stmt", "label_stmt",
  "break_stmt", "continue_stmt", "expr_stmt", "if_stmt", "param_for_stmt",
  "for_stmt", "forall_stmt", "coforall_stmt", "while_do_stmt",
  "do_while_stmt", "type_select_stmt", "select_stmt", "when_stmt_ls",
  "when_stmt", "return_stmt", "yield_stmt", "delete_stmt",
  "opt_return_part", "assign_stmt", "block_stmt", "cobegin_stmt",
  "atomic_stmt", "begin_stmt", "on_stmt", "local_stmt", "sync_stmt",
  "serial_stmt", "use_stmt", "use_stmt_ls", "mod_decl_stmt", "formal_ls",
  "opt_formal_ls", "fn_decl_stmt_inner", "ret_tag", "fn_decl_stmt", "@1",
  "@2", "function_body_stmt", "extern_fn_decl_stmt", "query_expr",
  "var_arg_expr", "formal", "intent_tag", "fn_identifier",
  "opt_where_part", "type_binding_part", "class_decl_stmt", "class_tag",
  "opt_inherit_expr_ls", "enum_decl_stmt", "enum_ls", "enum_item",
  "typedef_decl_stmt_inner", "typedef_decl_stmt", "opt_init_type",
  "typevar_decl_stmt", "var_decl_stmt", "is_config",
  "var_decl_stmt_inner_ls", "var_decl_stmt_inner",
  "tuple_var_decl_stmt_inner_ls", "distributed_expr", "array_type", "type",
  "formal_level_type", "alias_expr", "opt_init_expr", "opt_domain",
  "opt_type", "opt_formal_type", "formal_type_expr", "formal_expr_ls",
  "nonempty_formal_expr_ls", "formal_expr_list_item",
  "formal_tuple_paren_expr", "formal_parenop_expr",
  "formal_memberaccess_expr", "expr_ls", "nonempty_expr_ls",
  "expr_list_item", "literal", "identifier", "opt_identifier",
  "tuple_paren_expr", "parenop_expr", "memberaccess_expr", "variable_expr",
  "non_tuple_lvalue", "lvalue", "expr", "stmt_level_expr", "reduce_expr",
  "scan_expr", 0
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[YYLEX-NUM] -- Internal token number corresponding to
   token YYLEX-NUM.  */
static const yytype_uint16 yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   310,   311,   312,   313,   314,
     315,   316,   317,   318,   319,   320,   321,   322,   323,   324,
     325,   326,   327,   328,   329,   330,   331,   332,   333,   334,
     335,   336,   337,   338,   339,   340,   341,   342,   343,   344,
     345,   346,   347,   348,   349,   350,   351,   352,   353,   354,
     355,   356,   357,   358,   359,   360,   361,   362,   363,   364,
     365,   366,   367,   368,   369,   370,   371,   372,   373,   374,
     375,   376
};
# endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const yytype_uint8 yyr1[] =
{
       0,   122,   123,   124,   124,   125,   126,   126,   127,   127,
     128,   128,   128,   128,   128,   128,   128,   128,   128,   128,
     128,   128,   128,   128,   128,   128,   128,   128,   128,   128,
     128,   128,   128,   128,   128,   128,   128,   128,   128,   128,
     128,   128,   128,   128,   128,   129,   130,   130,   131,   131,
     131,   131,   131,   132,   133,   134,   135,   136,   137,   137,
     137,   137,   138,   138,   139,   139,   139,   139,   140,   140,
     140,   140,   140,   140,   141,   141,   141,   141,   142,   142,
     143,   144,   145,   146,   146,   147,   147,   147,   148,   149,
     150,   151,   151,   152,   152,   152,   152,   152,   152,   152,
     152,   152,   152,   152,   152,   152,   152,   152,   153,   154,
     155,   156,   157,   157,   158,   159,   160,   160,   161,   162,
     162,   163,   164,   164,   164,   164,   164,   165,   165,   166,
     166,   167,   167,   167,   167,   167,   169,   170,   168,   171,
     171,   172,   173,   173,   174,   174,   175,   175,   176,   176,
     176,   176,   176,   176,   176,   177,   177,   177,   177,   177,
     177,   177,   177,   177,   177,   177,   177,   177,   177,   177,
     177,   177,   177,   177,   177,   177,   177,   177,   177,   178,
     178,   179,   180,   181,   181,   181,   182,   182,   183,   184,
     184,   185,   185,   186,   186,   187,   188,   188,   189,   190,
     190,   190,   191,   191,   192,   192,   193,   193,   193,   194,
     194,   194,   194,   195,   195,   196,   196,   197,   197,   198,
     198,   198,   198,   198,   198,   199,   200,   200,   201,   201,
     202,   202,   203,   203,   203,   203,   203,   203,   203,   203,
     203,   203,   203,   203,   203,   203,   203,   204,   204,   204,
     204,   204,   204,   205,   205,   206,   206,   207,   207,   207,
     208,   209,   209,   209,   210,   210,   210,   211,   211,   212,
     212,   213,   213,   214,   214,   214,   214,   215,   216,   216,
     217,   218,   218,   218,   218,   219,   219,   219,   220,   221,
     221,   221,   221,   221,   222,   222,   223,   223,   223,   223,
     223,   223,   223,   223,   223,   223,   223,   223,   223,   223,
     224,   224,   224,   224,   224,   224,   224,   224,   224,   224,
     224,   224,   224,   224,   224,   224,   224,   224,   224,   224,
     224,   224,   224,   224,   224,   224,   224,   224,   224,   224,
     224,   224,   224,   224,   224,   224,   224,   224,   224,   225,
     225,   225,   225,   225,   225,   225,   225,   226,   226,   226,
     226,   226,   226,   226,   226
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
static const yytype_uint8 yyr2[] =
{
       0,     2,     1,     0,     2,     2,     0,     3,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     3,     0,     3,     1,     1,
       1,     1,     1,     1,     3,     3,     3,     2,     3,     4,
       5,     6,     7,     6,     5,     6,     3,     4,     5,     6,
       3,     4,     6,     4,     5,     6,     3,     4,     4,     3,
       5,     6,     5,     0,     2,     4,     3,     2,     3,     3,
       3,     0,     1,     4,     4,     4,     4,     4,     4,     4,
       4,     4,     4,     4,     4,     4,     4,     4,     3,     2,
       2,     2,     4,     3,     2,     2,     3,     4,     3,     1,
       3,     5,     0,     1,     3,     3,     5,     0,     3,     2,
       4,     0,     1,     1,     1,     1,     0,     0,     8,     1,
       1,     5,     2,     1,     2,     2,     4,     4,     0,     1,
       1,     1,     1,     1,     1,     1,     2,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     0,
       2,     1,     6,     1,     1,     1,     0,     2,     6,     1,
       3,     1,     3,     3,     5,     3,     0,     2,     4,     4,
       4,     4,     0,     1,     1,     3,     3,     3,     5,     1,
       3,     3,     5,     0,     2,     6,     4,     1,     1,     1,
       5,     4,     6,     2,     2,     2,     0,     2,     0,     4,
       0,     2,     0,     2,     2,     2,     2,     2,     2,     4,
       5,     3,     4,     4,     4,     5,     5,     1,     1,     1,
       3,     1,     1,     0,     1,     1,     3,     3,     1,     1,
       3,     4,     4,     4,     3,     3,     3,     0,     1,     1,
       3,     3,     1,     1,     1,     1,     1,     1,     0,     1,
       3,     4,     4,     4,     4,     3,     3,     3,     1,     1,
       1,     1,     1,     3,     1,     1,     1,     6,     4,     9,
       7,     6,     4,     9,     7,     6,     4,     9,     7,     6,
       1,     2,     4,     1,     4,     1,     1,     3,     3,     2,
       2,     1,     2,     2,     2,     2,     2,     2,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3
};

/* YYDEFACT[STATE-NAME] -- Default rule to reduce with in state
   STATE-NUM when YYTABLE doesn't specify something else to do.  Zero
   means the default is an error.  */
static const yytype_uint16 yydefact[] =
{
       6,     0,     3,     1,     0,    44,     0,     0,   278,   183,
       0,     0,   203,   278,   136,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   313,
       0,     0,     0,     0,   184,    91,     0,     0,     0,     0,
     185,     0,     0,    91,   277,   273,   274,   275,   276,     6,
       0,     0,    53,   321,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     4,     7,     9,    43,     8,    10,
      11,    12,    13,    14,    15,    16,    17,    18,    19,    20,
      22,    21,    23,    24,    25,    26,    27,    40,    41,    39,
      36,    42,    37,    38,    28,    29,    30,    31,    32,     0,
      33,    34,    35,     0,   289,   288,   295,   291,   292,   290,
     294,   310,     0,   296,   315,   316,   110,   111,   279,     0,
     109,     0,     0,     0,     0,   294,   310,     0,   296,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   267,
       0,     0,     0,   204,   230,   114,   324,     0,     0,     0,
     311,     0,     0,   325,     5,   267,     0,    92,     0,     0,
     115,     0,     0,     0,     0,   119,     0,     0,     3,     0,
       0,   269,   288,   272,     0,   320,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   323,     0,     0,   322,
       0,     0,   326,   327,   186,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   267,   267,     0,     0,
       0,   319,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    57,    55,     0,     0,     0,     0,     0,
       0,    76,    56,   157,   178,   177,   159,   160,   158,   163,
     162,   167,   166,   165,   164,   173,   172,   169,   168,   174,
     171,   170,   176,   161,   175,   137,   127,     0,   155,   181,
      90,     0,     0,   230,     0,     0,     0,    66,     0,     0,
      70,     0,    58,     0,   268,    54,     0,     0,   209,     0,
       0,     0,     0,   226,     6,     0,     0,   113,     0,    88,
      83,     0,   116,     0,   195,     0,     0,   118,     0,    79,
      89,   108,     0,     0,   280,     0,     0,     0,   361,   353,
     360,   352,   363,   355,   364,   356,   362,   354,   358,   350,
     359,   351,     0,     0,     0,     0,     0,   225,    45,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   287,   286,   285,     0,     0,   317,
     348,   347,   318,   345,   344,   342,   343,   341,   336,   335,
     340,   339,   338,   337,   333,   332,   329,   328,   334,   331,
     330,   357,   349,   346,     0,     0,     0,     0,     0,     0,
     293,    77,     0,   156,   131,   122,   129,     0,     0,     0,
     189,   191,     0,     0,     0,     0,    67,   302,     0,     0,
      71,   306,     0,    59,     0,     0,   284,     0,     0,   230,
     314,   205,     0,     0,     0,     0,     0,     0,   219,   231,
     218,   296,   207,     0,   206,     3,   293,   112,   283,     0,
     117,    83,     0,   193,   120,    78,   312,   270,   271,     0,
       0,    73,   298,   187,    46,   200,   199,   201,    93,   107,
     100,   101,   102,    97,    99,   103,   104,    95,    98,    96,
      94,   105,   106,   281,   282,     0,     0,     0,     0,     0,
       0,     0,    74,   132,   134,   135,   133,   230,   152,   149,
     150,   151,   153,   154,     0,     0,   123,     0,   127,   155,
      80,     0,     0,     0,   141,     0,     0,     0,    64,     0,
       0,    68,     0,     0,    60,   210,     0,   211,   226,   267,
     223,     0,   267,   224,     0,   227,   121,     0,     0,    82,
      84,     0,     0,     0,     0,     0,     3,     0,     0,     0,
       0,     0,     0,    75,   179,     0,   148,   128,   232,   130,
     190,   188,   192,     0,    63,     0,     0,    65,   301,     0,
       0,    69,   305,    61,   309,     0,   208,     0,   267,     0,
       0,   293,    87,     0,    81,   293,   194,     0,    72,   297,
       0,   182,   202,     0,     0,     0,     0,     0,     0,     0,
       0,   124,     0,   125,     0,   226,    62,   304,     0,   308,
       0,   212,   213,     0,   221,     0,   216,     0,    86,     0,
     300,     0,    47,    48,    49,    50,    51,    52,     0,     0,
       0,   180,   140,   139,   138,     0,   236,     0,   237,   238,
     143,     0,     0,   235,   234,   233,   247,   248,   249,   252,
     251,     0,   147,   146,     0,     0,     0,   220,   213,     0,
      85,     0,   196,     0,     0,     0,   126,   267,   142,   258,
       0,   255,   288,   259,   241,     0,     0,     0,   253,   253,
       0,   145,   144,   303,   307,   214,   222,   215,   299,     0,
       0,     0,     0,   260,     0,   244,   239,   242,     0,   243,
     266,   265,   264,     0,   254,     0,   250,   197,   198,   263,
     256,   257,   245,   240,     0,   246,   261,   262,     0
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
      -1,     1,     4,    64,     2,   423,    66,    67,   546,   622,
      68,    69,    70,    71,    72,    73,    74,    75,    76,    77,
      78,    79,    80,    81,   449,   540,    82,    83,    84,   156,
      85,    86,    87,    88,    89,    90,    91,    92,    93,    94,
     164,    95,   505,   406,   275,   497,    96,   130,   404,   634,
      97,   669,   652,   506,   507,   276,   600,   277,    98,    99,
     343,   100,   409,   410,   162,   101,   690,   626,   102,   103,
     142,   143,   297,   657,   438,   616,   440,   199,   444,   302,
     303,   605,   645,   703,   704,   671,   646,   647,   648,   293,
     294,   171,   104,   105,   119,   106,   107,   108,   109,   125,
     126,   112,   128,   114,   115
};

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
#define YYPACT_NINF -645
static const yytype_int16 yypact[] =
{
    -645,   141,   144,  -645,  1850,  -645,  1968,  1968,    38,  -645,
      14,  3783,  -645,    38,  -645,  3783,  1968,    38,    96,  3593,
    3783,  3783,    63,    38,   -40,  1968,  3783,    38,   176,  -645,
    3783,  3783,    98,    77,  -645,  3783,  3783,  3783,  1968,    84,
    -645,   176,  3783,  3783,  -645,  -645,  -645,  -645,  -645,  -645,
    3638,  3783,  -645,  4318,  -102,   173,   189,   197,   199,  3783,
     785,   202,  3783,  3783,  -645,  -645,  -645,  -645,  -645,  -645,
    -645,  -645,  -645,  -645,  -645,  -645,  -645,  -645,  -645,  -645,
    -645,  -645,  -645,  -645,  -645,  -645,  -645,  -645,  -645,  -645,
    -645,  -645,  -645,  -645,  -645,  -645,  -645,  -645,  -645,    38,
    -645,  -645,  -645,   155,  -645,  -645,  -645,  -645,  -645,  -645,
     103,  1360,  5587,    89,  -645,  -645,  -645,  -645,  -645,   115,
    -645,  3783,  3783,  3783,  3783,  -645,   175,   235,  -645,   119,
    4782,  4814,   132,   130,  4782,    38,  1303,  1497,  1586,  3783,
    1968,   -32,     0,  -645,    99,  -645,   152,   138,  3783,  3783,
     188,   175,  2587,   152,  -645,  3783,   157,  5587,  4846,  2619,
    -645,  3783,   168,   178,   -51,   175,  2651,   169,   183,  3783,
      71,  -645,   181,  5587,    -3,  5651,  3783,  3783,  3783,  3783,
    3783,  3783,  3783,  3783,  3783,  3783,   152,  3783,  3783,   152,
    3783,  3783,    35,    35,   194,   -40,   -40,   -40,  3783,   203,
    3783,  3783,  3783,  3783,  3783,  3783,  3783,  3783,  3783,  3783,
    3783,  3783,  3783,  3783,  3783,    42,  3783,  3783,  3783,  3783,
    3783,  4318,  3783,  3783,  3783,  3783,  3783,  3783,  3783,  3783,
    3783,  3783,  3783,  3783,  3783,  3783,  3783,  3783,  3783,  3783,
    3783,  3783,  3783,  -645,  -645,  1248,  2753,  4537,     8,  1968,
    3783,  -645,  -645,  -645,  -645,  -645,  -645,  -645,  -645,  -645,
    -645,  -645,  -645,  -645,  -645,  -645,  -645,  -645,  -645,  -645,
    -645,  -645,  -645,    38,  -645,  -645,   209,   208,   217,  -645,
    -645,  3783,    38,   221,   283,  2086,  3783,  -645,  2204,  3783,
    -645,  1968,   219,   225,   243,  -645,   -32,   140,  -645,  3783,
     -40,  3139,   103,   260,  -645,   -65,  1968,  -645,   238,  -645,
    -645,  1968,  -645,   109,  -645,  3242,   176,  -645,  1968,  -645,
    -645,  -645,  4883,  3783,  -645,  3783,  3783,  1729,   -58,   -58,
     -58,   -58,   -58,   -58,   -58,   -58,   -58,   -58,   -58,   -58,
     -58,   -58,  3783,   242,    41,    97,   112,  5587,  -645,  4915,
    4947,  4979,  5011,  5043,  5075,  5107,  5139,  5171,  5203,  5235,
    5267,  5299,  5331,  5363,  -645,  -645,  -645,   264,   263,  -645,
    5619,  5619,  5651,   344,  1541,  3104,  3205,   750,   812,   812,
     358,   358,   358,   358,   410,   410,   152,   152,    35,    35,
      35,   -58,   -58,   -58,  3883,  3783,  3928,  3783,  3783,  3783,
    4028,  -645,  2694,  -645,   164,    29,  -645,  4782,  5395,    72,
    -645,   292,  3242,   267,  3783,  3783,  -645,  5619,  2791,  3783,
    -645,  5619,  2823,   266,  5427,  1968,  -645,   145,   -23,   221,
    5619,  -645,   273,  3242,   314,   275,  3242,  3783,  -645,  -645,
    -645,   139,  -645,  3783,  -645,   277,  -645,  -645,  -645,     7,
    -645,  -645,  3783,   284,   175,  -645,  -645,  -645,  5587,  5459,
    3783,  -645,  5619,   243,  -645,  -645,  -645,  -645,  -645,  -645,
    -645,  -645,  -645,  -645,  -645,  -645,  -645,  -645,  -645,  -645,
    -645,  -645,  -645,  -645,  -645,  3783,  2898,  3783,  2930,  5491,
    3783,  1968,  -645,  -645,  -645,  -645,  -645,   221,  -645,  -645,
    -645,  -645,  -645,  -645,   -32,   163,  -645,    38,   209,  -645,
    -645,    38,   278,  3783,  -645,  2855,  4345,  2322,  -645,  4377,
    2440,  -645,  1968,  3783,  -645,  -645,   -32,  -645,   260,  3783,
    -645,   279,  3783,  -645,    15,  5587,  -645,  1968,  3783,  -645,
    -645,    83,    44,    38,  2558,  4409,   285,  4569,  4073,  4601,
    4173,  4218,  4633,  -645,   316,   198,   110,  -645,   290,  -645,
    -645,  -645,  5587,  1968,  -645,  1968,  3783,  -645,  5619,  1968,
    3783,  -645,  5619,  -645,  5587,   201,  -645,   286,  3783,   288,
    3783,    13,  -645,    -1,  -645,  3345,  -645,  3783,  -645,  5619,
    1968,  -645,   190,  3783,  3783,  3783,  3783,  3783,  3783,  3783,
     -14,  -645,   -32,  -645,   124,   -39,  -645,  5427,  4441,  5427,
    4473,  -645,   359,   291,  -645,  5523,  -645,  1968,  -645,  4505,
    5427,    38,  -645,  -645,  -645,  -645,  -645,  -645,  4665,  4697,
    4729,  5587,  -645,  -645,  -645,   207,   273,   293,  3242,  3242,
      38,  3738,  3493,  -645,  -645,   160,  -645,  -645,  -645,  -645,
    -645,  3738,  -645,  -645,  1968,  1968,  3783,  -645,   359,  3448,
    -645,  1968,   317,  3783,  3783,  3783,  -645,  3783,  -645,  -645,
     210,  -645,   321,  5587,  3036,   298,    47,   123,  3738,  3738,
     193,  -645,  5587,  5427,  5427,  5587,  -645,  -645,  5427,  3242,
     300,   301,  3738,  -645,  3738,  -645,  -645,  3036,  3783,  3036,
    -645,  -645,  -645,   304,   312,   310,   196,  -645,  -645,  -645,
    -645,  -645,  -645,  -645,  5555,  -645,  -645,  -645,  3242
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -645,  -645,  -152,  -645,   -43,    79,    74,  -645,  -645,  -645,
    -645,  -645,  -645,  -645,  -645,  -645,  -645,  -645,  -645,  -645,
    -645,  -645,  -645,  -645,   -49,  -645,  -197,  -645,  -645,   361,
    -645,    39,  -645,  -645,  -645,  -645,  -645,  -645,  -645,  -645,
    -645,  -645,  -645,  -103,   280,  -645,  -185,  -645,  -645,  -645,
    -645,  -548,  -645,  -145,  -645,     6,  -645,  -645,  -177,  -645,
    -645,  -176,  -645,   -94,  -125,  -645,  -645,  -645,  -173,  -645,
     108,   120,  -292,  -236,  -645,  -291,  -181,   126,  -515,  -645,
    -272,  -645,  -255,  -253,  -210,  -644,  -645,  -645,  -645,  -148,
     -42,   111,  -589,  1037,   420,  -645,   407,  -645,  -129,   971,
     371,   552,    -4,  -645,  -645
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If zero, do what YYDEFACT says.
   If YYTABLE_NINF, syntax error.  */
#define YYTABLE_NINF -294
static const yytype_int16 yytable[] =
{
     113,   279,   113,   113,   427,   279,   168,   308,   170,   174,
     439,   413,   113,   576,   617,   649,   323,   176,   177,    44,
     326,   113,   218,   299,   453,   446,   443,    44,    35,   432,
     316,   399,   121,   122,   113,   490,    44,    22,   580,   498,
     317,    24,   537,    26,   651,    28,    29,   141,   710,   120,
     711,    31,   499,    33,   500,   296,   643,   433,   364,   434,
     435,   436,   538,   242,   526,   501,   502,   580,   367,   368,
     698,    49,    44,    45,    46,    47,    48,  -229,   323,   503,
     323,   300,   248,    65,    49,   116,   117,   327,  -148,   323,
     653,   649,   365,   539,   675,   132,   323,    44,   400,    49,
      50,    44,   452,   681,   145,   581,   170,   305,   134,    53,
      54,    55,    56,    57,    58,   218,   504,   160,   537,   313,
     498,   439,   300,    59,    60,   323,   695,   161,   323,    61,
      62,    63,   465,   499,   585,   500,   113,   699,   538,   700,
     636,     3,   530,    44,    -2,   533,   501,   502,   637,   712,
     139,   715,   323,   511,   240,   241,   242,   528,   512,   324,
     503,   154,  -217,  -228,   155,   195,   251,   198,   638,   584,
     434,   435,   639,   701,   493,   287,   290,   292,   300,   301,
     243,  -217,    44,    44,    45,    46,    47,    48,   466,   281,
     323,   307,   196,   300,   451,  -217,     9,   602,   312,    12,
      22,   494,    14,   467,  -217,   319,   244,    17,   640,   197,
     252,   641,   555,   642,   495,   282,    33,   637,   496,   295,
    -217,   428,  -217,   304,  -217,   554,   428,  -217,   429,    32,
    -217,    34,   218,   525,   575,    44,    45,    46,    47,    48,
     621,    40,   677,   315,   556,   113,   325,   678,   309,   679,
     249,   557,    44,    45,    46,    47,    48,   215,   250,   314,
     320,   445,   216,   148,   217,   149,   237,   238,   239,   321,
    -291,   240,   241,   242,   342,  -291,   680,  -291,   677,   428,
     641,   113,   428,   678,   113,   679,   601,   113,   428,   611,
     407,   692,   178,   179,   348,   666,   405,   441,   693,  -288,
     463,   412,   113,   344,   345,   346,   414,   113,   180,   181,
     635,   441,   425,   426,   113,   218,   182,   183,   184,   185,
      49,   190,   191,   113,   323,   443,   448,   464,   401,   219,
     220,   221,   222,   223,   224,   225,   226,   227,   228,   229,
     230,   231,   232,   233,   234,   235,   236,   530,   533,   237,
     238,   239,   483,   484,   240,   241,   242,   513,   514,   522,
     529,   531,   532,   536,   416,   543,   578,   420,   687,   561,
     604,   591,   599,   656,   612,   111,   614,   111,   111,   658,
     667,   577,   689,   696,   579,   447,   694,   111,   697,   709,
     450,   708,   716,   692,   592,   534,   111,   455,   707,   151,
     717,   461,   541,   632,   167,   559,   713,   623,   441,   111,
     542,   603,   165,   508,   283,   624,   625,   560,   586,   627,
     431,   113,   686,   644,   218,   706,   705,   687,   442,   441,
     613,   670,   441,   129,   457,   150,     0,     0,   218,     0,
       0,   492,   223,   224,   225,   226,   227,   228,   229,   230,
     231,   232,   233,   234,   235,   236,     0,   518,   237,   238,
     239,   521,     0,   240,   241,   242,   233,   234,   235,   236,
       0,     0,   237,   238,   239,   650,     0,   240,   241,   242,
       0,     0,     0,     0,     0,     0,     0,   113,     0,     0,
     218,     0,     0,     0,     0,     0,   583,     0,     0,     0,
       0,     0,     0,     0,   524,     0,     0,     0,     0,     0,
       0,   111,     0,   113,     0,     0,   113,     0,   113,   691,
     235,   236,     0,     0,   237,   238,   239,     0,     0,   240,
     241,   242,     0,   113,     0,     0,     0,     0,     0,     0,
     113,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   650,     0,     0,   564,   292,     0,     0,   292,   113,
       0,   113,     0,   127,     0,   113,     0,   131,     0,     0,
     553,   136,   137,   138,     0,     0,     0,   441,   146,     0,
       0,   441,   152,   153,   292,     0,   113,   157,   158,   159,
       0,     0,     0,     0,   166,   157,   567,     0,     0,   571,
     676,   573,   173,   173,     0,   175,     0,     0,     0,     0,
       0,   186,   189,   113,   192,   193,   582,     0,     0,     0,
     111,     0,   618,   588,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   441,   441,     0,     0,     0,   633,
       0,     0,   606,     0,     0,     0,     0,   292,     0,   292,
     113,   113,     0,     0,     0,   441,   111,   113,   292,   111,
       0,     0,   111,     0,     0,     0,     0,     0,     0,     0,
     441,     0,     0,   245,   246,   247,   173,   111,     0,     0,
       0,     0,   111,     0,     0,   441,     0,   454,     0,   111,
       0,   173,     0,   441,     0,   441,   660,     0,   111,     0,
     173,   173,     0,     0,     0,     0,     0,   173,     0,     0,
       0,     0,     0,   173,   441,     0,     0,     0,     0,     0,
       0,   322,     0,     0,     0,     0,     0,     0,   328,   329,
     330,   331,   332,   333,   334,   335,   336,   337,     0,   338,
     339,     0,   340,   341,     0,     0,     0,     0,     0,     0,
     347,     0,   349,   350,   351,   352,   353,   354,   355,   356,
     357,   358,   359,   360,   361,   362,   363,     0,   173,   173,
     369,   370,   371,   372,   373,   374,   375,   376,   377,   378,
     379,   380,   381,   382,   383,   384,   385,   386,   387,   388,
     389,   390,   391,   392,   393,     0,   111,     0,     0,     0,
       0,     0,   402,     0,   121,   122,     0,   123,     0,    22,
       0,     0,     0,    24,     0,    26,     0,    28,    29,     0,
       0,     0,     0,    31,     0,    33,     0,     0,     0,     0,
     218,     0,     0,   408,     0,     0,     0,   417,   418,     0,
     421,   422,     0,   424,    44,    45,    46,    47,    48,     0,
       0,   430,   227,   228,   229,   230,   231,   232,   233,   234,
     235,   236,   111,     0,   237,   238,   239,     0,     0,   240,
     241,   242,    50,     0,   124,   173,     0,   458,   459,   462,
       0,    53,    54,    55,    56,    57,    58,     0,   111,     0,
       0,   111,   218,   111,   173,    59,    60,     0,     0,     0,
       0,    61,    62,    63,   187,   188,     0,     0,   111,     0,
       0,     0,     0,     0,     0,   111,   229,   230,   231,   232,
     233,   234,   235,   236,     0,     0,   237,   238,   239,     0,
       0,   240,   241,   242,   111,     0,   111,     0,     0,     0,
     111,     0,     0,     0,     0,     0,   417,   486,   421,   488,
     424,   489,   462,     0,     0,     0,     0,     0,     0,     0,
       0,   111,     0,     0,     0,     0,   515,   516,     0,     0,
       0,   519,     0,     0,     0,   110,     0,   110,   110,     0,
       0,     0,     0,     0,     0,     0,     0,   110,   111,   173,
       0,     0,     0,     0,     0,   535,   110,     0,     0,     0,
       0,     0,     0,     0,   173,     0,     0,     0,     0,   110,
       0,     0,   545,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   111,   111,     0,     0,     0,
       0,     0,   111,     0,     0,     0,     0,   547,     0,   549,
       0,     0,   552,     0,     0,   118,     0,     0,     0,     0,
     118,     0,     0,     0,   133,     0,     0,     0,     0,     0,
     140,   144,     0,     0,   147,   562,     0,     0,     0,   568,
       0,     0,   572,     0,     0,   574,   163,     0,     0,     0,
       0,   173,     0,     0,   173,     0,     0,   172,   172,     0,
     173,     0,     0,     0,     0,     0,   589,     0,     0,     0,
     568,     0,   572,   589,     0,     0,     0,     0,     0,     0,
       0,   110,     0,     0,     0,     0,     0,   607,   608,     0,
       0,   609,   610,     0,     0,     0,     0,     0,     0,     0,
     173,     0,   615,   462,     0,     0,   194,   462,     0,   619,
       0,     0,   620,     0,     0,   607,   628,   609,   629,   630,
     620,   631,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   172,     0,     0,     0,     0,     0,   278,     0,     0,
       0,   278,   284,     0,     0,     0,   172,     0,   298,     0,
       0,     0,     0,     0,     0,   172,   172,     0,     0,     0,
       0,     0,   172,   673,   173,     0,     0,     0,   172,     0,
       0,     0,     0,   682,     0,     0,   683,   684,   685,     0,
       0,   589,     0,   688,     0,   683,   684,   688,     0,   173,
     110,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     673,   673,   144,   144,   144,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   673,     0,   673,     0,     0,     0,
     714,     0,   366,   172,   172,     0,   110,     0,     0,   110,
       0,     0,   110,   394,     0,     0,     0,     0,     0,     0,
       0,   395,     0,     0,     0,     0,     0,   110,     0,     0,
       0,     0,   110,     0,     0,     0,     0,     0,     0,   110,
       0,     0,     0,     0,     0,     0,     0,     0,   110,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     403,     0,     0,     0,     0,     0,     0,     0,   285,   411,
       0,     0,     0,     0,     0,     0,   286,     0,   218,     0,
       0,     0,     0,   298,     0,     0,     0,   144,     0,     0,
       0,     0,   219,   220,   221,   222,   223,   224,   225,   226,
     227,   228,   229,   230,   231,   232,   233,   234,   235,   236,
     172,     0,   237,   238,   239,     0,     0,   240,   241,   242,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   172,
       0,     0,     0,   218,     0,     0,     0,     0,    49,     0,
       0,     0,     0,     0,     0,     0,   110,   219,   220,   221,
     222,   223,   224,   225,   226,   227,   228,   229,   230,   231,
     232,   233,   234,   235,   236,     0,     0,   237,   238,   239,
       0,     0,   240,   241,   242,   200,   201,   202,   203,   204,
     205,   206,   207,   208,   209,   210,   211,   212,   213,   214,
       0,     0,   215,     0,   509,     0,     0,   216,     0,   217,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   110,     0,     0,   527,     0,     0,     0,     0,
       0,     0,     0,     0,   172,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   110,   172,
       0,   110,     0,   110,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   110,     0,
       0,     0,   288,     0,     0,   110,     0,     0,     0,     0,
     289,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   110,     0,   110,     0,     0,     0,
     110,   298,     0,     0,   558,     0,     0,     0,   411,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   110,     0,   298,     0,     0,   172,     0,     0,   172,
       0,     0,     0,     0,     0,   172,     0,   218,     0,     0,
     163,     0,    49,     0,     0,     0,     0,     0,   110,     0,
       0,   219,   220,   221,   222,   223,   224,   225,   226,   227,
     228,   229,   230,   231,   232,   233,   234,   235,   236,     0,
       0,   237,   238,   239,     0,   172,   240,   241,   242,     0,
       0,   218,     0,     0,     0,   110,   110,     0,     0,     0,
       0,     0,   110,     0,     0,   291,     0,     0,     0,   298,
     224,   225,   226,   227,   228,   229,   230,   231,   232,   233,
     234,   235,   236,     0,     0,   237,   238,   239,   662,     0,
     240,   241,   242,     0,     0,     0,   218,     0,     0,     0,
       0,    49,     0,     0,     0,     0,     0,   668,   672,   172,
     219,   220,   221,   222,   223,   224,   225,   226,   227,   228,
     229,   230,   231,   232,   233,   234,   235,   236,     0,     0,
     237,   238,   239,     0,   172,   240,   241,   242,     0,     0,
       0,     0,     0,     0,   702,   672,   672,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   672,
       5,   672,     6,     7,     8,     9,    10,    11,    12,  -202,
      13,    14,    15,     0,    16,     0,    17,    18,    19,    20,
       0,   460,     0,    22,     0,     0,    23,    24,    25,    26,
      27,    28,    29,    30,     0,     0,  -202,    31,     0,    33,
      34,    35,    36,     0,    37,     0,     0,    38,     0,    39,
      40,    41,     0,  -202,     0,     0,    42,    43,    44,    45,
      46,    47,    48,  -293,  -293,  -293,  -293,  -293,  -293,  -293,
    -293,  -293,  -293,  -293,  -293,  -293,  -293,  -293,  -293,  -293,
       0,  -293,     0,     0,    49,     0,    50,     0,    51,     0,
    -293,     0,  -293,  -293,  -293,    53,    54,    55,    56,    57,
      58,  -293,  -293,  -293,  -293,  -293,  -293,  -293,  -293,    59,
      60,     0,     0,  -293,  -293,    61,    62,    63,  -293,  -293,
    -293,     5,     0,     6,     7,     8,     9,    10,    11,    12,
    -202,    13,    14,    15,     0,    16,     0,    17,    18,    19,
      20,     0,    21,     0,    22,     0,     0,    23,    24,    25,
      26,    27,    28,    29,    30,     0,     0,  -202,    31,    32,
      33,    34,    35,    36,     0,    37,     0,     0,    38,     0,
      39,    40,    41,     0,  -202,     0,     0,    42,    43,    44,
      45,    46,    47,    48,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    49,     0,    50,     0,    51,
       0,    52,     0,     0,     0,     0,    53,    54,    55,    56,
      57,    58,     0,     0,     0,     0,     0,     0,     0,     0,
      59,    60,     0,     0,     0,     0,    61,    62,    63,     5,
       0,     6,     7,     8,     9,    10,    11,    12,  -202,    13,
      14,    15,     0,    16,     0,    17,    18,    19,    20,     0,
      21,     0,    22,     0,     0,    23,    24,    25,    26,    27,
      28,    29,    30,     0,     0,  -202,    31,     0,    33,    34,
      35,    36,     0,    37,     0,     0,    38,     0,    39,    40,
      41,     0,  -202,     0,     0,    42,    43,    44,    45,    46,
      47,    48,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    49,     0,    50,     0,    51,     0,    52,
       0,     0,     0,     0,    53,    54,    55,    56,    57,    58,
       0,     0,     0,     0,     0,     0,     0,     0,    59,    60,
       0,     0,     0,     0,    61,    62,    63,     5,     0,     6,
       7,     8,     9,    10,    11,    12,  -202,    13,    14,    15,
       0,    16,     0,    17,    18,    19,    20,     0,   415,     0,
      22,     0,     0,    23,    24,    25,    26,    27,    28,    29,
      30,     0,     0,  -202,    31,     0,    33,    34,    35,    36,
       0,    37,     0,     0,    38,     0,    39,    40,    41,     0,
    -202,     0,     0,    42,    43,    44,    45,    46,    47,    48,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    49,     0,    50,     0,    51,     0,    52,     0,     0,
       0,     0,    53,    54,    55,    56,    57,    58,     0,     0,
       0,     0,     0,     0,     0,     0,    59,    60,     0,     0,
       0,     0,    61,    62,    63,     5,     0,     6,     7,     8,
       9,    10,    11,    12,  -202,    13,    14,    15,     0,    16,
       0,    17,    18,    19,    20,     0,   419,     0,    22,     0,
       0,    23,    24,    25,    26,    27,    28,    29,    30,     0,
       0,  -202,    31,     0,    33,    34,    35,    36,     0,    37,
       0,     0,    38,     0,    39,    40,    41,     0,  -202,     0,
       0,    42,    43,    44,    45,    46,    47,    48,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    49,
       0,    50,     0,    51,     0,    52,     0,     0,     0,     0,
      53,    54,    55,    56,    57,    58,     0,     0,     0,     0,
       0,     0,     0,     0,    59,    60,     0,     0,     0,     0,
      61,    62,    63,     5,     0,     6,     7,     8,     9,    10,
      11,    12,  -202,    13,    14,    15,     0,    16,     0,    17,
      18,    19,    20,     0,   566,     0,    22,     0,     0,    23,
      24,    25,    26,    27,    28,    29,    30,     0,     0,  -202,
      31,     0,    33,    34,    35,    36,     0,    37,     0,     0,
      38,     0,    39,    40,    41,     0,  -202,     0,     0,    42,
      43,    44,    45,    46,    47,    48,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    49,     0,    50,
       0,    51,     0,    52,     0,     0,     0,     0,    53,    54,
      55,    56,    57,    58,     0,     0,     0,     0,     0,     0,
       0,     0,    59,    60,     0,     0,     0,     0,    61,    62,
      63,     5,     0,     6,     7,     8,     9,    10,    11,    12,
    -202,    13,    14,    15,     0,    16,     0,    17,    18,    19,
      20,     0,   570,     0,    22,     0,     0,    23,    24,    25,
      26,    27,    28,    29,    30,     0,     0,  -202,    31,     0,
      33,    34,    35,    36,     0,    37,     0,     0,    38,     0,
      39,    40,    41,     0,  -202,     0,     0,    42,    43,    44,
      45,    46,    47,    48,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    49,     0,    50,     0,    51,
       0,    52,     0,     0,     0,     0,    53,    54,    55,    56,
      57,    58,     0,     0,     0,     0,     0,     0,     0,     0,
      59,    60,     0,     0,     0,     0,    61,    62,    63,     5,
       0,     6,     7,     8,     9,    10,    11,    12,  -202,    13,
      14,    15,     0,    16,     0,    17,    18,    19,    20,     0,
     587,     0,    22,     0,     0,    23,    24,    25,    26,    27,
      28,    29,    30,     0,     0,  -202,    31,     0,    33,    34,
      35,    36,   306,    37,     0,     0,    38,     0,    39,    40,
      41,     0,  -202,     0,     0,    42,    43,    44,    45,    46,
      47,    48,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   311,     0,     0,     0,     0,     0,
       0,     0,     0,    49,     0,    50,     0,    51,     0,    52,
       0,     0,     0,     0,    53,    54,    55,    56,    57,    58,
       0,     0,     0,     0,     0,     0,   318,   218,    59,    60,
       0,     0,    49,     0,    61,    62,    63,     0,     0,     0,
       0,   219,   220,   221,   222,   223,   224,   225,   226,   227,
     228,   229,   230,   231,   232,   233,   234,   235,   236,   218,
       0,   237,   238,   239,    49,     0,   240,   241,   242,   491,
       0,     0,     0,   219,   220,   221,   222,   223,   224,   225,
     226,   227,   228,   229,   230,   231,   232,   233,   234,   235,
     236,   218,     0,   237,   238,   239,    49,     0,   240,   241,
     242,     0,     0,     0,     0,   219,   220,   221,   222,   223,
     224,   225,   226,   227,   228,   229,   230,   231,   232,   233,
     234,   235,   236,     0,     0,   237,   238,   239,   396,     0,
     240,   241,   242,     0,   218,     0,   397,     0,     0,    49,
       0,     0,     0,     0,     0,     0,     0,     0,   219,   220,
     221,   222,   223,   224,   225,   226,   227,   228,   229,   230,
     231,   232,   233,   234,   235,   236,   517,     0,   237,   238,
     239,     0,     0,   240,   241,   242,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   218,     0,     0,     0,     0,   520,     0,
       0,     0,     0,     0,     0,     0,     0,   219,   220,   221,
     222,   223,   224,   225,   226,   227,   228,   229,   230,   231,
     232,   233,   234,   235,   236,     0,     0,   237,   238,   239,
     563,   218,   240,   241,   242,     0,    49,     0,     0,     0,
       0,     0,     0,     0,     0,   219,   220,   221,   222,   223,
     224,   225,   226,   227,   228,   229,   230,   231,   232,   233,
     234,   235,   236,   218,     0,   237,   238,   239,    49,     0,
     240,   241,   242,   548,     0,     0,     0,   219,   220,   221,
     222,   223,   224,   225,   226,   227,   228,   229,   230,   231,
     232,   233,   234,   235,   236,   218,     0,   237,   238,   239,
      49,     0,   240,   241,   242,   550,     0,     0,     0,   219,
     220,   221,   222,   223,   224,   225,   226,   227,   228,   229,
     230,   231,   232,   233,   234,   235,   236,     0,     0,   237,
     238,   239,     0,     0,   240,   241,   242,     0,   218,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   219,   220,   221,   222,   223,   224,   225,   226,
     227,   228,   229,   230,   231,   232,   233,   234,   235,   236,
     218,     0,   237,   238,   239,     0,     0,   240,   241,   242,
       0,     0,     0,     0,   219,   220,   221,   222,   223,   224,
     225,   226,   227,   228,   229,   230,   231,   232,   233,   234,
     235,   236,     0,     0,   237,   238,   239,     0,     0,   240,
     241,   242,   432,     0,     0,   121,   122,     0,   123,     0,
      22,     0,     0,     0,    24,     0,    26,     0,    28,    29,
       0,     0,     0,     0,    31,     0,    33,     0,     0,     0,
     433,     0,   434,   435,   436,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    44,    45,    46,    47,    48,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     640,     0,     0,    50,     0,   452,     0,     0,     0,     0,
       0,     0,    53,    54,    55,    56,    57,    58,     0,     0,
       0,     0,     0,     0,     0,     0,    59,    60,     0,     0,
       0,     0,    61,    62,    63,   432,     0,     0,   121,   122,
       0,   123,     0,    22,     0,     0,     0,    24,     0,    26,
       0,    28,    29,     0,     0,     0,     0,    31,     0,    33,
       0,     0,     0,   433,   218,   434,   435,   436,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,    44,    45,
      46,    47,    48,     0,   225,   226,   227,   228,   229,   230,
     231,   232,   233,   234,   235,   236,     0,     0,   237,   238,
     239,     0,     0,   240,   241,   242,    50,     0,   437,     0,
       0,     0,     0,     0,     0,    53,    54,    55,    56,    57,
      58,     0,     0,     0,     0,     0,     0,     0,     0,    59,
      60,     0,     0,     0,     0,    61,    62,    63,   432,     0,
       0,   121,   122,     0,   123,     0,    22,     0,     0,     0,
      24,     0,    26,     0,    28,    29,     0,     0,     0,     0,
      31,     0,    33,     0,     0,   218,   433,     0,   434,   435,
     436,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    44,    45,    46,    47,    48,   226,   227,   228,   229,
     230,   231,   232,   233,   234,   235,   236,     0,     0,   237,
     238,   239,     0,     0,   240,   241,   242,     0,     0,    50,
       0,   452,     0,     0,     0,     0,     0,     0,    53,    54,
      55,    56,    57,    58,     0,     0,     0,     0,     0,     0,
       0,     0,    59,    60,     0,     0,     0,     0,    61,    62,
      63,   432,     0,     0,   121,   122,     0,   490,     0,    22,
       0,     0,     0,    24,     0,    26,     0,    28,    29,     0,
       0,     0,     0,    31,     0,    33,     0,     0,     0,   433,
       0,   434,   435,   436,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    44,    45,    46,    47,    48,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    50,     0,   452,     0,     0,     0,     0,     0,
       0,    53,    54,    55,    56,    57,    58,     0,     0,     0,
       0,     0,     0,     0,     0,    59,    60,     0,     0,     0,
       0,    61,    62,    63,   432,     0,     0,   121,   122,     0,
     597,     0,    22,     0,     0,     0,    24,     0,    26,     0,
      28,    29,     0,     0,     0,     0,    31,     0,    33,     0,
       0,     0,   433,     0,   434,   435,   436,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    44,    45,    46,
      47,    48,   121,   122,     0,   123,     0,    22,     0,     0,
       0,    24,     0,    26,     0,    28,    29,     0,     0,     0,
       0,    31,     0,    33,     0,    50,     0,   452,     0,     0,
       0,     0,     0,     0,    53,    54,    55,    56,    57,    58,
       0,     0,    44,    45,    46,    47,    48,     0,    59,    60,
       0,     0,     0,     0,    61,    62,    63,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   640,     0,     0,
      50,     0,   124,   674,     0,     0,     0,     0,     0,    53,
      54,    55,    56,    57,    58,     0,     0,     0,     0,     0,
       0,     0,     0,    59,    60,     0,     0,     0,     0,    61,
      62,    63,   121,   122,     0,   123,     0,    22,     0,     0,
       0,    24,     0,    26,     0,    28,    29,     0,     0,     0,
     135,    31,     0,    33,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    44,    45,    46,    47,    48,   121,   122,     0,
     123,     0,    22,     0,     0,     0,    24,     0,    26,     0,
      28,    29,     0,     0,     0,     0,    31,     0,    33,     0,
      50,     0,   124,     0,     0,     0,     0,     0,     0,    53,
      54,    55,    56,    57,    58,     0,     0,    44,    45,    46,
      47,    48,     0,    59,    60,     0,     0,     0,     0,    61,
      62,    63,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   169,     0,     0,     0,    50,     0,   124,     0,     0,
       0,     0,     0,     0,    53,    54,    55,    56,    57,    58,
       0,     0,     0,     0,     0,     0,     0,     0,    59,    60,
       0,     0,     0,     0,    61,    62,    63,   121,   122,     0,
     123,     0,    22,     0,     0,     0,    24,     0,    26,     0,
      28,    29,     0,     0,     0,     0,    31,     0,    33,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    44,    45,    46,
      47,    48,   121,   122,     0,   123,     0,    22,     0,     0,
       0,    24,     0,    26,     0,    28,    29,     0,     0,     0,
       0,    31,   640,    33,     0,    50,     0,   124,     0,     0,
       0,     0,     0,     0,    53,    54,    55,    56,    57,    58,
       0,     0,    44,    45,    46,    47,    48,     0,    59,    60,
       0,     0,     0,     0,    61,    62,    63,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      50,     0,   124,     0,     0,     0,     0,     0,     0,    53,
      54,    55,    56,    57,    58,     0,     0,     0,     0,     0,
       0,     0,     0,    59,    60,     0,     0,     0,     0,    61,
      62,    63,   121,   122,     0,   485,     0,    22,     0,     0,
       0,    24,     0,    26,     0,    28,    29,     0,     0,     0,
       0,    31,     0,    33,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    44,    45,    46,    47,    48,   121,   122,     0,
     487,     0,    22,     0,     0,     0,    24,     0,    26,     0,
      28,    29,     0,     0,     0,     0,    31,     0,    33,     0,
      50,     0,   124,     0,     0,     0,     0,     0,     0,    53,
      54,    55,    56,    57,    58,     0,     0,    44,    45,    46,
      47,    48,     0,    59,    60,     0,     0,     0,     0,    61,
      62,    63,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    50,     0,   124,     0,     0,
       0,     0,     0,     0,    53,    54,    55,    56,    57,    58,
       0,     0,     0,     0,     0,     0,     0,     0,    59,    60,
       0,     0,     0,     0,    61,    62,    63,   121,   122,     0,
     490,     0,    22,     0,     0,     0,    24,     0,    26,     0,
      28,    29,     0,     0,     0,     0,    31,     0,    33,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    44,    45,    46,
      47,    48,   121,   122,     0,   594,     0,    22,     0,     0,
       0,    24,     0,    26,     0,    28,    29,     0,     0,     0,
       0,    31,     0,    33,     0,    50,     0,   124,     0,     0,
       0,     0,     0,     0,    53,    54,    55,    56,    57,    58,
       0,     0,    44,    45,    46,    47,    48,     0,    59,    60,
       0,     0,     0,     0,    61,    62,    63,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      50,     0,   124,     0,     0,     0,     0,     0,     0,    53,
      54,    55,    56,    57,    58,     0,     0,     0,     0,     0,
       0,     0,     0,    59,    60,     0,     0,     0,     0,    61,
      62,    63,   121,   122,     0,   596,     0,    22,     0,     0,
       0,    24,     0,    26,     0,    28,    29,     0,     0,     0,
       0,    31,     0,    33,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    44,    45,    46,    47,    48,   121,   122,     0,
     597,     0,    22,     0,     0,     0,    24,     0,    26,     0,
      28,    29,     0,     0,     0,     0,    31,     0,    33,     0,
      50,     0,   124,     0,     0,     0,     0,     0,     0,    53,
      54,    55,    56,    57,    58,     0,     0,    44,    45,    46,
      47,    48,     0,    59,    60,     0,     0,     0,     0,    61,
      62,    63,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    50,     0,   124,     0,     0,
       0,     0,     0,     0,    53,    54,    55,    56,    57,    58,
       0,     0,     0,     0,     0,     0,     0,     0,    59,    60,
       0,     0,     0,     0,    61,    62,    63,   121,   122,     0,
     123,     0,    22,     0,     0,     0,    24,     0,    26,     0,
      28,    29,     0,     0,     0,     0,    31,     0,    33,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    44,    45,    46,
      47,    48,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   565,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    50,     0,   124,     0,     0,
       0,     0,     0,     0,     0,    54,    55,    56,    57,    58,
       0,     0,     0,     0,     0,   218,   569,     0,    59,    60,
      49,     0,     0,     0,    61,    62,    63,     0,     0,   219,
     220,   221,   222,   223,   224,   225,   226,   227,   228,   229,
     230,   231,   232,   233,   234,   235,   236,   218,   590,   237,
     238,   239,    49,     0,   240,   241,   242,     0,     0,     0,
       0,   219,   220,   221,   222,   223,   224,   225,   226,   227,
     228,   229,   230,   231,   232,   233,   234,   235,   236,   218,
     654,   237,   238,   239,    49,     0,   240,   241,   242,     0,
       0,     0,     0,   219,   220,   221,   222,   223,   224,   225,
     226,   227,   228,   229,   230,   231,   232,   233,   234,   235,
     236,   218,   655,   237,   238,   239,    49,     0,   240,   241,
     242,     0,     0,     0,     0,   219,   220,   221,   222,   223,
     224,   225,   226,   227,   228,   229,   230,   231,   232,   233,
     234,   235,   236,   218,   661,   237,   238,   239,    49,     0,
     240,   241,   242,     0,     0,     0,     0,   219,   220,   221,
     222,   223,   224,   225,   226,   227,   228,   229,   230,   231,
     232,   233,   234,   235,   236,   218,   398,   237,   238,   239,
      49,     0,   240,   241,   242,     0,     0,     0,     0,   219,
     220,   221,   222,   223,   224,   225,   226,   227,   228,   229,
     230,   231,   232,   233,   234,   235,   236,   218,   593,   237,
     238,   239,     0,     0,   240,   241,   242,     0,     0,     0,
       0,   219,   220,   221,   222,   223,   224,   225,   226,   227,
     228,   229,   230,   231,   232,   233,   234,   235,   236,   218,
     595,   237,   238,   239,     0,     0,   240,   241,   242,     0,
       0,     0,     0,   219,   220,   221,   222,   223,   224,   225,
     226,   227,   228,   229,   230,   231,   232,   233,   234,   235,
     236,   218,   598,   237,   238,   239,     0,     0,   240,   241,
     242,     0,     0,     0,     0,   219,   220,   221,   222,   223,
     224,   225,   226,   227,   228,   229,   230,   231,   232,   233,
     234,   235,   236,   218,   663,   237,   238,   239,     0,     0,
     240,   241,   242,     0,     0,     0,     0,   219,   220,   221,
     222,   223,   224,   225,   226,   227,   228,   229,   230,   231,
     232,   233,   234,   235,   236,   218,   664,   237,   238,   239,
       0,     0,   240,   241,   242,     0,     0,     0,     0,   219,
     220,   221,   222,   223,   224,   225,   226,   227,   228,   229,
     230,   231,   232,   233,   234,   235,   236,   218,   665,   237,
     238,   239,     0,     0,   240,   241,   242,     0,     0,     0,
       0,   219,   220,   221,   222,   223,   224,   225,   226,   227,
     228,   229,   230,   231,   232,   233,   234,   235,   236,   218,
       0,   237,   238,   239,     0,     0,   240,   241,   242,     0,
       0,     0,     0,   219,   220,   221,   222,   223,   224,   225,
     226,   227,   228,   229,   230,   231,   232,   233,   234,   235,
     236,    44,     0,   237,   238,   239,     0,   253,   240,   241,
     242,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   254,   255,     0,     0,
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   218,     0,   269,   270,   271,   272,
     273,     0,     0,   274,     0,   280,     0,     0,   219,   220,
     221,   222,   223,   224,   225,   226,   227,   228,   229,   230,
     231,   232,   233,   234,   235,   236,   218,     0,   237,   238,
     239,   310,     0,   240,   241,   242,     0,     0,     0,     0,
     219,   220,   221,   222,   223,   224,   225,   226,   227,   228,
     229,   230,   231,   232,   233,   234,   235,   236,     0,     0,
     237,   238,   239,   218,     0,   240,   241,   242,     0,     0,
       0,   456,     0,     0,     0,     0,     0,   219,   220,   221,
     222,   223,   224,   225,   226,   227,   228,   229,   230,   231,
     232,   233,   234,   235,   236,   218,     0,   237,   238,   239,
       0,     0,   240,   241,   242,     0,   468,     0,     0,   219,
     220,   221,   222,   223,   224,   225,   226,   227,   228,   229,
     230,   231,   232,   233,   234,   235,   236,   218,     0,   237,
     238,   239,     0,     0,   240,   241,   242,     0,   469,     0,
       0,   219,   220,   221,   222,   223,   224,   225,   226,   227,
     228,   229,   230,   231,   232,   233,   234,   235,   236,   218,
       0,   237,   238,   239,     0,     0,   240,   241,   242,     0,
     470,     0,     0,   219,   220,   221,   222,   223,   224,   225,
     226,   227,   228,   229,   230,   231,   232,   233,   234,   235,
     236,   218,     0,   237,   238,   239,     0,     0,   240,   241,
     242,     0,   471,     0,     0,   219,   220,   221,   222,   223,
     224,   225,   226,   227,   228,   229,   230,   231,   232,   233,
     234,   235,   236,   218,     0,   237,   238,   239,     0,     0,
     240,   241,   242,     0,   472,     0,     0,   219,   220,   221,
     222,   223,   224,   225,   226,   227,   228,   229,   230,   231,
     232,   233,   234,   235,   236,   218,     0,   237,   238,   239,
       0,     0,   240,   241,   242,     0,   473,     0,     0,   219,
     220,   221,   222,   223,   224,   225,   226,   227,   228,   229,
     230,   231,   232,   233,   234,   235,   236,   218,     0,   237,
     238,   239,     0,     0,   240,   241,   242,     0,   474,     0,
       0,   219,   220,   221,   222,   223,   224,   225,   226,   227,
     228,   229,   230,   231,   232,   233,   234,   235,   236,   218,
       0,   237,   238,   239,     0,     0,   240,   241,   242,     0,
     475,     0,     0,   219,   220,   221,   222,   223,   224,   225,
     226,   227,   228,   229,   230,   231,   232,   233,   234,   235,
     236,   218,     0,   237,   238,   239,     0,     0,   240,   241,
     242,     0,   476,     0,     0,   219,   220,   221,   222,   223,
     224,   225,   226,   227,   228,   229,   230,   231,   232,   233,
     234,   235,   236,   218,     0,   237,   238,   239,     0,     0,
     240,   241,   242,     0,   477,     0,     0,   219,   220,   221,
     222,   223,   224,   225,   226,   227,   228,   229,   230,   231,
     232,   233,   234,   235,   236,   218,     0,   237,   238,   239,
       0,     0,   240,   241,   242,     0,   478,     0,     0,   219,
     220,   221,   222,   223,   224,   225,   226,   227,   228,   229,
     230,   231,   232,   233,   234,   235,   236,   218,     0,   237,
     238,   239,     0,     0,   240,   241,   242,     0,   479,     0,
       0,   219,   220,   221,   222,   223,   224,   225,   226,   227,
     228,   229,   230,   231,   232,   233,   234,   235,   236,   218,
       0,   237,   238,   239,     0,     0,   240,   241,   242,     0,
     480,     0,     0,   219,   220,   221,   222,   223,   224,   225,
     226,   227,   228,   229,   230,   231,   232,   233,   234,   235,
     236,   218,     0,   237,   238,   239,     0,     0,   240,   241,
     242,     0,   481,     0,     0,   219,   220,   221,   222,   223,
     224,   225,   226,   227,   228,   229,   230,   231,   232,   233,
     234,   235,   236,   218,     0,   237,   238,   239,     0,     0,
     240,   241,   242,     0,   482,     0,     0,   219,   220,   221,
     222,   223,   224,   225,   226,   227,   228,   229,   230,   231,
     232,   233,   234,   235,   236,   218,     0,   237,   238,   239,
       0,     0,   240,   241,   242,     0,   510,     0,     0,   219,
     220,   221,   222,   223,   224,   225,   226,   227,   228,   229,
     230,   231,   232,   233,   234,   235,   236,   218,     0,   237,
     238,   239,     0,     0,   240,   241,   242,     0,     0,     0,
     523,   219,   220,   221,   222,   223,   224,   225,   226,   227,
     228,   229,   230,   231,   232,   233,   234,   235,   236,   218,
       0,   237,   238,   239,     0,     0,   240,   241,   242,   544,
       0,     0,     0,   219,   220,   221,   222,   223,   224,   225,
     226,   227,   228,   229,   230,   231,   232,   233,   234,   235,
     236,   218,     0,   237,   238,   239,     0,     0,   240,   241,
     242,   551,     0,     0,     0,   219,   220,   221,   222,   223,
     224,   225,   226,   227,   228,   229,   230,   231,   232,   233,
     234,   235,   236,   218,     0,   237,   238,   239,     0,     0,
     240,   241,   242,   659,     0,     0,     0,   219,   220,   221,
     222,   223,   224,   225,   226,   227,   228,   229,   230,   231,
     232,   233,   234,   235,   236,   218,     0,   237,   238,   239,
       0,     0,   240,   241,   242,   718,     0,     0,     0,   219,
     220,   221,   222,   223,   224,   225,   226,   227,   228,   229,
     230,   231,   232,   233,   234,   235,   236,   218,     0,   237,
     238,   239,     0,     0,   240,   241,   242,     0,     0,     0,
       0,   219,   220,   221,   222,   223,   224,   225,   226,   227,
     228,   229,   230,   231,   232,   233,   234,   235,   236,   218,
       0,   237,   238,   239,     0,     0,   240,   241,   242,     0,
       0,     0,     0,     0,     0,   221,   222,   223,   224,   225,
     226,   227,   228,   229,   230,   231,   232,   233,   234,   235,
     236,   218,     0,   237,   238,   239,     0,     0,   240,   241,
     242,     0,     0,     0,     0,     0,     0,     0,   222,   223,
     224,   225,   226,   227,   228,   229,   230,   231,   232,   233,
     234,   235,   236,     0,     0,   237,   238,   239,     0,     0,
     240,   241,   242
};

static const yytype_int16 yycheck[] =
{
       4,   130,     6,     7,   296,   134,    49,   155,    50,    51,
     301,   283,    16,   528,    15,   604,    81,   119,   120,    59,
      23,    25,    80,    23,   315,    90,    65,    59,    42,    16,
      81,    23,    19,    20,    38,    22,    59,    24,    23,    10,
      91,    28,    35,    30,    83,    32,    33,    87,   692,    10,
     694,    38,    23,    40,    25,    87,   604,    44,    16,    46,
      47,    48,    55,   121,    87,    36,    37,    23,   216,   217,
      23,    85,    59,    60,    61,    62,    63,    64,    81,    50,
      81,    81,   124,     4,    85,     6,     7,    90,    59,    81,
     605,   680,    50,    86,   642,    16,    81,    59,    90,    85,
      87,    59,    89,   651,    25,    90,   148,   149,    12,    96,
      97,    98,    99,   100,   101,    80,    87,    38,    35,   161,
      10,   412,    81,   110,   111,    81,   674,    43,    81,   116,
     117,   118,    91,    23,    90,    25,   140,    90,    55,    16,
      16,     0,   433,    59,     0,   436,    36,    37,    24,   697,
      87,   699,    81,    81,   119,   120,   121,   429,    86,    88,
      50,    63,    23,    64,    87,    10,   127,    64,    44,    86,
      46,    47,    48,    50,    10,   136,   137,   138,    81,    80,
      91,    42,    59,    59,    60,    61,    62,    63,    91,    57,
      81,   152,    37,    81,    85,    56,     6,    87,   159,     9,
      24,    37,    12,    91,    65,   166,    91,    17,    84,    54,
      91,    87,   504,    89,    50,    85,    40,    24,    54,   140,
      81,    81,    83,    85,    85,   497,    81,    88,    88,    39,
      91,    41,    80,    88,   526,    59,    60,    61,    62,    63,
      50,    51,    82,    65,    81,   249,    65,    87,    91,    89,
      15,    88,    59,    60,    61,    62,    63,    82,    23,    91,
      91,   304,    87,    87,    89,    89,   114,   115,   116,    86,
      82,   119,   120,   121,    80,    87,   116,    89,    82,    81,
      87,   285,    81,    87,   288,    89,    88,   291,    81,    88,
      82,    81,   119,   120,    91,    88,    87,   301,    88,    82,
     342,    80,   306,   195,   196,   197,    23,   311,   119,   120,
     602,   315,    93,    88,   318,    80,   119,   120,   119,   120,
      85,   119,   120,   327,    81,    65,    88,    85,   249,    94,
      95,    96,    97,    98,    99,   100,   101,   102,   103,   104,
     105,   106,   107,   108,   109,   110,   111,   638,   639,   114,
     115,   116,    88,    90,   119,   120,   121,    65,    91,    93,
      87,    47,    87,    86,   285,    81,    87,   288,   659,    91,
      80,    86,    56,    14,    88,     4,    88,     6,     7,    88,
      87,   529,    65,   674,   532,   306,    65,    16,    90,    88,
     311,    91,    88,    81,   546,   437,    25,   318,   689,    28,
      90,   327,   451,   600,    43,   508,   697,   592,   412,    38,
     452,   556,    41,   407,   134,   592,   592,   511,   543,   592,
     300,   425,   658,   604,    80,   680,   679,   718,   302,   433,
     578,   641,   436,    13,   323,    28,    -1,    -1,    80,    -1,
      -1,   402,    98,    99,   100,   101,   102,   103,   104,   105,
     106,   107,   108,   109,   110,   111,    -1,   418,   114,   115,
     116,   422,    -1,   119,   120,   121,   108,   109,   110,   111,
      -1,    -1,   114,   115,   116,   604,    -1,   119,   120,   121,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   491,    -1,    -1,
      80,    -1,    -1,    -1,    -1,    -1,   538,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   425,    -1,    -1,    -1,    -1,    -1,
      -1,   140,    -1,   517,    -1,    -1,   520,    -1,   522,   667,
     110,   111,    -1,    -1,   114,   115,   116,    -1,    -1,   119,
     120,   121,    -1,   537,    -1,    -1,    -1,    -1,    -1,    -1,
     544,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   680,    -1,    -1,   515,   516,    -1,    -1,   519,   563,
      -1,   565,    -1,    11,    -1,   569,    -1,    15,    -1,    -1,
     491,    19,    20,    21,    -1,    -1,    -1,   581,    26,    -1,
      -1,   585,    30,    31,   545,    -1,   590,    35,    36,    37,
      -1,    -1,    -1,    -1,    42,    43,   517,    -1,    -1,   520,
     642,   522,    50,    51,    -1,    53,    -1,    -1,    -1,    -1,
      -1,    59,    60,   617,    62,    63,   537,    -1,    -1,    -1,
     249,    -1,   583,   544,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   638,   639,    -1,    -1,    -1,   600,
      -1,    -1,   563,    -1,    -1,    -1,    -1,   608,    -1,   610,
     654,   655,    -1,    -1,    -1,   659,   285,   661,   619,   288,
      -1,    -1,   291,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     674,    -1,    -1,   121,   122,   123,   124,   306,    -1,    -1,
      -1,    -1,   311,    -1,    -1,   689,    -1,   316,    -1,   318,
      -1,   139,    -1,   697,    -1,   699,   617,    -1,   327,    -1,
     148,   149,    -1,    -1,    -1,    -1,    -1,   155,    -1,    -1,
      -1,    -1,    -1,   161,   718,    -1,    -1,    -1,    -1,    -1,
      -1,   169,    -1,    -1,    -1,    -1,    -1,    -1,   176,   177,
     178,   179,   180,   181,   182,   183,   184,   185,    -1,   187,
     188,    -1,   190,   191,    -1,    -1,    -1,    -1,    -1,    -1,
     198,    -1,   200,   201,   202,   203,   204,   205,   206,   207,
     208,   209,   210,   211,   212,   213,   214,    -1,   216,   217,
     218,   219,   220,   221,   222,   223,   224,   225,   226,   227,
     228,   229,   230,   231,   232,   233,   234,   235,   236,   237,
     238,   239,   240,   241,   242,    -1,   425,    -1,    -1,    -1,
      -1,    -1,   250,    -1,    19,    20,    -1,    22,    -1,    24,
      -1,    -1,    -1,    28,    -1,    30,    -1,    32,    33,    -1,
      -1,    -1,    -1,    38,    -1,    40,    -1,    -1,    -1,    -1,
      80,    -1,    -1,   281,    -1,    -1,    -1,   285,   286,    -1,
     288,   289,    -1,   291,    59,    60,    61,    62,    63,    -1,
      -1,   299,   102,   103,   104,   105,   106,   107,   108,   109,
     110,   111,   491,    -1,   114,   115,   116,    -1,    -1,   119,
     120,   121,    87,    -1,    89,   323,    -1,   325,   326,   327,
      -1,    96,    97,    98,    99,   100,   101,    -1,   517,    -1,
      -1,   520,    80,   522,   342,   110,   111,    -1,    -1,    -1,
      -1,   116,   117,   118,   119,   120,    -1,    -1,   537,    -1,
      -1,    -1,    -1,    -1,    -1,   544,   104,   105,   106,   107,
     108,   109,   110,   111,    -1,    -1,   114,   115,   116,    -1,
      -1,   119,   120,   121,   563,    -1,   565,    -1,    -1,    -1,
     569,    -1,    -1,    -1,    -1,    -1,   394,   395,   396,   397,
     398,   399,   400,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   590,    -1,    -1,    -1,    -1,   414,   415,    -1,    -1,
      -1,   419,    -1,    -1,    -1,     4,    -1,     6,     7,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    16,   617,   437,
      -1,    -1,    -1,    -1,    -1,   443,    25,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   452,    -1,    -1,    -1,    -1,    38,
      -1,    -1,   460,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   654,   655,    -1,    -1,    -1,
      -1,    -1,   661,    -1,    -1,    -1,    -1,   485,    -1,   487,
      -1,    -1,   490,    -1,    -1,     8,    -1,    -1,    -1,    -1,
      13,    -1,    -1,    -1,    17,    -1,    -1,    -1,    -1,    -1,
      23,    24,    -1,    -1,    27,   513,    -1,    -1,    -1,   517,
      -1,    -1,   520,    -1,    -1,   523,    39,    -1,    -1,    -1,
      -1,   529,    -1,    -1,   532,    -1,    -1,    50,    51,    -1,
     538,    -1,    -1,    -1,    -1,    -1,   544,    -1,    -1,    -1,
     548,    -1,   550,   551,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   140,    -1,    -1,    -1,    -1,    -1,   565,   566,    -1,
      -1,   569,   570,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     578,    -1,   580,   581,    -1,    -1,    99,   585,    -1,   587,
      -1,    -1,   590,    -1,    -1,   593,   594,   595,   596,   597,
     598,   599,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   124,    -1,    -1,    -1,    -1,    -1,   130,    -1,    -1,
      -1,   134,   135,    -1,    -1,    -1,   139,    -1,   141,    -1,
      -1,    -1,    -1,    -1,    -1,   148,   149,    -1,    -1,    -1,
      -1,    -1,   155,   641,   642,    -1,    -1,    -1,   161,    -1,
      -1,    -1,    -1,   651,    -1,    -1,   654,   655,   656,    -1,
      -1,   659,    -1,   661,    -1,   663,   664,   665,    -1,   667,
     249,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     678,   679,   195,   196,   197,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   692,    -1,   694,    -1,    -1,    -1,
     698,    -1,   215,   216,   217,    -1,   285,    -1,    -1,   288,
      -1,    -1,   291,    15,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    23,    -1,    -1,    -1,    -1,    -1,   306,    -1,    -1,
      -1,    -1,   311,    -1,    -1,    -1,    -1,    -1,    -1,   318,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   327,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     273,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    15,   282,
      -1,    -1,    -1,    -1,    -1,    -1,    23,    -1,    80,    -1,
      -1,    -1,    -1,   296,    -1,    -1,    -1,   300,    -1,    -1,
      -1,    -1,    94,    95,    96,    97,    98,    99,   100,   101,
     102,   103,   104,   105,   106,   107,   108,   109,   110,   111,
     323,    -1,   114,   115,   116,    -1,    -1,   119,   120,   121,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   342,
      -1,    -1,    -1,    80,    -1,    -1,    -1,    -1,    85,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   425,    94,    95,    96,
      97,    98,    99,   100,   101,   102,   103,   104,   105,   106,
     107,   108,   109,   110,   111,    -1,    -1,   114,   115,   116,
      -1,    -1,   119,   120,   121,    65,    66,    67,    68,    69,
      70,    71,    72,    73,    74,    75,    76,    77,    78,    79,
      -1,    -1,    82,    -1,   407,    -1,    -1,    87,    -1,    89,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   491,    -1,    -1,   428,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   437,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   517,   452,
      -1,   520,    -1,   522,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   537,    -1,
      -1,    -1,    15,    -1,    -1,   544,    -1,    -1,    -1,    -1,
      23,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   563,    -1,   565,    -1,    -1,    -1,
     569,   504,    -1,    -1,   507,    -1,    -1,    -1,   511,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   590,    -1,   526,    -1,    -1,   529,    -1,    -1,   532,
      -1,    -1,    -1,    -1,    -1,   538,    -1,    80,    -1,    -1,
     543,    -1,    85,    -1,    -1,    -1,    -1,    -1,   617,    -1,
      -1,    94,    95,    96,    97,    98,    99,   100,   101,   102,
     103,   104,   105,   106,   107,   108,   109,   110,   111,    -1,
      -1,   114,   115,   116,    -1,   578,   119,   120,   121,    -1,
      -1,    80,    -1,    -1,    -1,   654,   655,    -1,    -1,    -1,
      -1,    -1,   661,    -1,    -1,    49,    -1,    -1,    -1,   602,
      99,   100,   101,   102,   103,   104,   105,   106,   107,   108,
     109,   110,   111,    -1,    -1,   114,   115,   116,   621,    -1,
     119,   120,   121,    -1,    -1,    -1,    80,    -1,    -1,    -1,
      -1,    85,    -1,    -1,    -1,    -1,    -1,   640,   641,   642,
      94,    95,    96,    97,    98,    99,   100,   101,   102,   103,
     104,   105,   106,   107,   108,   109,   110,   111,    -1,    -1,
     114,   115,   116,    -1,   667,   119,   120,   121,    -1,    -1,
      -1,    -1,    -1,    -1,   677,   678,   679,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   692,
       1,   694,     3,     4,     5,     6,     7,     8,     9,    10,
      11,    12,    13,    -1,    15,    -1,    17,    18,    19,    20,
      -1,    22,    -1,    24,    -1,    -1,    27,    28,    29,    30,
      31,    32,    33,    34,    -1,    -1,    37,    38,    -1,    40,
      41,    42,    43,    -1,    45,    -1,    -1,    48,    -1,    50,
      51,    52,    -1,    54,    -1,    -1,    57,    58,    59,    60,
      61,    62,    63,    64,    65,    66,    67,    68,    69,    70,
      71,    72,    73,    74,    75,    76,    77,    78,    79,    80,
      -1,    82,    -1,    -1,    85,    -1,    87,    -1,    89,    -1,
      91,    -1,    93,    94,    95,    96,    97,    98,    99,   100,
     101,   102,   103,   104,   105,   106,   107,   108,   109,   110,
     111,    -1,    -1,   114,   115,   116,   117,   118,   119,   120,
     121,     1,    -1,     3,     4,     5,     6,     7,     8,     9,
      10,    11,    12,    13,    -1,    15,    -1,    17,    18,    19,
      20,    -1,    22,    -1,    24,    -1,    -1,    27,    28,    29,
      30,    31,    32,    33,    34,    -1,    -1,    37,    38,    39,
      40,    41,    42,    43,    -1,    45,    -1,    -1,    48,    -1,
      50,    51,    52,    -1,    54,    -1,    -1,    57,    58,    59,
      60,    61,    62,    63,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    85,    -1,    87,    -1,    89,
      -1,    91,    -1,    -1,    -1,    -1,    96,    97,    98,    99,
     100,   101,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     110,   111,    -1,    -1,    -1,    -1,   116,   117,   118,     1,
      -1,     3,     4,     5,     6,     7,     8,     9,    10,    11,
      12,    13,    -1,    15,    -1,    17,    18,    19,    20,    -1,
      22,    -1,    24,    -1,    -1,    27,    28,    29,    30,    31,
      32,    33,    34,    -1,    -1,    37,    38,    -1,    40,    41,
      42,    43,    -1,    45,    -1,    -1,    48,    -1,    50,    51,
      52,    -1,    54,    -1,    -1,    57,    58,    59,    60,    61,
      62,    63,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    85,    -1,    87,    -1,    89,    -1,    91,
      -1,    -1,    -1,    -1,    96,    97,    98,    99,   100,   101,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   110,   111,
      -1,    -1,    -1,    -1,   116,   117,   118,     1,    -1,     3,
       4,     5,     6,     7,     8,     9,    10,    11,    12,    13,
      -1,    15,    -1,    17,    18,    19,    20,    -1,    22,    -1,
      24,    -1,    -1,    27,    28,    29,    30,    31,    32,    33,
      34,    -1,    -1,    37,    38,    -1,    40,    41,    42,    43,
      -1,    45,    -1,    -1,    48,    -1,    50,    51,    52,    -1,
      54,    -1,    -1,    57,    58,    59,    60,    61,    62,    63,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    85,    -1,    87,    -1,    89,    -1,    91,    -1,    -1,
      -1,    -1,    96,    97,    98,    99,   100,   101,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   110,   111,    -1,    -1,
      -1,    -1,   116,   117,   118,     1,    -1,     3,     4,     5,
       6,     7,     8,     9,    10,    11,    12,    13,    -1,    15,
      -1,    17,    18,    19,    20,    -1,    22,    -1,    24,    -1,
      -1,    27,    28,    29,    30,    31,    32,    33,    34,    -1,
      -1,    37,    38,    -1,    40,    41,    42,    43,    -1,    45,
      -1,    -1,    48,    -1,    50,    51,    52,    -1,    54,    -1,
      -1,    57,    58,    59,    60,    61,    62,    63,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    85,
      -1,    87,    -1,    89,    -1,    91,    -1,    -1,    -1,    -1,
      96,    97,    98,    99,   100,   101,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   110,   111,    -1,    -1,    -1,    -1,
     116,   117,   118,     1,    -1,     3,     4,     5,     6,     7,
       8,     9,    10,    11,    12,    13,    -1,    15,    -1,    17,
      18,    19,    20,    -1,    22,    -1,    24,    -1,    -1,    27,
      28,    29,    30,    31,    32,    33,    34,    -1,    -1,    37,
      38,    -1,    40,    41,    42,    43,    -1,    45,    -1,    -1,
      48,    -1,    50,    51,    52,    -1,    54,    -1,    -1,    57,
      58,    59,    60,    61,    62,    63,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    85,    -1,    87,
      -1,    89,    -1,    91,    -1,    -1,    -1,    -1,    96,    97,
      98,    99,   100,   101,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   110,   111,    -1,    -1,    -1,    -1,   116,   117,
     118,     1,    -1,     3,     4,     5,     6,     7,     8,     9,
      10,    11,    12,    13,    -1,    15,    -1,    17,    18,    19,
      20,    -1,    22,    -1,    24,    -1,    -1,    27,    28,    29,
      30,    31,    32,    33,    34,    -1,    -1,    37,    38,    -1,
      40,    41,    42,    43,    -1,    45,    -1,    -1,    48,    -1,
      50,    51,    52,    -1,    54,    -1,    -1,    57,    58,    59,
      60,    61,    62,    63,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    85,    -1,    87,    -1,    89,
      -1,    91,    -1,    -1,    -1,    -1,    96,    97,    98,    99,
     100,   101,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     110,   111,    -1,    -1,    -1,    -1,   116,   117,   118,     1,
      -1,     3,     4,     5,     6,     7,     8,     9,    10,    11,
      12,    13,    -1,    15,    -1,    17,    18,    19,    20,    -1,
      22,    -1,    24,    -1,    -1,    27,    28,    29,    30,    31,
      32,    33,    34,    -1,    -1,    37,    38,    -1,    40,    41,
      42,    43,    15,    45,    -1,    -1,    48,    -1,    50,    51,
      52,    -1,    54,    -1,    -1,    57,    58,    59,    60,    61,
      62,    63,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    15,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    85,    -1,    87,    -1,    89,    -1,    91,
      -1,    -1,    -1,    -1,    96,    97,    98,    99,   100,   101,
      -1,    -1,    -1,    -1,    -1,    -1,    15,    80,   110,   111,
      -1,    -1,    85,    -1,   116,   117,   118,    -1,    -1,    -1,
      -1,    94,    95,    96,    97,    98,    99,   100,   101,   102,
     103,   104,   105,   106,   107,   108,   109,   110,   111,    80,
      -1,   114,   115,   116,    85,    -1,   119,   120,   121,    15,
      -1,    -1,    -1,    94,    95,    96,    97,    98,    99,   100,
     101,   102,   103,   104,   105,   106,   107,   108,   109,   110,
     111,    80,    -1,   114,   115,   116,    85,    -1,   119,   120,
     121,    -1,    -1,    -1,    -1,    94,    95,    96,    97,    98,
      99,   100,   101,   102,   103,   104,   105,   106,   107,   108,
     109,   110,   111,    -1,    -1,   114,   115,   116,    15,    -1,
     119,   120,   121,    -1,    80,    -1,    23,    -1,    -1,    85,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    94,    95,
      96,    97,    98,    99,   100,   101,   102,   103,   104,   105,
     106,   107,   108,   109,   110,   111,    15,    -1,   114,   115,
     116,    -1,    -1,   119,   120,   121,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    80,    -1,    -1,    -1,    -1,    15,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    94,    95,    96,
      97,    98,    99,   100,   101,   102,   103,   104,   105,   106,
     107,   108,   109,   110,   111,    -1,    -1,   114,   115,   116,
      15,    80,   119,   120,   121,    -1,    85,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    94,    95,    96,    97,    98,
      99,   100,   101,   102,   103,   104,   105,   106,   107,   108,
     109,   110,   111,    80,    -1,   114,   115,   116,    85,    -1,
     119,   120,   121,    15,    -1,    -1,    -1,    94,    95,    96,
      97,    98,    99,   100,   101,   102,   103,   104,   105,   106,
     107,   108,   109,   110,   111,    80,    -1,   114,   115,   116,
      85,    -1,   119,   120,   121,    15,    -1,    -1,    -1,    94,
      95,    96,    97,    98,    99,   100,   101,   102,   103,   104,
     105,   106,   107,   108,   109,   110,   111,    -1,    -1,   114,
     115,   116,    -1,    -1,   119,   120,   121,    -1,    80,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    94,    95,    96,    97,    98,    99,   100,   101,
     102,   103,   104,   105,   106,   107,   108,   109,   110,   111,
      80,    -1,   114,   115,   116,    -1,    -1,   119,   120,   121,
      -1,    -1,    -1,    -1,    94,    95,    96,    97,    98,    99,
     100,   101,   102,   103,   104,   105,   106,   107,   108,   109,
     110,   111,    -1,    -1,   114,   115,   116,    -1,    -1,   119,
     120,   121,    16,    -1,    -1,    19,    20,    -1,    22,    -1,
      24,    -1,    -1,    -1,    28,    -1,    30,    -1,    32,    33,
      -1,    -1,    -1,    -1,    38,    -1,    40,    -1,    -1,    -1,
      44,    -1,    46,    47,    48,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    59,    60,    61,    62,    63,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      84,    -1,    -1,    87,    -1,    89,    -1,    -1,    -1,    -1,
      -1,    -1,    96,    97,    98,    99,   100,   101,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   110,   111,    -1,    -1,
      -1,    -1,   116,   117,   118,    16,    -1,    -1,    19,    20,
      -1,    22,    -1,    24,    -1,    -1,    -1,    28,    -1,    30,
      -1,    32,    33,    -1,    -1,    -1,    -1,    38,    -1,    40,
      -1,    -1,    -1,    44,    80,    46,    47,    48,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    59,    60,
      61,    62,    63,    -1,   100,   101,   102,   103,   104,   105,
     106,   107,   108,   109,   110,   111,    -1,    -1,   114,   115,
     116,    -1,    -1,   119,   120,   121,    87,    -1,    89,    -1,
      -1,    -1,    -1,    -1,    -1,    96,    97,    98,    99,   100,
     101,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   110,
     111,    -1,    -1,    -1,    -1,   116,   117,   118,    16,    -1,
      -1,    19,    20,    -1,    22,    -1,    24,    -1,    -1,    -1,
      28,    -1,    30,    -1,    32,    33,    -1,    -1,    -1,    -1,
      38,    -1,    40,    -1,    -1,    80,    44,    -1,    46,    47,
      48,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    59,    60,    61,    62,    63,   101,   102,   103,   104,
     105,   106,   107,   108,   109,   110,   111,    -1,    -1,   114,
     115,   116,    -1,    -1,   119,   120,   121,    -1,    -1,    87,
      -1,    89,    -1,    -1,    -1,    -1,    -1,    -1,    96,    97,
      98,    99,   100,   101,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   110,   111,    -1,    -1,    -1,    -1,   116,   117,
     118,    16,    -1,    -1,    19,    20,    -1,    22,    -1,    24,
      -1,    -1,    -1,    28,    -1,    30,    -1,    32,    33,    -1,
      -1,    -1,    -1,    38,    -1,    40,    -1,    -1,    -1,    44,
      -1,    46,    47,    48,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    59,    60,    61,    62,    63,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    87,    -1,    89,    -1,    -1,    -1,    -1,    -1,
      -1,    96,    97,    98,    99,   100,   101,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   110,   111,    -1,    -1,    -1,
      -1,   116,   117,   118,    16,    -1,    -1,    19,    20,    -1,
      22,    -1,    24,    -1,    -1,    -1,    28,    -1,    30,    -1,
      32,    33,    -1,    -1,    -1,    -1,    38,    -1,    40,    -1,
      -1,    -1,    44,    -1,    46,    47,    48,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    59,    60,    61,
      62,    63,    19,    20,    -1,    22,    -1,    24,    -1,    -1,
      -1,    28,    -1,    30,    -1,    32,    33,    -1,    -1,    -1,
      -1,    38,    -1,    40,    -1,    87,    -1,    89,    -1,    -1,
      -1,    -1,    -1,    -1,    96,    97,    98,    99,   100,   101,
      -1,    -1,    59,    60,    61,    62,    63,    -1,   110,   111,
      -1,    -1,    -1,    -1,   116,   117,   118,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    84,    -1,    -1,
      87,    -1,    89,    90,    -1,    -1,    -1,    -1,    -1,    96,
      97,    98,    99,   100,   101,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   110,   111,    -1,    -1,    -1,    -1,   116,
     117,   118,    19,    20,    -1,    22,    -1,    24,    -1,    -1,
      -1,    28,    -1,    30,    -1,    32,    33,    -1,    -1,    -1,
      37,    38,    -1,    40,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    59,    60,    61,    62,    63,    19,    20,    -1,
      22,    -1,    24,    -1,    -1,    -1,    28,    -1,    30,    -1,
      32,    33,    -1,    -1,    -1,    -1,    38,    -1,    40,    -1,
      87,    -1,    89,    -1,    -1,    -1,    -1,    -1,    -1,    96,
      97,    98,    99,   100,   101,    -1,    -1,    59,    60,    61,
      62,    63,    -1,   110,   111,    -1,    -1,    -1,    -1,   116,
     117,   118,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    83,    -1,    -1,    -1,    87,    -1,    89,    -1,    -1,
      -1,    -1,    -1,    -1,    96,    97,    98,    99,   100,   101,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   110,   111,
      -1,    -1,    -1,    -1,   116,   117,   118,    19,    20,    -1,
      22,    -1,    24,    -1,    -1,    -1,    28,    -1,    30,    -1,
      32,    33,    -1,    -1,    -1,    -1,    38,    -1,    40,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    59,    60,    61,
      62,    63,    19,    20,    -1,    22,    -1,    24,    -1,    -1,
      -1,    28,    -1,    30,    -1,    32,    33,    -1,    -1,    -1,
      -1,    38,    84,    40,    -1,    87,    -1,    89,    -1,    -1,
      -1,    -1,    -1,    -1,    96,    97,    98,    99,   100,   101,
      -1,    -1,    59,    60,    61,    62,    63,    -1,   110,   111,
      -1,    -1,    -1,    -1,   116,   117,   118,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      87,    -1,    89,    -1,    -1,    -1,    -1,    -1,    -1,    96,
      97,    98,    99,   100,   101,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   110,   111,    -1,    -1,    -1,    -1,   116,
     117,   118,    19,    20,    -1,    22,    -1,    24,    -1,    -1,
      -1,    28,    -1,    30,    -1,    32,    33,    -1,    -1,    -1,
      -1,    38,    -1,    40,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    59,    60,    61,    62,    63,    19,    20,    -1,
      22,    -1,    24,    -1,    -1,    -1,    28,    -1,    30,    -1,
      32,    33,    -1,    -1,    -1,    -1,    38,    -1,    40,    -1,
      87,    -1,    89,    -1,    -1,    -1,    -1,    -1,    -1,    96,
      97,    98,    99,   100,   101,    -1,    -1,    59,    60,    61,
      62,    63,    -1,   110,   111,    -1,    -1,    -1,    -1,   116,
     117,   118,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    87,    -1,    89,    -1,    -1,
      -1,    -1,    -1,    -1,    96,    97,    98,    99,   100,   101,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   110,   111,
      -1,    -1,    -1,    -1,   116,   117,   118,    19,    20,    -1,
      22,    -1,    24,    -1,    -1,    -1,    28,    -1,    30,    -1,
      32,    33,    -1,    -1,    -1,    -1,    38,    -1,    40,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    59,    60,    61,
      62,    63,    19,    20,    -1,    22,    -1,    24,    -1,    -1,
      -1,    28,    -1,    30,    -1,    32,    33,    -1,    -1,    -1,
      -1,    38,    -1,    40,    -1,    87,    -1,    89,    -1,    -1,
      -1,    -1,    -1,    -1,    96,    97,    98,    99,   100,   101,
      -1,    -1,    59,    60,    61,    62,    63,    -1,   110,   111,
      -1,    -1,    -1,    -1,   116,   117,   118,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      87,    -1,    89,    -1,    -1,    -1,    -1,    -1,    -1,    96,
      97,    98,    99,   100,   101,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   110,   111,    -1,    -1,    -1,    -1,   116,
     117,   118,    19,    20,    -1,    22,    -1,    24,    -1,    -1,
      -1,    28,    -1,    30,    -1,    32,    33,    -1,    -1,    -1,
      -1,    38,    -1,    40,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    59,    60,    61,    62,    63,    19,    20,    -1,
      22,    -1,    24,    -1,    -1,    -1,    28,    -1,    30,    -1,
      32,    33,    -1,    -1,    -1,    -1,    38,    -1,    40,    -1,
      87,    -1,    89,    -1,    -1,    -1,    -1,    -1,    -1,    96,
      97,    98,    99,   100,   101,    -1,    -1,    59,    60,    61,
      62,    63,    -1,   110,   111,    -1,    -1,    -1,    -1,   116,
     117,   118,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    87,    -1,    89,    -1,    -1,
      -1,    -1,    -1,    -1,    96,    97,    98,    99,   100,   101,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   110,   111,
      -1,    -1,    -1,    -1,   116,   117,   118,    19,    20,    -1,
      22,    -1,    24,    -1,    -1,    -1,    28,    -1,    30,    -1,
      32,    33,    -1,    -1,    -1,    -1,    38,    -1,    40,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    59,    60,    61,
      62,    63,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    49,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    87,    -1,    89,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    97,    98,    99,   100,   101,
      -1,    -1,    -1,    -1,    -1,    80,    49,    -1,   110,   111,
      85,    -1,    -1,    -1,   116,   117,   118,    -1,    -1,    94,
      95,    96,    97,    98,    99,   100,   101,   102,   103,   104,
     105,   106,   107,   108,   109,   110,   111,    80,    49,   114,
     115,   116,    85,    -1,   119,   120,   121,    -1,    -1,    -1,
      -1,    94,    95,    96,    97,    98,    99,   100,   101,   102,
     103,   104,   105,   106,   107,   108,   109,   110,   111,    80,
      49,   114,   115,   116,    85,    -1,   119,   120,   121,    -1,
      -1,    -1,    -1,    94,    95,    96,    97,    98,    99,   100,
     101,   102,   103,   104,   105,   106,   107,   108,   109,   110,
     111,    80,    49,   114,   115,   116,    85,    -1,   119,   120,
     121,    -1,    -1,    -1,    -1,    94,    95,    96,    97,    98,
      99,   100,   101,   102,   103,   104,   105,   106,   107,   108,
     109,   110,   111,    80,    49,   114,   115,   116,    85,    -1,
     119,   120,   121,    -1,    -1,    -1,    -1,    94,    95,    96,
      97,    98,    99,   100,   101,   102,   103,   104,   105,   106,
     107,   108,   109,   110,   111,    80,    49,   114,   115,   116,
      85,    -1,   119,   120,   121,    -1,    -1,    -1,    -1,    94,
      95,    96,    97,    98,    99,   100,   101,   102,   103,   104,
     105,   106,   107,   108,   109,   110,   111,    80,    49,   114,
     115,   116,    -1,    -1,   119,   120,   121,    -1,    -1,    -1,
      -1,    94,    95,    96,    97,    98,    99,   100,   101,   102,
     103,   104,   105,   106,   107,   108,   109,   110,   111,    80,
      49,   114,   115,   116,    -1,    -1,   119,   120,   121,    -1,
      -1,    -1,    -1,    94,    95,    96,    97,    98,    99,   100,
     101,   102,   103,   104,   105,   106,   107,   108,   109,   110,
     111,    80,    49,   114,   115,   116,    -1,    -1,   119,   120,
     121,    -1,    -1,    -1,    -1,    94,    95,    96,    97,    98,
      99,   100,   101,   102,   103,   104,   105,   106,   107,   108,
     109,   110,   111,    80,    49,   114,   115,   116,    -1,    -1,
     119,   120,   121,    -1,    -1,    -1,    -1,    94,    95,    96,
      97,    98,    99,   100,   101,   102,   103,   104,   105,   106,
     107,   108,   109,   110,   111,    80,    49,   114,   115,   116,
      -1,    -1,   119,   120,   121,    -1,    -1,    -1,    -1,    94,
      95,    96,    97,    98,    99,   100,   101,   102,   103,   104,
     105,   106,   107,   108,   109,   110,   111,    80,    49,   114,
     115,   116,    -1,    -1,   119,   120,   121,    -1,    -1,    -1,
      -1,    94,    95,    96,    97,    98,    99,   100,   101,   102,
     103,   104,   105,   106,   107,   108,   109,   110,   111,    80,
      -1,   114,   115,   116,    -1,    -1,   119,   120,   121,    -1,
      -1,    -1,    -1,    94,    95,    96,    97,    98,    99,   100,
     101,   102,   103,   104,   105,   106,   107,   108,   109,   110,
     111,    59,    -1,   114,   115,   116,    -1,    65,   119,   120,
     121,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    94,    95,    -1,    -1,
      -1,    99,   100,   101,   102,   103,   104,   105,   106,   107,
     108,   109,   110,   111,    80,    -1,   114,   115,   116,   117,
     118,    -1,    -1,   121,    -1,    91,    -1,    -1,    94,    95,
      96,    97,    98,    99,   100,   101,   102,   103,   104,   105,
     106,   107,   108,   109,   110,   111,    80,    -1,   114,   115,
     116,    85,    -1,   119,   120,   121,    -1,    -1,    -1,    -1,
      94,    95,    96,    97,    98,    99,   100,   101,   102,   103,
     104,   105,   106,   107,   108,   109,   110,   111,    -1,    -1,
     114,   115,   116,    80,    -1,   119,   120,   121,    -1,    -1,
      -1,    88,    -1,    -1,    -1,    -1,    -1,    94,    95,    96,
      97,    98,    99,   100,   101,   102,   103,   104,   105,   106,
     107,   108,   109,   110,   111,    80,    -1,   114,   115,   116,
      -1,    -1,   119,   120,   121,    -1,    91,    -1,    -1,    94,
      95,    96,    97,    98,    99,   100,   101,   102,   103,   104,
     105,   106,   107,   108,   109,   110,   111,    80,    -1,   114,
     115,   116,    -1,    -1,   119,   120,   121,    -1,    91,    -1,
      -1,    94,    95,    96,    97,    98,    99,   100,   101,   102,
     103,   104,   105,   106,   107,   108,   109,   110,   111,    80,
      -1,   114,   115,   116,    -1,    -1,   119,   120,   121,    -1,
      91,    -1,    -1,    94,    95,    96,    97,    98,    99,   100,
     101,   102,   103,   104,   105,   106,   107,   108,   109,   110,
     111,    80,    -1,   114,   115,   116,    -1,    -1,   119,   120,
     121,    -1,    91,    -1,    -1,    94,    95,    96,    97,    98,
      99,   100,   101,   102,   103,   104,   105,   106,   107,   108,
     109,   110,   111,    80,    -1,   114,   115,   116,    -1,    -1,
     119,   120,   121,    -1,    91,    -1,    -1,    94,    95,    96,
      97,    98,    99,   100,   101,   102,   103,   104,   105,   106,
     107,   108,   109,   110,   111,    80,    -1,   114,   115,   116,
      -1,    -1,   119,   120,   121,    -1,    91,    -1,    -1,    94,
      95,    96,    97,    98,    99,   100,   101,   102,   103,   104,
     105,   106,   107,   108,   109,   110,   111,    80,    -1,   114,
     115,   116,    -1,    -1,   119,   120,   121,    -1,    91,    -1,
      -1,    94,    95,    96,    97,    98,    99,   100,   101,   102,
     103,   104,   105,   106,   107,   108,   109,   110,   111,    80,
      -1,   114,   115,   116,    -1,    -1,   119,   120,   121,    -1,
      91,    -1,    -1,    94,    95,    96,    97,    98,    99,   100,
     101,   102,   103,   104,   105,   106,   107,   108,   109,   110,
     111,    80,    -1,   114,   115,   116,    -1,    -1,   119,   120,
     121,    -1,    91,    -1,    -1,    94,    95,    96,    97,    98,
      99,   100,   101,   102,   103,   104,   105,   106,   107,   108,
     109,   110,   111,    80,    -1,   114,   115,   116,    -1,    -1,
     119,   120,   121,    -1,    91,    -1,    -1,    94,    95,    96,
      97,    98,    99,   100,   101,   102,   103,   104,   105,   106,
     107,   108,   109,   110,   111,    80,    -1,   114,   115,   116,
      -1,    -1,   119,   120,   121,    -1,    91,    -1,    -1,    94,
      95,    96,    97,    98,    99,   100,   101,   102,   103,   104,
     105,   106,   107,   108,   109,   110,   111,    80,    -1,   114,
     115,   116,    -1,    -1,   119,   120,   121,    -1,    91,    -1,
      -1,    94,    95,    96,    97,    98,    99,   100,   101,   102,
     103,   104,   105,   106,   107,   108,   109,   110,   111,    80,
      -1,   114,   115,   116,    -1,    -1,   119,   120,   121,    -1,
      91,    -1,    -1,    94,    95,    96,    97,    98,    99,   100,
     101,   102,   103,   104,   105,   106,   107,   108,   109,   110,
     111,    80,    -1,   114,   115,   116,    -1,    -1,   119,   120,
     121,    -1,    91,    -1,    -1,    94,    95,    96,    97,    98,
      99,   100,   101,   102,   103,   104,   105,   106,   107,   108,
     109,   110,   111,    80,    -1,   114,   115,   116,    -1,    -1,
     119,   120,   121,    -1,    91,    -1,    -1,    94,    95,    96,
      97,    98,    99,   100,   101,   102,   103,   104,   105,   106,
     107,   108,   109,   110,   111,    80,    -1,   114,   115,   116,
      -1,    -1,   119,   120,   121,    -1,    91,    -1,    -1,    94,
      95,    96,    97,    98,    99,   100,   101,   102,   103,   104,
     105,   106,   107,   108,   109,   110,   111,    80,    -1,   114,
     115,   116,    -1,    -1,   119,   120,   121,    -1,    -1,    -1,
      93,    94,    95,    96,    97,    98,    99,   100,   101,   102,
     103,   104,   105,   106,   107,   108,   109,   110,   111,    80,
      -1,   114,   115,   116,    -1,    -1,   119,   120,   121,    90,
      -1,    -1,    -1,    94,    95,    96,    97,    98,    99,   100,
     101,   102,   103,   104,   105,   106,   107,   108,   109,   110,
     111,    80,    -1,   114,   115,   116,    -1,    -1,   119,   120,
     121,    90,    -1,    -1,    -1,    94,    95,    96,    97,    98,
      99,   100,   101,   102,   103,   104,   105,   106,   107,   108,
     109,   110,   111,    80,    -1,   114,   115,   116,    -1,    -1,
     119,   120,   121,    90,    -1,    -1,    -1,    94,    95,    96,
      97,    98,    99,   100,   101,   102,   103,   104,   105,   106,
     107,   108,   109,   110,   111,    80,    -1,   114,   115,   116,
      -1,    -1,   119,   120,   121,    90,    -1,    -1,    -1,    94,
      95,    96,    97,    98,    99,   100,   101,   102,   103,   104,
     105,   106,   107,   108,   109,   110,   111,    80,    -1,   114,
     115,   116,    -1,    -1,   119,   120,   121,    -1,    -1,    -1,
      -1,    94,    95,    96,    97,    98,    99,   100,   101,   102,
     103,   104,   105,   106,   107,   108,   109,   110,   111,    80,
      -1,   114,   115,   116,    -1,    -1,   119,   120,   121,    -1,
      -1,    -1,    -1,    -1,    -1,    96,    97,    98,    99,   100,
     101,   102,   103,   104,   105,   106,   107,   108,   109,   110,
     111,    80,    -1,   114,   115,   116,    -1,    -1,   119,   120,
     121,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    97,    98,
      99,   100,   101,   102,   103,   104,   105,   106,   107,   108,
     109,   110,   111,    -1,    -1,   114,   115,   116,    -1,    -1,
     119,   120,   121
};

/* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
static const yytype_uint8 yystos[] =
{
       0,   123,   126,     0,   124,     1,     3,     4,     5,     6,
       7,     8,     9,    11,    12,    13,    15,    17,    18,    19,
      20,    22,    24,    27,    28,    29,    30,    31,    32,    33,
      34,    38,    39,    40,    41,    42,    43,    45,    48,    50,
      51,    52,    57,    58,    59,    60,    61,    62,    63,    85,
      87,    89,    91,    96,    97,    98,    99,   100,   101,   110,
     111,   116,   117,   118,   125,   127,   128,   129,   132,   133,
     134,   135,   136,   137,   138,   139,   140,   141,   142,   143,
     144,   145,   148,   149,   150,   152,   153,   154,   155,   156,
     157,   158,   159,   160,   161,   163,   168,   172,   180,   181,
     183,   187,   190,   191,   214,   215,   217,   218,   219,   220,
     221,   222,   223,   224,   225,   226,   127,   127,   215,   216,
     153,    19,    20,    22,    89,   221,   222,   223,   224,   216,
     169,   223,   127,   215,    12,    37,   223,   223,   223,    87,
     215,    87,   192,   193,   215,   127,   223,   215,    87,    89,
     218,   222,   223,   223,    63,    87,   151,   223,   223,   223,
     127,    43,   186,   215,   162,   222,   223,   151,   126,    83,
     212,   213,   215,   223,   212,   223,   119,   120,   119,   120,
     119,   120,   119,   120,   119,   120,   223,   119,   120,   223,
     119,   120,   223,   223,   215,    10,    37,    54,    64,   199,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    82,    87,    89,    80,    94,
      95,    96,    97,    98,    99,   100,   101,   102,   103,   104,
     105,   106,   107,   108,   109,   110,   111,   114,   115,   116,
     119,   120,   121,    91,    91,   223,   223,   223,   212,    15,
      23,   153,    91,    65,    94,    95,    99,   100,   101,   102,
     103,   104,   105,   106,   107,   108,   109,   110,   111,   114,
     115,   116,   117,   118,   121,   166,   177,   179,   215,   220,
      91,    57,    85,   166,   215,    15,    23,   153,    15,    23,
     153,    49,   153,   211,   212,   127,    87,   194,   215,    23,
      81,    80,   201,   202,    85,   212,    15,   153,   211,    91,
      85,    15,   153,   212,    91,    65,    81,    91,    15,   153,
      91,    86,   223,    81,    88,    65,    23,    90,   223,   223,
     223,   223,   223,   223,   223,   223,   223,   223,   223,   223,
     223,   223,    80,   182,   192,   192,   192,   223,    91,   223,
     223,   223,   223,   223,   223,   223,   223,   223,   223,   223,
     223,   223,   223,   223,    16,    50,   215,   211,   211,   223,
     223,   223,   223,   223,   223,   223,   223,   223,   223,   223,
     223,   223,   223,   223,   223,   223,   223,   223,   223,   223,
     223,   223,   223,   223,    15,    23,    15,    23,    49,    23,
      90,   127,   223,   215,   170,    87,   165,    82,   223,   184,
     185,   215,    80,   202,    23,    22,   127,   223,   223,    22,
     127,   223,   223,   127,   223,    93,    88,   194,    81,    88,
     223,   193,    16,    44,    46,    47,    48,    89,   196,   197,
     198,   224,   199,    65,   200,   126,    90,   127,    88,   146,
     127,    85,    89,   197,   222,   127,    88,   213,   223,   223,
      22,   128,   223,   212,    85,    91,    91,    91,    91,    91,
      91,    91,    91,    91,    91,    91,    91,    91,    91,    91,
      91,    91,    91,    88,    90,    22,   223,    22,   223,   223,
      22,    15,   153,    10,    37,    50,    54,   167,    10,    23,
      25,    36,    37,    50,    87,   164,   175,   176,   177,   215,
      91,    81,    86,    65,    91,   223,   223,    15,   153,   223,
      15,   153,    93,    93,   127,    88,    87,   215,   202,    87,
     197,    47,    87,   197,   212,   223,    86,    35,    55,    86,
     147,   146,   212,    81,    90,   223,   130,   223,    15,   223,
      15,    90,   223,   127,   202,   194,    81,    88,   215,   165,
     185,    91,   223,    15,   153,    49,    22,   127,   223,    49,
      22,   127,   223,   127,   223,   194,   200,   211,    87,   211,
      23,    90,   127,   212,    86,    90,   186,    22,   127,   223,
      49,    86,   124,    49,    22,    49,    22,    22,    49,    56,
     178,    88,    87,   175,    80,   203,   127,   223,   223,   223,
     223,    88,    88,   211,    88,   223,   197,    15,   153,   223,
     223,    50,   131,   168,   180,   183,   189,   190,   223,   223,
     223,   223,   148,   153,   171,   194,    16,    24,    44,    48,
      84,    87,    89,   173,   198,   204,   208,   209,   210,   214,
     220,    83,   174,   200,    49,    49,    14,   195,    88,    90,
     127,    49,   215,    49,    49,    49,    88,    87,   215,   173,
     206,   207,   215,   223,    90,   173,   212,    82,    87,    89,
     116,   173,   223,   223,   223,   223,   195,   197,   223,    65,
     188,   211,    81,    88,    65,   173,   197,    90,    23,    90,
      16,    50,   215,   205,   206,   205,   204,   197,    91,    88,
     207,   207,   173,   197,   223,   173,    88,    90,    90
};

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		(-2)
#define YYEOF		0

#define YYACCEPT	goto yyacceptlab
#define YYABORT		goto yyabortlab
#define YYERROR		goto yyerrorlab


/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */

#define YYFAIL		goto yyerrlab

#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      yytoken = YYTRANSLATE (yychar);				\
      YYPOPSTACK (1);						\
      goto yybackup;						\
    }								\
  else								\
    {								\
      yyerror (YY_("syntax error: cannot back up")); \
      YYERROR;							\
    }								\
while (YYID (0))


#define YYTERROR	1
#define YYERRCODE	256


/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

#define YYRHSLOC(Rhs, K) ((Rhs)[K])
#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)				\
    do									\
      if (YYID (N))                                                    \
	{								\
	  (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;	\
	  (Current).first_column = YYRHSLOC (Rhs, 1).first_column;	\
	  (Current).last_line    = YYRHSLOC (Rhs, N).last_line;		\
	  (Current).last_column  = YYRHSLOC (Rhs, N).last_column;	\
	}								\
      else								\
	{								\
	  (Current).first_line   = (Current).last_line   =		\
	    YYRHSLOC (Rhs, 0).last_line;				\
	  (Current).first_column = (Current).last_column =		\
	    YYRHSLOC (Rhs, 0).last_column;				\
	}								\
    while (YYID (0))
#endif


/* YY_LOCATION_PRINT -- Print the location on the stream.
   This macro was not mandated originally: define only if we know
   we won't break user code: when these are the locations we know.  */

#ifndef YY_LOCATION_PRINT
# if YYLTYPE_IS_TRIVIAL
#  define YY_LOCATION_PRINT(File, Loc)			\
     fprintf (File, "%d.%d-%d.%d",			\
	      (Loc).first_line, (Loc).first_column,	\
	      (Loc).last_line,  (Loc).last_column)
# else
#  define YY_LOCATION_PRINT(File, Loc) ((void) 0)
# endif
#endif


/* YYLEX -- calling `yylex' with the right arguments.  */

#ifdef YYLEX_PARAM
# define YYLEX yylex (YYLEX_PARAM)
#else
# define YYLEX yylex ()
#endif

/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (YYID (0))

# define YY_SYMBOL_PRINT(Title, Type, Value, Location)			  \
do {									  \
  if (yydebug)								  \
    {									  \
      YYFPRINTF (stderr, "%s ", Title);					  \
      yy_symbol_print (stderr,						  \
		  Type, Value, Location); \
      YYFPRINTF (stderr, "\n");						  \
    }									  \
} while (YYID (0))


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_value_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep, YYLTYPE const * const yylocationp)
#else
static void
yy_symbol_value_print (yyoutput, yytype, yyvaluep, yylocationp)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
    YYLTYPE const * const yylocationp;
#endif
{
  if (!yyvaluep)
    return;
  YYUSE (yylocationp);
# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# else
  YYUSE (yyoutput);
# endif
  switch (yytype)
    {
      default:
	break;
    }
}


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep, YYLTYPE const * const yylocationp)
#else
static void
yy_symbol_print (yyoutput, yytype, yyvaluep, yylocationp)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
    YYLTYPE const * const yylocationp;
#endif
{
  if (yytype < YYNTOKENS)
    YYFPRINTF (yyoutput, "token %s (", yytname[yytype]);
  else
    YYFPRINTF (yyoutput, "nterm %s (", yytname[yytype]);

  YY_LOCATION_PRINT (yyoutput, *yylocationp);
  YYFPRINTF (yyoutput, ": ");
  yy_symbol_value_print (yyoutput, yytype, yyvaluep, yylocationp);
  YYFPRINTF (yyoutput, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_stack_print (yytype_int16 *bottom, yytype_int16 *top)
#else
static void
yy_stack_print (bottom, top)
    yytype_int16 *bottom;
    yytype_int16 *top;
#endif
{
  YYFPRINTF (stderr, "Stack now");
  for (; bottom <= top; ++bottom)
    YYFPRINTF (stderr, " %d", *bottom);
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)				\
do {								\
  if (yydebug)							\
    yy_stack_print ((Bottom), (Top));				\
} while (YYID (0))


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_reduce_print (YYSTYPE *yyvsp, YYLTYPE *yylsp, int yyrule)
#else
static void
yy_reduce_print (yyvsp, yylsp, yyrule)
    YYSTYPE *yyvsp;
    YYLTYPE *yylsp;
    int yyrule;
#endif
{
  int yynrhs = yyr2[yyrule];
  int yyi;
  unsigned long int yylno = yyrline[yyrule];
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %lu):\n",
	     yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      fprintf (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr, yyrhs[yyprhs[yyrule] + yyi],
		       &(yyvsp[(yyi + 1) - (yynrhs)])
		       , &(yylsp[(yyi + 1) - (yynrhs)])		       );
      fprintf (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)		\
do {					\
  if (yydebug)				\
    yy_reduce_print (yyvsp, yylsp, Rule); \
} while (YYID (0))

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif



#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined __GLIBC__ && defined _STRING_H
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static YYSIZE_T
yystrlen (const char *yystr)
#else
static YYSIZE_T
yystrlen (yystr)
    const char *yystr;
#endif
{
  YYSIZE_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static char *
yystpcpy (char *yydest, const char *yysrc)
#else
static char *
yystpcpy (yydest, yysrc)
    char *yydest;
    const char *yysrc;
#endif
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYSIZE_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYSIZE_T yyn = 0;
      char const *yyp = yystr;

      for (;;)
	switch (*++yyp)
	  {
	  case '\'':
	  case ',':
	    goto do_not_strip_quotes;

	  case '\\':
	    if (*++yyp != '\\')
	      goto do_not_strip_quotes;
	    /* Fall through.  */
	  default:
	    if (yyres)
	      yyres[yyn] = *yyp;
	    yyn++;
	    break;

	  case '"':
	    if (yyres)
	      yyres[yyn] = '\0';
	    return yyn;
	  }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return yystrlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

/* Copy into YYRESULT an error message about the unexpected token
   YYCHAR while in state YYSTATE.  Return the number of bytes copied,
   including the terminating null byte.  If YYRESULT is null, do not
   copy anything; just return the number of bytes that would be
   copied.  As a special case, return 0 if an ordinary "syntax error"
   message will do.  Return YYSIZE_MAXIMUM if overflow occurs during
   size calculation.  */
static YYSIZE_T
yysyntax_error (char *yyresult, int yystate, int yychar)
{
  int yyn = yypact[yystate];

  if (! (YYPACT_NINF < yyn && yyn <= YYLAST))
    return 0;
  else
    {
      int yytype = YYTRANSLATE (yychar);
      YYSIZE_T yysize0 = yytnamerr (0, yytname[yytype]);
      YYSIZE_T yysize = yysize0;
      YYSIZE_T yysize1;
      int yysize_overflow = 0;
      enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
      char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
      int yyx;

# if 0
      /* This is so xgettext sees the translatable formats that are
	 constructed on the fly.  */
      YY_("syntax error, unexpected %s");
      YY_("syntax error, unexpected %s, expecting %s");
      YY_("syntax error, unexpected %s, expecting %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s");
# endif
      char *yyfmt;
      char const *yyf;
      static char const yyunexpected[] = "syntax error, unexpected %s";
      static char const yyexpecting[] = ", expecting %s";
      static char const yyor[] = " or %s";
      char yyformat[sizeof yyunexpected
		    + sizeof yyexpecting - 1
		    + ((YYERROR_VERBOSE_ARGS_MAXIMUM - 2)
		       * (sizeof yyor - 1))];
      char const *yyprefix = yyexpecting;

      /* Start YYX at -YYN if negative to avoid negative indexes in
	 YYCHECK.  */
      int yyxbegin = yyn < 0 ? -yyn : 0;

      /* Stay within bounds of both yycheck and yytname.  */
      int yychecklim = YYLAST - yyn + 1;
      int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
      int yycount = 1;

      yyarg[0] = yytname[yytype];
      yyfmt = yystpcpy (yyformat, yyunexpected);

      for (yyx = yyxbegin; yyx < yyxend; ++yyx)
	if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
	  {
	    if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
	      {
		yycount = 1;
		yysize = yysize0;
		yyformat[sizeof yyunexpected - 1] = '\0';
		break;
	      }
	    yyarg[yycount++] = yytname[yyx];
	    yysize1 = yysize + yytnamerr (0, yytname[yyx]);
	    yysize_overflow |= (yysize1 < yysize);
	    yysize = yysize1;
	    yyfmt = yystpcpy (yyfmt, yyprefix);
	    yyprefix = yyor;
	  }

      yyf = YY_(yyformat);
      yysize1 = yysize + yystrlen (yyf);
      yysize_overflow |= (yysize1 < yysize);
      yysize = yysize1;

      if (yysize_overflow)
	return YYSIZE_MAXIMUM;

      if (yyresult)
	{
	  /* Avoid sprintf, as that infringes on the user's name space.
	     Don't have undefined behavior even if the translation
	     produced a string with the wrong number of "%s"s.  */
	  char *yyp = yyresult;
	  int yyi = 0;
	  while ((*yyp = *yyf) != '\0')
	    {
	      if (*yyp == '%' && yyf[1] == 's' && yyi < yycount)
		{
		  yyp += yytnamerr (yyp, yyarg[yyi++]);
		  yyf += 2;
		}
	      else
		{
		  yyp++;
		  yyf++;
		}
	    }
	}
      return yysize;
    }
}
#endif /* YYERROR_VERBOSE */


/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep, YYLTYPE *yylocationp)
#else
static void
yydestruct (yymsg, yytype, yyvaluep, yylocationp)
    const char *yymsg;
    int yytype;
    YYSTYPE *yyvaluep;
    YYLTYPE *yylocationp;
#endif
{
  YYUSE (yyvaluep);
  YYUSE (yylocationp);

  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  switch (yytype)
    {

      default:
	break;
    }
}


/* Prevent warnings from -Wmissing-prototypes.  */

#ifdef YYPARSE_PARAM
#if defined __STDC__ || defined __cplusplus
int yyparse (void *YYPARSE_PARAM);
#else
int yyparse ();
#endif
#else /* ! YYPARSE_PARAM */
#if defined __STDC__ || defined __cplusplus
int yyparse (void);
#else
int yyparse ();
#endif
#endif /* ! YYPARSE_PARAM */



/* The look-ahead symbol.  */
int yychar;

/* The semantic value of the look-ahead symbol.  */
YYSTYPE yylval;

/* Number of syntax errors so far.  */
int yynerrs;
/* Location data for the look-ahead symbol.  */
YYLTYPE yylloc;



/*----------.
| yyparse.  |
`----------*/

#ifdef YYPARSE_PARAM
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void *YYPARSE_PARAM)
#else
int
yyparse (YYPARSE_PARAM)
    void *YYPARSE_PARAM;
#endif
#else /* ! YYPARSE_PARAM */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void)
#else
int
yyparse ()

#endif
#endif
{
  
  int yystate;
  int yyn;
  int yyresult;
  /* Number of tokens to shift before error messages enabled.  */
  int yyerrstatus;
  /* Look-ahead token as an internal (translated) token number.  */
  int yytoken = 0;
#if YYERROR_VERBOSE
  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYSIZE_T yymsg_alloc = sizeof yymsgbuf;
#endif

  /* Three stacks and their tools:
     `yyss': related to states,
     `yyvs': related to semantic values,
     `yyls': related to locations.

     Refer to the stacks thru separate pointers, to allow yyoverflow
     to reallocate them elsewhere.  */

  /* The state stack.  */
  yytype_int16 yyssa[YYINITDEPTH];
  yytype_int16 *yyss = yyssa;
  yytype_int16 *yyssp;

  /* The semantic value stack.  */
  YYSTYPE yyvsa[YYINITDEPTH];
  YYSTYPE *yyvs = yyvsa;
  YYSTYPE *yyvsp;

  /* The location stack.  */
  YYLTYPE yylsa[YYINITDEPTH];
  YYLTYPE *yyls = yylsa;
  YYLTYPE *yylsp;
  /* The locations where the error started and ended.  */
  YYLTYPE yyerror_range[2];

#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N), yylsp -= (N))

  YYSIZE_T yystacksize = YYINITDEPTH;

  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;
  YYLTYPE yyloc;

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss;
  yyvsp = yyvs;
  yylsp = yyls;
#if YYLTYPE_IS_TRIVIAL
  /* Initialize the default location before parsing starts.  */
  yylloc.first_line   = yylloc.last_line   = 1;
  yylloc.first_column = yylloc.last_column = 0;
#endif

  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack.  Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	yytype_int16 *yyss1 = yyss;
	YYLTYPE *yyls1 = yyls;

	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  This used to be a
	   conditional around just the two extra args, but that might
	   be undefined if yyoverflow is a macro.  */
	yyoverflow (YY_("memory exhausted"),
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),
		    &yyls1, yysize * sizeof (*yylsp),
		    &yystacksize);
	yyls = yyls1;
	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyexhaustedlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
	goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
	yystacksize = YYMAXDEPTH;

      {
	yytype_int16 *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyexhaustedlab;
	YYSTACK_RELOCATE (yyss);
	YYSTACK_RELOCATE (yyvs);
	YYSTACK_RELOCATE (yyls);
#  undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;
      yylsp = yyls + yysize - 1;

      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

  /* Do appropriate processing given the current state.  Read a
     look-ahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to look-ahead token.  */
  yyn = yypact[yystate];
  if (yyn == YYPACT_NINF)
    goto yydefault;

  /* Not known => get a look-ahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid look-ahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yyn == 0 || yyn == YYTABLE_NINF)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the look-ahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

  /* Discard the shifted token unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  yystate = yyn;
  *++yyvsp = yylval;
  *++yylsp = yylloc;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];

  /* Default location.  */
  YYLLOC_DEFAULT (yyloc, (yylsp - yylen), yylen);
  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 2:
#line 244 "chapel.ypp"
    { (void)(yylsp[(1) - (1)]).first_line; yyblock = (yyval.pblockstmt); ;}
    break;

  case 3:
#line 252 "chapel.ypp"
    { (yyval.vpch) = new Vec<const char*>(); ;}
    break;

  case 4:
#line 254 "chapel.ypp"
    { (yyvsp[(1) - (2)].vpch)->add((yyvsp[(2) - (2)].pch)); ;}
    break;

  case 5:
#line 260 "chapel.ypp"
    { (yyval.pch) = astr((yyvsp[(2) - (2)].pch)); ;}
    break;

  case 6:
#line 269 "chapel.ypp"
    { (yyval.pblockstmt) = new BlockStmt(); ;}
    break;

  case 7:
#line 271 "chapel.ypp"
    {
      if (DefExpr* def = toDefExpr((yyvsp[(3) - (3)].pblockstmt)->body.first()))
        def->sym->addFlags((yyvsp[(2) - (3)].vpch));
      delete (yyvsp[(2) - (3)].vpch);
      (yyvsp[(1) - (3)].pblockstmt)->insertAtTail((yyvsp[(3) - (3)].pblockstmt));
    ;}
    break;

  case 44:
#line 322 "chapel.ypp"
    { printf("syntax error"); clean_exit(1); ;}
    break;

  case 45:
#line 327 "chapel.ypp"
    {
      (yyval.pblockstmt) = buildChapelStmt(new CallExpr(new CallExpr(".", (yyvsp[(1) - (3)].pexpr), new_StringSymbol("makeAlias")), (yyvsp[(2) - (3)].pexpr)));
    ;}
    break;

  case 46:
#line 334 "chapel.ypp"
    { (yyval.pblockstmt) = new BlockStmt(); ;}
    break;

  case 47:
#line 336 "chapel.ypp"
    {
      if (DefExpr* def = toDefExpr((yyvsp[(3) - (3)].pblockstmt)->body.first()))
        def->sym->addFlags((yyvsp[(2) - (3)].vpch));
      delete (yyvsp[(2) - (3)].vpch);
      (yyvsp[(1) - (3)].pblockstmt)->insertAtTail((yyvsp[(3) - (3)].pblockstmt));
    ;}
    break;

  case 53:
#line 356 "chapel.ypp"
    { (yyval.pblockstmt) = buildChapelStmt(new BlockStmt()); ;}
    break;

  case 54:
#line 362 "chapel.ypp"
    { (yyval.pblockstmt) = buildLabelStmt((yyvsp[(2) - (3)].pch), (yyvsp[(3) - (3)].pblockstmt)); ;}
    break;

  case 55:
#line 368 "chapel.ypp"
    { (yyval.pblockstmt) = buildChapelStmt(new GotoStmt(GOTO_BREAK, (yyvsp[(2) - (3)].pch))); ;}
    break;

  case 56:
#line 374 "chapel.ypp"
    { (yyval.pblockstmt) = buildChapelStmt(new GotoStmt(GOTO_CONTINUE, (yyvsp[(2) - (3)].pch))); ;}
    break;

  case 57:
#line 380 "chapel.ypp"
    { (yyval.pblockstmt) = buildChapelStmt((yyvsp[(1) - (2)].pexpr)); ;}
    break;

  case 58:
#line 386 "chapel.ypp"
    { (yyval.pblockstmt) = buildIfStmt((yyvsp[(2) - (3)].pexpr), (yyvsp[(3) - (3)].pblockstmt)); ;}
    break;

  case 59:
#line 388 "chapel.ypp"
    { (yyval.pblockstmt) = buildIfStmt((yyvsp[(2) - (4)].pexpr), (yyvsp[(4) - (4)].pblockstmt)); ;}
    break;

  case 60:
#line 390 "chapel.ypp"
    { (yyval.pblockstmt) = buildIfStmt((yyvsp[(2) - (5)].pexpr), (yyvsp[(3) - (5)].pblockstmt), (yyvsp[(5) - (5)].pblockstmt)); ;}
    break;

  case 61:
#line 392 "chapel.ypp"
    { (yyval.pblockstmt) = buildIfStmt((yyvsp[(2) - (6)].pexpr), (yyvsp[(4) - (6)].pblockstmt), (yyvsp[(6) - (6)].pblockstmt)); ;}
    break;

  case 62:
#line 398 "chapel.ypp"
    { (yyval.pblockstmt) = buildParamForLoopStmt((yyvsp[(3) - (7)].pch), (yyvsp[(5) - (7)].pexpr), (yyvsp[(7) - (7)].pblockstmt)); ;}
    break;

  case 63:
#line 400 "chapel.ypp"
    { (yyval.pblockstmt) = buildParamForLoopStmt((yyvsp[(3) - (6)].pch), (yyvsp[(5) - (6)].pexpr), (yyvsp[(6) - (6)].pblockstmt)); ;}
    break;

  case 64:
#line 406 "chapel.ypp"
    { (yyval.pblockstmt) = buildForLoopStmt((yyvsp[(2) - (5)].pexpr), (yyvsp[(4) - (5)].pexpr), (yyvsp[(5) - (5)].pblockstmt)); ;}
    break;

  case 65:
#line 408 "chapel.ypp"
    { (yyval.pblockstmt) = buildForLoopStmt((yyvsp[(2) - (6)].pexpr), (yyvsp[(4) - (6)].pexpr), new BlockStmt((yyvsp[(6) - (6)].pblockstmt))); ;}
    break;

  case 66:
#line 410 "chapel.ypp"
    { (yyval.pblockstmt) = buildForLoopStmt(NULL, (yyvsp[(2) - (3)].pexpr), (yyvsp[(3) - (3)].pblockstmt)); ;}
    break;

  case 67:
#line 412 "chapel.ypp"
    { (yyval.pblockstmt) = buildForLoopStmt(NULL, (yyvsp[(2) - (4)].pexpr), new BlockStmt((yyvsp[(4) - (4)].pblockstmt))); ;}
    break;

  case 68:
#line 418 "chapel.ypp"
    { (yyval.pblockstmt) = buildForallLoopStmt((yyvsp[(2) - (5)].pexpr), (yyvsp[(4) - (5)].pexpr), (yyvsp[(5) - (5)].pblockstmt)); ;}
    break;

  case 69:
#line 420 "chapel.ypp"
    { (yyval.pblockstmt) = buildForallLoopStmt((yyvsp[(2) - (6)].pexpr), (yyvsp[(4) - (6)].pexpr), new BlockStmt((yyvsp[(6) - (6)].pblockstmt))); ;}
    break;

  case 70:
#line 422 "chapel.ypp"
    { (yyval.pblockstmt) = buildForallLoopStmt(NULL, (yyvsp[(2) - (3)].pexpr), (yyvsp[(3) - (3)].pblockstmt)); ;}
    break;

  case 71:
#line 424 "chapel.ypp"
    { (yyval.pblockstmt) = buildForallLoopStmt(NULL, (yyvsp[(2) - (4)].pexpr), new BlockStmt((yyvsp[(4) - (4)].pblockstmt))); ;}
    break;

  case 72:
#line 426 "chapel.ypp"
    {
      if ((yyvsp[(2) - (6)].pcallexpr)->argList.length != 1)
        USR_FATAL((yyvsp[(4) - (6)].pexpr), "invalid index expression");
      (yyval.pblockstmt) = buildForallLoopStmt((yyvsp[(2) - (6)].pcallexpr)->get(1)->remove(), (yyvsp[(4) - (6)].pexpr), new BlockStmt((yyvsp[(6) - (6)].pblockstmt)));
    ;}
    break;

  case 73:
#line 432 "chapel.ypp"
    {
      if ((yyvsp[(2) - (4)].pcallexpr)->argList.length != 1)
        USR_FATAL((yyvsp[(4) - (4)].pblockstmt), "invalid loop expression");
      (yyval.pblockstmt) = buildForallLoopStmt(NULL, (yyvsp[(2) - (4)].pcallexpr)->get(1)->remove(), new BlockStmt((yyvsp[(4) - (4)].pblockstmt)));
    ;}
    break;

  case 74:
#line 442 "chapel.ypp"
    { (yyval.pblockstmt) = buildCoforallLoopStmt((yyvsp[(2) - (5)].pexpr), (yyvsp[(4) - (5)].pexpr), (yyvsp[(5) - (5)].pblockstmt)); ;}
    break;

  case 75:
#line 444 "chapel.ypp"
    { (yyval.pblockstmt) = buildCoforallLoopStmt((yyvsp[(2) - (6)].pexpr), (yyvsp[(4) - (6)].pexpr), new BlockStmt((yyvsp[(6) - (6)].pblockstmt))); ;}
    break;

  case 76:
#line 446 "chapel.ypp"
    { (yyval.pblockstmt) = buildCoforallLoopStmt(NULL, (yyvsp[(2) - (3)].pexpr), (yyvsp[(3) - (3)].pblockstmt)); ;}
    break;

  case 77:
#line 448 "chapel.ypp"
    { (yyval.pblockstmt) = buildCoforallLoopStmt(NULL, (yyvsp[(2) - (4)].pexpr), new BlockStmt((yyvsp[(4) - (4)].pblockstmt))); ;}
    break;

  case 78:
#line 454 "chapel.ypp"
    { (yyval.pblockstmt) = buildWhileDoLoopStmt((yyvsp[(2) - (4)].pexpr), new BlockStmt((yyvsp[(4) - (4)].pblockstmt))); ;}
    break;

  case 79:
#line 456 "chapel.ypp"
    { (yyval.pblockstmt) = buildWhileDoLoopStmt((yyvsp[(2) - (3)].pexpr), (yyvsp[(3) - (3)].pblockstmt)); ;}
    break;

  case 80:
#line 462 "chapel.ypp"
    { (yyval.pblockstmt) = buildDoWhileLoopStmt((yyvsp[(4) - (5)].pexpr), (yyvsp[(2) - (5)].pblockstmt)); ;}
    break;

  case 81:
#line 468 "chapel.ypp"
    { (yyval.pblockstmt) = buildTypeSelectStmt((yyvsp[(3) - (6)].pcallexpr), (yyvsp[(5) - (6)].pblockstmt)); ;}
    break;

  case 82:
#line 474 "chapel.ypp"
    { (yyval.pblockstmt) = buildChapelStmt(buildSelectStmt((yyvsp[(2) - (5)].pexpr), (yyvsp[(4) - (5)].pblockstmt))); ;}
    break;

  case 83:
#line 480 "chapel.ypp"
    { (yyval.pblockstmt) = buildChapelStmt(); ;}
    break;

  case 84:
#line 482 "chapel.ypp"
    { (yyvsp[(1) - (2)].pblockstmt)->insertAtTail((yyvsp[(2) - (2)].pexpr)); ;}
    break;

  case 85:
#line 488 "chapel.ypp"
    { (yyval.pexpr) = new CondStmt(new CallExpr(PRIM_WHEN, (yyvsp[(2) - (4)].pcallexpr)), (yyvsp[(4) - (4)].pblockstmt)); ;}
    break;

  case 86:
#line 490 "chapel.ypp"
    { (yyval.pexpr) = new CondStmt(new CallExpr(PRIM_WHEN, (yyvsp[(2) - (3)].pcallexpr)), (yyvsp[(3) - (3)].pblockstmt)); ;}
    break;

  case 87:
#line 492 "chapel.ypp"
    { (yyval.pexpr) = new CondStmt(new CallExpr(PRIM_WHEN), (yyvsp[(2) - (2)].pblockstmt)); ;}
    break;

  case 88:
#line 498 "chapel.ypp"
    { (yyval.pblockstmt) = buildChapelStmt(new CallExpr(PRIM_RETURN, (yyvsp[(2) - (3)].pexpr))); ;}
    break;

  case 89:
#line 504 "chapel.ypp"
    { (yyval.pblockstmt) = buildChapelStmt(new CallExpr(PRIM_YIELD, (yyvsp[(2) - (3)].pexpr))); ;}
    break;

  case 90:
#line 510 "chapel.ypp"
    {
      (yyval.pblockstmt) = buildChapelStmt(new CallExpr(PRIM_DELETE, (yyvsp[(2) - (3)].pexpr)));
    ;}
    break;

  case 91:
#line 518 "chapel.ypp"
    { (yyval.pexpr) = new SymExpr(gVoid); ;}
    break;

  case 93:
#line 525 "chapel.ypp"
    { (yyval.pblockstmt) = buildChapelStmt(new CallExpr("=", (yyvsp[(1) - (4)].pexpr), (yyvsp[(3) - (4)].pexpr))); ;}
    break;

  case 94:
#line 527 "chapel.ypp"
    { (yyval.pblockstmt) = buildCompoundAssignment("+", (yyvsp[(1) - (4)].pexpr), (yyvsp[(3) - (4)].pexpr)); ;}
    break;

  case 95:
#line 529 "chapel.ypp"
    { (yyval.pblockstmt) = buildCompoundAssignment("-", (yyvsp[(1) - (4)].pexpr), (yyvsp[(3) - (4)].pexpr)); ;}
    break;

  case 96:
#line 531 "chapel.ypp"
    { (yyval.pblockstmt) = buildCompoundAssignment("*", (yyvsp[(1) - (4)].pexpr), (yyvsp[(3) - (4)].pexpr)); ;}
    break;

  case 97:
#line 533 "chapel.ypp"
    { (yyval.pblockstmt) = buildCompoundAssignment("/", (yyvsp[(1) - (4)].pexpr), (yyvsp[(3) - (4)].pexpr)); ;}
    break;

  case 98:
#line 535 "chapel.ypp"
    { (yyval.pblockstmt) = buildCompoundAssignment("%", (yyvsp[(1) - (4)].pexpr), (yyvsp[(3) - (4)].pexpr)); ;}
    break;

  case 99:
#line 537 "chapel.ypp"
    { (yyval.pblockstmt) = buildCompoundAssignment("**", (yyvsp[(1) - (4)].pexpr), (yyvsp[(3) - (4)].pexpr)); ;}
    break;

  case 100:
#line 539 "chapel.ypp"
    { (yyval.pblockstmt) = buildCompoundAssignment("&", (yyvsp[(1) - (4)].pexpr), (yyvsp[(3) - (4)].pexpr)); ;}
    break;

  case 101:
#line 541 "chapel.ypp"
    { (yyval.pblockstmt) = buildCompoundAssignment("|", (yyvsp[(1) - (4)].pexpr), (yyvsp[(3) - (4)].pexpr)); ;}
    break;

  case 102:
#line 543 "chapel.ypp"
    { (yyval.pblockstmt) = buildCompoundAssignment("^", (yyvsp[(1) - (4)].pexpr), (yyvsp[(3) - (4)].pexpr)); ;}
    break;

  case 103:
#line 545 "chapel.ypp"
    { (yyval.pblockstmt) = buildLogicalAndExprAssignment((yyvsp[(1) - (4)].pexpr), (yyvsp[(3) - (4)].pexpr)); ;}
    break;

  case 104:
#line 547 "chapel.ypp"
    { (yyval.pblockstmt) = buildLogicalOrExprAssignment((yyvsp[(1) - (4)].pexpr), (yyvsp[(3) - (4)].pexpr)); ;}
    break;

  case 105:
#line 549 "chapel.ypp"
    { (yyval.pblockstmt) = buildCompoundAssignment(">>", (yyvsp[(1) - (4)].pexpr), (yyvsp[(3) - (4)].pexpr)); ;}
    break;

  case 106:
#line 551 "chapel.ypp"
    { (yyval.pblockstmt) = buildCompoundAssignment("<<", (yyvsp[(1) - (4)].pexpr), (yyvsp[(3) - (4)].pexpr)); ;}
    break;

  case 107:
#line 553 "chapel.ypp"
    { (yyval.pblockstmt) = buildChapelStmt(new CallExpr("_chpl_swap", (yyvsp[(1) - (4)].pexpr), (yyvsp[(3) - (4)].pexpr))); ;}
    break;

  case 108:
#line 559 "chapel.ypp"
    { (yyval.pblockstmt) = buildChapelStmt((yyvsp[(2) - (3)].pblockstmt)); ;}
    break;

  case 109:
#line 565 "chapel.ypp"
    {
      (yyvsp[(2) - (2)].pblockstmt)->lineno = yystartlineno; /* capture line number in case there
                                   * is a need to issue a warning */
      (yyval.pblockstmt) = buildCobeginStmt((yyvsp[(2) - (2)].pblockstmt));
    ;}
    break;

  case 110:
#line 575 "chapel.ypp"
    { (yyval.pblockstmt) = buildAtomicStmt((yyvsp[(2) - (2)].pblockstmt)); ;}
    break;

  case 111:
#line 581 "chapel.ypp"
    { (yyval.pblockstmt) = buildBeginStmt((yyvsp[(2) - (2)].pblockstmt)); ;}
    break;

  case 112:
#line 587 "chapel.ypp"
    { (yyval.pblockstmt) = buildOnStmt((yyvsp[(2) - (4)].pexpr), (yyvsp[(4) - (4)].pblockstmt)); ;}
    break;

  case 113:
#line 589 "chapel.ypp"
    { (yyval.pblockstmt) = buildOnStmt((yyvsp[(2) - (3)].pexpr), (yyvsp[(3) - (3)].pblockstmt)); ;}
    break;

  case 114:
#line 595 "chapel.ypp"
    {
    (yyval.pblockstmt) = buildLocalStmt((yyvsp[(2) - (2)].pblockstmt));
  ;}
    break;

  case 115:
#line 603 "chapel.ypp"
    { (yyval.pblockstmt) = buildSyncStmt((yyvsp[(2) - (2)].pblockstmt)); ;}
    break;

  case 116:
#line 609 "chapel.ypp"
    { (yyval.pblockstmt) = buildSerialStmt((yyvsp[(2) - (3)].pexpr), (yyvsp[(3) - (3)].pblockstmt)); ;}
    break;

  case 117:
#line 611 "chapel.ypp"
    { (yyval.pblockstmt) = buildSerialStmt((yyvsp[(2) - (4)].pexpr), (yyvsp[(4) - (4)].pblockstmt)); ;}
    break;

  case 118:
#line 621 "chapel.ypp"
    { (yyval.pblockstmt) = (yyvsp[(2) - (3)].pblockstmt); ;}
    break;

  case 119:
#line 627 "chapel.ypp"
    { (yyval.pblockstmt) = buildUseList((yyvsp[(1) - (1)].pexpr)); ;}
    break;

  case 120:
#line 629 "chapel.ypp"
    { (yyval.pblockstmt) = buildUseList((yyvsp[(3) - (3)].pexpr), (yyvsp[(1) - (3)].pblockstmt)); ;}
    break;

  case 121:
#line 635 "chapel.ypp"
    { (yyval.pblockstmt) = buildChapelStmt(new DefExpr(buildModule((yyvsp[(2) - (5)].pch), (yyvsp[(4) - (5)].pblockstmt), yyfilename))); ;}
    break;

  case 122:
#line 641 "chapel.ypp"
    { (yyval.pfnsym) = new FnSymbol("_"); ;}
    break;

  case 123:
#line 643 "chapel.ypp"
    {
      (yyval.pfnsym) = new FnSymbol("_");
      (yyval.pfnsym)->insertFormalAtTail((yyvsp[(1) - (1)].pdefexpr));
    ;}
    break;

  case 124:
#line 648 "chapel.ypp"
    {
      (yyval.pfnsym) = new FnSymbol("_");
      buildTupleArg((yyval.pfnsym), (yyvsp[(2) - (3)].pblockstmt), NULL);
    ;}
    break;

  case 125:
#line 653 "chapel.ypp"
    { (yyvsp[(1) - (3)].pfnsym)->insertFormalAtTail((yyvsp[(3) - (3)].pdefexpr)); ;}
    break;

  case 126:
#line 655 "chapel.ypp"
    { buildTupleArg((yyvsp[(1) - (5)].pfnsym), (yyvsp[(4) - (5)].pblockstmt), NULL); ;}
    break;

  case 127:
#line 660 "chapel.ypp"
    { (yyval.pfnsym) = new FnSymbol("_"); (yyval.pfnsym)->addFlag(FLAG_NO_PARENS); ;}
    break;

  case 128:
#line 662 "chapel.ypp"
    { (yyval.pfnsym) = (yyvsp[(2) - (3)].pfnsym); ;}
    break;

  case 129:
#line 668 "chapel.ypp"
    {
      (yyval.pfnsym) = (yyvsp[(2) - (2)].pfnsym);
      (yyval.pfnsym)->name = astr((yyvsp[(1) - (2)].pch));
      if ((yyvsp[(1) - (2)].pch)[0] == '~' && (yyvsp[(1) - (2)].pch)[1] != '\0') {
        (yyval.pfnsym)->cname = astr("chpl__destroy_", &((yyvsp[(1) - (2)].pch)[1]));
        (yyval.pfnsym)->addFlag(FLAG_DESTRUCTOR);
      } else
        (yyval.pfnsym)->cname = (yyval.pfnsym)->name;
    ;}
    break;

  case 130:
#line 678 "chapel.ypp"
    {
      (yyval.pfnsym) = (yyvsp[(4) - (4)].pfnsym);
      (yyval.pfnsym)->name = astr((yyvsp[(3) - (4)].pch));
      if ((yyvsp[(3) - (4)].pch)[0] == '~' && (yyvsp[(3) - (4)].pch)[1] != '\0') {
        (yyval.pfnsym)->cname = astr("chpl__destroy_", &((yyvsp[(3) - (4)].pch)[1]));
        (yyval.pfnsym)->addFlag(FLAG_DESTRUCTOR);
      } else
        (yyval.pfnsym)->cname = (yyval.pfnsym)->name;
      (yyval.pfnsym)->_this = new ArgSymbol(INTENT_BLANK, "this", dtUnknown, (yyvsp[(1) - (4)].pexpr));
      (yyval.pfnsym)->insertFormalAtHead(new DefExpr((yyval.pfnsym)->_this));
      (yyval.pfnsym)->insertFormalAtHead(new DefExpr(new ArgSymbol(INTENT_BLANK, "_mt", dtMethodToken)));
    ;}
    break;

  case 131:
#line 695 "chapel.ypp"
    { (yyval.retTag) = RET_VALUE; ;}
    break;

  case 132:
#line 697 "chapel.ypp"
    { (yyval.retTag) = RET_VALUE; ;}
    break;

  case 133:
#line 699 "chapel.ypp"
    { (yyval.retTag) = RET_VAR; ;}
    break;

  case 134:
#line 701 "chapel.ypp"
    { (yyval.retTag) = RET_PARAM; ;}
    break;

  case 135:
#line 703 "chapel.ypp"
    { (yyval.retTag) = RET_TYPE; ;}
    break;

  case 136:
#line 709 "chapel.ypp"
    {
      captureTokens = 1;
      captureString[0] = '\0';
    ;}
    break;

  case 137:
#line 714 "chapel.ypp"
    {
      captureTokens = 0;
      (yyvsp[(3) - (3)].pfnsym)->userString = astr(captureString);
    ;}
    break;

  case 138:
#line 719 "chapel.ypp"
    {
      (yyvsp[(3) - (8)].pfnsym)->retTag = (yyvsp[(5) - (8)].retTag);
      if ((yyvsp[(5) - (8)].retTag) == RET_VAR)
        (yyvsp[(3) - (8)].pfnsym)->setter = new DefExpr(new ArgSymbol(INTENT_BLANK, "setter", dtBool));
      if ((yyvsp[(6) - (8)].pexpr))
        (yyvsp[(3) - (8)].pfnsym)->retExprType = new BlockStmt((yyvsp[(6) - (8)].pexpr), BLOCK_SCOPELESS);
      if ((yyvsp[(7) - (8)].pexpr))
        (yyvsp[(3) - (8)].pfnsym)->where = new BlockStmt((yyvsp[(7) - (8)].pexpr));
      (yyvsp[(3) - (8)].pfnsym)->insertAtTail((yyvsp[(8) - (8)].pblockstmt));
      (yyval.pblockstmt) = buildChapelStmt(new DefExpr((yyvsp[(3) - (8)].pfnsym)));
    ;}
    break;

  case 140:
#line 736 "chapel.ypp"
    { (yyval.pblockstmt) = new BlockStmt((yyvsp[(1) - (1)].pblockstmt)); ;}
    break;

  case 141:
#line 742 "chapel.ypp"
    {
      FnSymbol* fn = (yyvsp[(3) - (5)].pfnsym);
      fn->addFlag(FLAG_EXTERN);
      if ((yyvsp[(4) - (5)].pexpr))
        fn->retExprType = new BlockStmt((yyvsp[(4) - (5)].pexpr), BLOCK_SCOPELESS);
      else
        fn->retType = dtVoid;
      (yyval.pblockstmt) = buildChapelStmt(new DefExpr(fn));
    ;}
    break;

  case 142:
#line 756 "chapel.ypp"
    {
      (yyval.pdefexpr) = new DefExpr(new VarSymbol((yyvsp[(2) - (2)].pch)));
    ;}
    break;

  case 143:
#line 760 "chapel.ypp"
    {
      (yyval.pdefexpr) = new DefExpr(new VarSymbol(astr("_query_dummy", istr(query_uid++))));
    ;}
    break;

  case 144:
#line 768 "chapel.ypp"
    { (yyval.pexpr) = (yyvsp[(2) - (2)].pexpr); ;}
    break;

  case 145:
#line 770 "chapel.ypp"
    {
      (yyvsp[(2) - (2)].pdefexpr)->sym->addFlag(FLAG_PARAM);
      (yyval.pexpr) = (yyvsp[(2) - (2)].pdefexpr);
    ;}
    break;

  case 146:
#line 779 "chapel.ypp"
    { (yyval.pdefexpr) = buildArgDefExpr((yyvsp[(1) - (4)].pt), (yyvsp[(2) - (4)].pch), (yyvsp[(3) - (4)].pexpr), (yyvsp[(4) - (4)].pexpr), NULL); ;}
    break;

  case 147:
#line 781 "chapel.ypp"
    { (yyval.pdefexpr) = buildArgDefExpr((yyvsp[(1) - (4)].pt), (yyvsp[(2) - (4)].pch), (yyvsp[(3) - (4)].pexpr), NULL, (yyvsp[(4) - (4)].pexpr)); ;}
    break;

  case 148:
#line 787 "chapel.ypp"
    { (yyval.pt) = INTENT_BLANK; ;}
    break;

  case 149:
#line 789 "chapel.ypp"
    { (yyval.pt) = INTENT_IN; ;}
    break;

  case 150:
#line 791 "chapel.ypp"
    { (yyval.pt) = INTENT_INOUT; ;}
    break;

  case 151:
#line 793 "chapel.ypp"
    { (yyval.pt) = INTENT_OUT; ;}
    break;

  case 152:
#line 795 "chapel.ypp"
    { (yyval.pt) = INTENT_CONST; ;}
    break;

  case 153:
#line 797 "chapel.ypp"
    { (yyval.pt) = INTENT_PARAM; ;}
    break;

  case 154:
#line 799 "chapel.ypp"
    { (yyval.pt) = INTENT_TYPE; ;}
    break;

  case 156:
#line 806 "chapel.ypp"
    { (yyval.pch) = astr("~", (yyvsp[(2) - (2)].pch)); ;}
    break;

  case 157:
#line 808 "chapel.ypp"
    { (yyval.pch) = "="; ;}
    break;

  case 158:
#line 810 "chapel.ypp"
    { (yyval.pch) = "&"; ;}
    break;

  case 159:
#line 812 "chapel.ypp"
    { (yyval.pch) = "|"; ;}
    break;

  case 160:
#line 814 "chapel.ypp"
    { (yyval.pch) = "^"; ;}
    break;

  case 161:
#line 816 "chapel.ypp"
    { (yyval.pch) = "~"; ;}
    break;

  case 162:
#line 818 "chapel.ypp"
    { (yyval.pch) = "=="; ;}
    break;

  case 163:
#line 820 "chapel.ypp"
    { (yyval.pch) = "!="; ;}
    break;

  case 164:
#line 822 "chapel.ypp"
    { (yyval.pch) = "<="; ;}
    break;

  case 165:
#line 824 "chapel.ypp"
    { (yyval.pch) = ">="; ;}
    break;

  case 166:
#line 826 "chapel.ypp"
    { (yyval.pch) = "<"; ;}
    break;

  case 167:
#line 828 "chapel.ypp"
    { (yyval.pch) = ">"; ;}
    break;

  case 168:
#line 830 "chapel.ypp"
    { (yyval.pch) = "+"; ;}
    break;

  case 169:
#line 832 "chapel.ypp"
    { (yyval.pch) = "-"; ;}
    break;

  case 170:
#line 834 "chapel.ypp"
    { (yyval.pch) = "*"; ;}
    break;

  case 171:
#line 836 "chapel.ypp"
    { (yyval.pch) = "/"; ;}
    break;

  case 172:
#line 838 "chapel.ypp"
    { (yyval.pch) = "<<"; ;}
    break;

  case 173:
#line 840 "chapel.ypp"
    { (yyval.pch) = ">>"; ;}
    break;

  case 174:
#line 842 "chapel.ypp"
    { (yyval.pch) = "%"; ;}
    break;

  case 175:
#line 844 "chapel.ypp"
    { (yyval.pch) = "**"; ;}
    break;

  case 176:
#line 846 "chapel.ypp"
    { (yyval.pch) = "!"; ;}
    break;

  case 177:
#line 848 "chapel.ypp"
    { (yyval.pch) = "by"; ;}
    break;

  case 178:
#line 850 "chapel.ypp"
    { (yyval.pch) = "#"; ;}
    break;

  case 179:
#line 856 "chapel.ypp"
    { (yyval.pexpr) = NULL; ;}
    break;

  case 180:
#line 858 "chapel.ypp"
    { (yyval.pexpr) = (yyvsp[(2) - (2)].pexpr); ;}
    break;

  case 182:
#line 869 "chapel.ypp"
    {
      DefExpr* def = buildClassDefExpr((yyvsp[(2) - (6)].pch), (yyvsp[(1) - (6)].ptype), (yyvsp[(5) - (6)].pblockstmt));
      ClassType* ct = toClassType(toTypeSymbol(def->sym)->type);
      ct->inherits.insertAtTail((yyvsp[(3) - (6)].pcallexpr));
      (yyval.pblockstmt) = buildChapelStmt(def);
    ;}
    break;

  case 183:
#line 880 "chapel.ypp"
    { (yyval.ptype) = new ClassType(CLASS_CLASS); ;}
    break;

  case 184:
#line 882 "chapel.ypp"
    { (yyval.ptype) = new ClassType(CLASS_RECORD); ;}
    break;

  case 185:
#line 884 "chapel.ypp"
    { (yyval.ptype) = new ClassType(CLASS_UNION); ;}
    break;

  case 186:
#line 890 "chapel.ypp"
    { (yyval.pcallexpr) = new CallExpr(PRIM_ACTUALS_LIST); ;}
    break;

  case 187:
#line 892 "chapel.ypp"
    { (yyval.pcallexpr) = (yyvsp[(2) - (2)].pcallexpr); ;}
    break;

  case 188:
#line 898 "chapel.ypp"
    {
      EnumType* pdt = (yyvsp[(4) - (6)].pet);
      TypeSymbol* pst = new TypeSymbol((yyvsp[(2) - (6)].pch), pdt);
      (yyvsp[(4) - (6)].pet)->symbol = pst;
      (yyval.pblockstmt) = buildChapelStmt(new DefExpr(pst));
    ;}
    break;

  case 189:
#line 909 "chapel.ypp"
    {
      (yyval.pet) = new EnumType();
      (yyvsp[(1) - (1)].pdefexpr)->sym->type = (yyval.pet);
      (yyval.pet)->constants.insertAtTail((yyvsp[(1) - (1)].pdefexpr));
      (yyval.pet)->defaultValue = (yyvsp[(1) - (1)].pdefexpr)->sym;
    ;}
    break;

  case 190:
#line 916 "chapel.ypp"
    {
      (yyvsp[(1) - (3)].pet)->constants.insertAtTail((yyvsp[(3) - (3)].pdefexpr));
      (yyvsp[(3) - (3)].pdefexpr)->sym->type = (yyvsp[(1) - (3)].pet);
    ;}
    break;

  case 191:
#line 925 "chapel.ypp"
    { (yyval.pdefexpr) = new DefExpr(new EnumSymbol((yyvsp[(1) - (1)].pch))); ;}
    break;

  case 192:
#line 927 "chapel.ypp"
    { (yyval.pdefexpr) = new DefExpr(new EnumSymbol((yyvsp[(1) - (3)].pch)), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 193:
#line 933 "chapel.ypp"
    {
      VarSymbol* var = new VarSymbol((yyvsp[(1) - (3)].pch));
      var->addFlag(FLAG_TYPE_VARIABLE);
      DefExpr* def = new DefExpr(var, (yyvsp[(3) - (3)].pexpr));
      (yyval.pblockstmt) = buildChapelStmt(def);
    ;}
    break;

  case 194:
#line 940 "chapel.ypp"
    {
      VarSymbol* var = new VarSymbol((yyvsp[(1) - (5)].pch));
      var->addFlag(FLAG_TYPE_VARIABLE);
      DefExpr* def = new DefExpr(var, (yyvsp[(3) - (5)].pexpr));
      (yyvsp[(5) - (5)].pblockstmt)->insertAtTail(def);
      (yyval.pblockstmt) = buildChapelStmt((yyvsp[(5) - (5)].pblockstmt));
    ;}
    break;

  case 195:
#line 951 "chapel.ypp"
    { (yyval.pblockstmt) = (yyvsp[(2) - (3)].pblockstmt); ;}
    break;

  case 196:
#line 957 "chapel.ypp"
    { (yyval.pexpr) = NULL; ;}
    break;

  case 197:
#line 959 "chapel.ypp"
    { (yyval.pexpr) = (yyvsp[(2) - (2)].pexpr); ;}
    break;

  case 198:
#line 965 "chapel.ypp"
    {
      VarSymbol* var = new VarSymbol((yyvsp[(2) - (4)].pch));
      var->addFlag(FLAG_TYPE_VARIABLE);
      DefExpr* def = new DefExpr(var, (yyvsp[(3) - (4)].pexpr));
      (yyval.pblockstmt) = buildChapelStmt(def);
    ;}
    break;

  case 199:
#line 976 "chapel.ypp"
    {
      setVarSymbolAttributes((yyvsp[(3) - (4)].pblockstmt), (yyvsp[(1) - (4)].b), true, false);
      backPropagateInitsTypes((yyvsp[(3) - (4)].pblockstmt));
      (yyval.pblockstmt) = (yyvsp[(3) - (4)].pblockstmt);
    ;}
    break;

  case 200:
#line 982 "chapel.ypp"
    {
      setVarSymbolAttributes((yyvsp[(3) - (4)].pblockstmt), (yyvsp[(1) - (4)].b), false, true);
      backPropagateInitsTypes((yyvsp[(3) - (4)].pblockstmt));
      (yyval.pblockstmt) = (yyvsp[(3) - (4)].pblockstmt);
    ;}
    break;

  case 201:
#line 988 "chapel.ypp"
    {
      setVarSymbolAttributes((yyvsp[(3) - (4)].pblockstmt), (yyvsp[(1) - (4)].b), false, false);
      backPropagateInitsTypes((yyvsp[(3) - (4)].pblockstmt));
      (yyval.pblockstmt) = (yyvsp[(3) - (4)].pblockstmt);
    ;}
    break;

  case 202:
#line 998 "chapel.ypp"
    { (yyval.b) = false; ;}
    break;

  case 203:
#line 1000 "chapel.ypp"
    { (yyval.b) = true; ;}
    break;

  case 204:
#line 1006 "chapel.ypp"
    { (yyval.pblockstmt) = (yyvsp[(1) - (1)].pblockstmt); ;}
    break;

  case 205:
#line 1008 "chapel.ypp"
    {
      for_alist(expr, (yyvsp[(3) - (3)].pblockstmt)->body)
        (yyvsp[(1) - (3)].pblockstmt)->insertAtTail(expr->remove());
      (yyval.pblockstmt) = (yyvsp[(1) - (3)].pblockstmt);
    ;}
    break;

  case 206:
#line 1018 "chapel.ypp"
    {
      VarSymbol* var = new VarSymbol((yyvsp[(1) - (3)].pch));
      (yyval.pblockstmt) = buildChapelStmt(new DefExpr(var, (yyvsp[(3) - (3)].pexpr), (yyvsp[(2) - (3)].pexpr)));
    ;}
    break;

  case 207:
#line 1023 "chapel.ypp"
    {
      VarSymbol* var = new VarSymbol((yyvsp[(1) - (3)].pch));
      (yyval.pblockstmt) = buildChapelStmt(new DefExpr(var, (yyvsp[(3) - (3)].pexpr), (yyvsp[(2) - (3)].pexpr)));
      var->addFlag(FLAG_ARRAY_ALIAS);
    ;}
    break;

  case 208:
#line 1029 "chapel.ypp"
    { (yyval.pblockstmt) = buildTupleVarDeclStmt((yyvsp[(2) - (5)].pblockstmt), (yyvsp[(4) - (5)].pexpr), (yyvsp[(5) - (5)].pexpr)); ;}
    break;

  case 209:
#line 1035 "chapel.ypp"
    { (yyval.pblockstmt) = buildChapelStmt(new DefExpr(new VarSymbol((yyvsp[(1) - (1)].pch)))); ;}
    break;

  case 210:
#line 1037 "chapel.ypp"
    { (yyval.pblockstmt) = buildChapelStmt((yyvsp[(2) - (3)].pblockstmt)); ;}
    break;

  case 211:
#line 1039 "chapel.ypp"
    {
      (yyvsp[(1) - (3)].pblockstmt)->insertAtTail(new DefExpr(new VarSymbol((yyvsp[(3) - (3)].pch))));
      (yyval.pblockstmt) = (yyvsp[(1) - (3)].pblockstmt);
    ;}
    break;

  case 212:
#line 1044 "chapel.ypp"
    {
      (yyvsp[(1) - (5)].pblockstmt)->insertAtTail((yyvsp[(4) - (5)].pblockstmt));
      (yyval.pblockstmt) = (yyvsp[(1) - (5)].pblockstmt);
    ;}
    break;

  case 213:
#line 1056 "chapel.ypp"
    { (yyval.pexpr) = new UnresolvedSymExpr("defaultDist"); ;}
    break;

  case 214:
#line 1058 "chapel.ypp"
    { (yyval.pexpr) = (yyvsp[(2) - (2)].pexpr); ;}
    break;

  case 215:
#line 1064 "chapel.ypp"
    { 
      if ((yyvsp[(2) - (6)].pcallexpr)->argList.length != 1)
        USR_FATAL((yyvsp[(4) - (6)].pexpr), "invalid index expression");
      (yyval.pexpr) = new CallExpr("chpl__buildArrayRuntimeType",
                        new CallExpr("chpl__buildDomainExpr", (yyvsp[(4) - (6)].pexpr)), (yyvsp[(6) - (6)].pexpr), (yyvsp[(2) - (6)].pcallexpr)->get(1)->remove(),
                        new CallExpr("chpl__buildDomainExpr", (yyvsp[(4) - (6)].pexpr)->copy()));
    ;}
    break;

  case 216:
#line 1072 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("chpl__buildArrayRuntimeType", new CallExpr("chpl__buildDomainExpr", (yyvsp[(2) - (4)].pcallexpr)), (yyvsp[(4) - (4)].pexpr)); ;}
    break;

  case 220:
#line 1085 "chapel.ypp"
    {
      CallExpr* call = new CallExpr("chpl__buildDomainRuntimeType", (yyvsp[(5) - (5)].pexpr));
      call->insertAtTail((yyvsp[(3) - (5)].pcallexpr));
      (yyval.pexpr) = call;
    ;}
    break;

  case 221:
#line 1091 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("chpl__buildSubDomainType", (yyvsp[(3) - (4)].pcallexpr)); ;}
    break;

  case 222:
#line 1093 "chapel.ypp"
    {
      CallExpr* call = new CallExpr("chpl__buildSparseDomainRuntimeType", (yyvsp[(6) - (6)].pexpr));
      call->insertAtTail((yyvsp[(4) - (6)].pcallexpr));
      (yyval.pexpr) = call;
    ;}
    break;

  case 223:
#line 1099 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr( "_singlevar", (yyvsp[(2) - (2)].pexpr)); ;}
    break;

  case 224:
#line 1101 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr( "_syncvar", (yyvsp[(2) - (2)].pexpr)); ;}
    break;

  case 225:
#line 1107 "chapel.ypp"
    { (yyval.pexpr) = (yyvsp[(2) - (2)].pexpr); ;}
    break;

  case 226:
#line 1113 "chapel.ypp"
    { (yyval.pexpr) = NULL; ;}
    break;

  case 227:
#line 1115 "chapel.ypp"
    { (yyval.pexpr) = (yyvsp[(2) - (2)].pexpr); ;}
    break;

  case 228:
#line 1121 "chapel.ypp"
    { (yyval.pexpr) = NULL; ;}
    break;

  case 229:
#line 1123 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("chpl__buildDomainExpr", (yyvsp[(3) - (4)].pcallexpr)); ;}
    break;

  case 230:
#line 1129 "chapel.ypp"
    { (yyval.pexpr) = NULL; ;}
    break;

  case 231:
#line 1131 "chapel.ypp"
    { (yyval.pexpr) = (yyvsp[(2) - (2)].pexpr); ;}
    break;

  case 232:
#line 1137 "chapel.ypp"
    { (yyval.pexpr) = NULL; ;}
    break;

  case 233:
#line 1139 "chapel.ypp"
    { (yyval.pexpr) = (yyvsp[(2) - (2)].pexpr); ;}
    break;

  case 234:
#line 1141 "chapel.ypp"
    { (yyval.pexpr) = (yyvsp[(2) - (2)].pexpr); ;}
    break;

  case 235:
#line 1143 "chapel.ypp"
    { (yyval.pexpr) = (yyvsp[(2) - (2)].pdefexpr); ;}
    break;

  case 236:
#line 1145 "chapel.ypp"
    { (yyval.pexpr) = new UnresolvedSymExpr("_domain"); ;}
    break;

  case 237:
#line 1147 "chapel.ypp"
    { (yyval.pexpr) = new UnresolvedSymExpr( "_singlevar"); ;}
    break;

  case 238:
#line 1149 "chapel.ypp"
    { (yyval.pexpr) = new UnresolvedSymExpr( "_syncvar"); ;}
    break;

  case 239:
#line 1151 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("chpl__buildArrayRuntimeType", gNil, (yyvsp[(4) - (4)].pexpr)); ;}
    break;

  case 240:
#line 1153 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("chpl__buildArrayRuntimeType", (yyvsp[(3) - (5)].pdefexpr), (yyvsp[(5) - (5)].pexpr)); ;}
    break;

  case 241:
#line 1155 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("chpl__buildArrayRuntimeType", gNil); ;}
    break;

  case 242:
#line 1157 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("chpl__buildArrayRuntimeType", (yyvsp[(3) - (4)].pdefexpr)); ;}
    break;

  case 243:
#line 1159 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("chpl__buildArrayRuntimeType", new CallExpr("chpl__buildDomainExpr", (yyvsp[(3) - (4)].pcallexpr))); ;}
    break;

  case 244:
#line 1161 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("chpl__buildArrayRuntimeType", gNil, (yyvsp[(4) - (4)].pdefexpr)); ;}
    break;

  case 245:
#line 1163 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("chpl__buildArrayRuntimeType", (yyvsp[(3) - (5)].pdefexpr), (yyvsp[(5) - (5)].pdefexpr)); ;}
    break;

  case 246:
#line 1165 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("chpl__buildArrayRuntimeType", new CallExpr("chpl__buildDomainExpr", (yyvsp[(3) - (5)].pcallexpr)), (yyvsp[(5) - (5)].pdefexpr)); ;}
    break;

  case 250:
#line 1174 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("*", (yyvsp[(1) - (3)].pexpr), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 253:
#line 1182 "chapel.ypp"
    { (yyval.pcallexpr) = new CallExpr(PRIM_ACTUALS_LIST); ;}
    break;

  case 255:
#line 1189 "chapel.ypp"
    { (yyval.pcallexpr) = new CallExpr(PRIM_ACTUALS_LIST, (yyvsp[(1) - (1)].pexpr)); ;}
    break;

  case 256:
#line 1191 "chapel.ypp"
    { (yyvsp[(1) - (3)].pcallexpr)->insertAtTail((yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 257:
#line 1197 "chapel.ypp"
    { (yyval.pexpr) = new NamedExpr((yyvsp[(1) - (3)].pch), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 258:
#line 1199 "chapel.ypp"
    { (yyval.pexpr) = (yyvsp[(1) - (1)].pdefexpr); ;}
    break;

  case 260:
#line 1206 "chapel.ypp"
    { 
      if ((yyvsp[(2) - (3)].pcallexpr)->argList.length == 1) {
        (yyval.pexpr) = (yyvsp[(2) - (3)].pcallexpr)->get(1);
        (yyval.pexpr)->remove();
      } else {
        (yyval.pexpr) = new CallExpr("_build_tuple", (yyvsp[(2) - (3)].pcallexpr));
      }
    ;}
    break;

  case 261:
#line 1219 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr((yyvsp[(1) - (4)].pexpr), (yyvsp[(3) - (4)].pcallexpr)); ;}
    break;

  case 262:
#line 1221 "chapel.ypp"
    {
      CallExpr* call = new CallExpr((yyvsp[(1) - (4)].pexpr), (yyvsp[(3) - (4)].pcallexpr));
      call->square = true;
      (yyval.pexpr) = call;
    ;}
    break;

  case 263:
#line 1227 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("chpl__buildIndexType", (yyvsp[(3) - (4)].pcallexpr)); ;}
    break;

  case 264:
#line 1232 "chapel.ypp"
    { (yyval.pexpr) = buildDotExpr((yyvsp[(1) - (3)].pexpr), (yyvsp[(3) - (3)].pch)); ;}
    break;

  case 265:
#line 1234 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr(PRIM_TYPEOF, (yyvsp[(1) - (3)].pexpr)); ;}
    break;

  case 266:
#line 1236 "chapel.ypp"
    { (yyval.pexpr) = buildDotExpr((yyvsp[(1) - (3)].pexpr), "_dom"); ;}
    break;

  case 267:
#line 1245 "chapel.ypp"
    { (yyval.pcallexpr) = new CallExpr(PRIM_ACTUALS_LIST); ;}
    break;

  case 269:
#line 1252 "chapel.ypp"
    { (yyval.pcallexpr) = new CallExpr(PRIM_ACTUALS_LIST, (yyvsp[(1) - (1)].pexpr)); ;}
    break;

  case 270:
#line 1254 "chapel.ypp"
    { (yyvsp[(1) - (3)].pcallexpr)->insertAtTail((yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 271:
#line 1260 "chapel.ypp"
    { (yyval.pexpr) = new NamedExpr((yyvsp[(1) - (3)].pch), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 273:
#line 1267 "chapel.ypp"
    {
      uint64_t ull;
      if (!strncmp("0b", yytext, 2))
        ull = binStr2uint64(yytext);
      else if (!strncmp("0x", yytext, 2))
        ull = hexStr2uint64(yytext);
      else
        ull = str2uint64(yytext);
      if (ull <= 2147483647ull)
        (yyval.pexpr) = new SymExpr(new_IntSymbol(ull, INT_SIZE_32));
      else if (ull <= 9223372036854775807ull)
        (yyval.pexpr) = new SymExpr(new_IntSymbol(ull, INT_SIZE_64));
      else
        (yyval.pexpr) = new SymExpr(new_UIntSymbol(ull, INT_SIZE_64));
    ;}
    break;

  case 274:
#line 1283 "chapel.ypp"
    { (yyval.pexpr) = new SymExpr(new_RealSymbol(yytext, strtod(yytext, NULL))); ;}
    break;

  case 275:
#line 1285 "chapel.ypp"
    {
      yytext[strlen(yytext)-1] = '\0';
      (yyval.pexpr) = new SymExpr(new_ImagSymbol(yytext, strtod(yytext, NULL)));
    ;}
    break;

  case 276:
#line 1290 "chapel.ypp"
    { (yyval.pexpr) = new SymExpr(new_StringSymbol((yyvsp[(1) - (1)].pch))); ;}
    break;

  case 277:
#line 1296 "chapel.ypp"
    { (yyval.pch) = astr(yytext); ;}
    break;

  case 278:
#line 1302 "chapel.ypp"
    { (yyval.pch) = NULL; ;}
    break;

  case 280:
#line 1309 "chapel.ypp"
    { 
      if ((yyvsp[(2) - (3)].pcallexpr)->argList.length == 1) {
        (yyval.pexpr) = (yyvsp[(2) - (3)].pcallexpr)->get(1);
        (yyval.pexpr)->remove();
      } else {
        (yyval.pexpr) = new CallExpr("_build_tuple", (yyvsp[(2) - (3)].pcallexpr));
      }
    ;}
    break;

  case 281:
#line 1322 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr((yyvsp[(1) - (4)].pexpr), (yyvsp[(3) - (4)].pcallexpr)); ;}
    break;

  case 282:
#line 1324 "chapel.ypp"
    {
      CallExpr* call = new CallExpr((yyvsp[(1) - (4)].pexpr), (yyvsp[(3) - (4)].pcallexpr));
      call->square = true;
      (yyval.pexpr) = call;
    ;}
    break;

  case 283:
#line 1330 "chapel.ypp"
    { (yyval.pexpr) = buildPrimitiveExpr((yyvsp[(3) - (4)].pcallexpr)); ;}
    break;

  case 284:
#line 1332 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("chpl__buildIndexType", (yyvsp[(3) - (4)].pcallexpr)); ;}
    break;

  case 285:
#line 1338 "chapel.ypp"
    { (yyval.pexpr) = buildDotExpr((yyvsp[(1) - (3)].pexpr), (yyvsp[(3) - (3)].pch)); ;}
    break;

  case 286:
#line 1340 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr(PRIM_TYPEOF, (yyvsp[(1) - (3)].pexpr)); ;}
    break;

  case 287:
#line 1342 "chapel.ypp"
    { (yyval.pexpr) = buildDotExpr((yyvsp[(1) - (3)].pexpr), "_dom"); ;}
    break;

  case 288:
#line 1348 "chapel.ypp"
    { (yyval.pexpr) = new UnresolvedSymExpr((yyvsp[(1) - (1)].pch)); ;}
    break;

  case 293:
#line 1358 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("chpl__buildDomainExpr", (yyvsp[(2) - (3)].pcallexpr)); ;}
    break;

  case 297:
#line 1371 "chapel.ypp"
    {
      if ((yyvsp[(2) - (6)].pcallexpr)->argList.length != 1)
        USR_FATAL((yyvsp[(4) - (6)].pexpr), "invalid index expression");
      (yyval.pexpr) = buildForallLoopExpr((yyvsp[(2) - (6)].pcallexpr)->get(1)->remove(), (yyvsp[(4) - (6)].pexpr), (yyvsp[(6) - (6)].pexpr));
    ;}
    break;

  case 298:
#line 1377 "chapel.ypp"
    {
      if ((yyvsp[(2) - (4)].pcallexpr)->argList.length != 1)
        USR_FATAL((yyvsp[(4) - (4)].pexpr), "invalid loop expression");
      (yyval.pexpr) = buildForallLoopExpr(NULL, (yyvsp[(2) - (4)].pcallexpr)->get(1)->remove(), (yyvsp[(4) - (4)].pexpr));
    ;}
    break;

  case 299:
#line 1383 "chapel.ypp"
    {
      if ((yyvsp[(2) - (9)].pcallexpr)->argList.length != 1)
        USR_FATAL((yyvsp[(4) - (9)].pexpr), "invalid index expression");
      (yyval.pexpr) = buildForallLoopExpr((yyvsp[(2) - (9)].pcallexpr)->get(1)->remove(), (yyvsp[(4) - (9)].pexpr), (yyvsp[(9) - (9)].pexpr), (yyvsp[(7) - (9)].pexpr));
    ;}
    break;

  case 300:
#line 1389 "chapel.ypp"
    {
      if ((yyvsp[(2) - (7)].pcallexpr)->argList.length != 1)
        USR_FATAL((yyvsp[(5) - (7)].pexpr), "invalid loop expression");
      (yyval.pexpr) = buildForallLoopExpr(NULL, (yyvsp[(2) - (7)].pcallexpr)->get(1)->remove(), (yyvsp[(7) - (7)].pexpr), (yyvsp[(5) - (7)].pexpr));
    ;}
    break;

  case 301:
#line 1395 "chapel.ypp"
    { (yyval.pexpr) = buildForLoopExpr((yyvsp[(2) - (6)].pexpr), (yyvsp[(4) - (6)].pexpr), (yyvsp[(6) - (6)].pexpr)); ;}
    break;

  case 302:
#line 1397 "chapel.ypp"
    { (yyval.pexpr) = buildForLoopExpr(NULL, (yyvsp[(2) - (4)].pexpr), (yyvsp[(4) - (4)].pexpr)); ;}
    break;

  case 303:
#line 1399 "chapel.ypp"
    { (yyval.pexpr) = buildForLoopExpr((yyvsp[(2) - (9)].pexpr), (yyvsp[(4) - (9)].pexpr), (yyvsp[(9) - (9)].pexpr), (yyvsp[(7) - (9)].pexpr)); ;}
    break;

  case 304:
#line 1401 "chapel.ypp"
    { (yyval.pexpr) = buildForLoopExpr(NULL, (yyvsp[(2) - (7)].pexpr), (yyvsp[(7) - (7)].pexpr), (yyvsp[(5) - (7)].pexpr)); ;}
    break;

  case 305:
#line 1403 "chapel.ypp"
    { (yyval.pexpr) = buildForallLoopExpr((yyvsp[(2) - (6)].pexpr), (yyvsp[(4) - (6)].pexpr), (yyvsp[(6) - (6)].pexpr)); ;}
    break;

  case 306:
#line 1405 "chapel.ypp"
    { (yyval.pexpr) = buildForallLoopExpr(NULL, (yyvsp[(2) - (4)].pexpr), (yyvsp[(4) - (4)].pexpr)); ;}
    break;

  case 307:
#line 1407 "chapel.ypp"
    { (yyval.pexpr) = buildForallLoopExpr((yyvsp[(2) - (9)].pexpr), (yyvsp[(4) - (9)].pexpr), (yyvsp[(9) - (9)].pexpr), (yyvsp[(7) - (9)].pexpr)); ;}
    break;

  case 308:
#line 1409 "chapel.ypp"
    { (yyval.pexpr) = buildForallLoopExpr(NULL, (yyvsp[(2) - (7)].pexpr), (yyvsp[(7) - (7)].pexpr), (yyvsp[(5) - (7)].pexpr)); ;}
    break;

  case 309:
#line 1411 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr(new DefExpr(buildIfExpr((yyvsp[(2) - (6)].pexpr), (yyvsp[(4) - (6)].pexpr), (yyvsp[(6) - (6)].pexpr)))); ;}
    break;

  case 311:
#line 1418 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr(PRIM_NEW, (yyvsp[(2) - (2)].pexpr)); ;}
    break;

  case 312:
#line 1420 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr(PRIM_TUPLE_EXPAND, (yyvsp[(3) - (4)].pexpr)); ;}
    break;

  case 313:
#line 1422 "chapel.ypp"
    { (yyval.pexpr) = new SymExpr(gNil); ;}
    break;

  case 314:
#line 1424 "chapel.ypp"
    { (yyval.pexpr) = buildLetExpr((yyvsp[(2) - (4)].pblockstmt), (yyvsp[(4) - (4)].pexpr)); ;}
    break;

  case 317:
#line 1428 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("_cast", (yyvsp[(3) - (3)].pexpr), (yyvsp[(1) - (3)].pexpr)); ;}
    break;

  case 318:
#line 1430 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("_build_range", (yyvsp[(1) - (3)].pexpr), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 319:
#line 1432 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("_build_range", buildDotExpr("BoundedRangeType", "boundedLow"), (yyvsp[(1) - (2)].pexpr)); ;}
    break;

  case 320:
#line 1434 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("_build_range", buildDotExpr("BoundedRangeType", "boundedHigh"), (yyvsp[(2) - (2)].pexpr)); ;}
    break;

  case 321:
#line 1436 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("_build_range", buildDotExpr("BoundedRangeType", "boundedNone")); ;}
    break;

  case 322:
#line 1438 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("+", (yyvsp[(2) - (2)].pexpr)); ;}
    break;

  case 323:
#line 1440 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("-", (yyvsp[(2) - (2)].pexpr)); ;}
    break;

  case 324:
#line 1442 "chapel.ypp"
    { (yyval.pexpr) = buildPreDecIncWarning((yyvsp[(2) - (2)].pexpr), '-'); ;}
    break;

  case 325:
#line 1444 "chapel.ypp"
    { (yyval.pexpr) = buildPreDecIncWarning((yyvsp[(2) - (2)].pexpr), '+'); ;}
    break;

  case 326:
#line 1446 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("!", (yyvsp[(2) - (2)].pexpr)); ;}
    break;

  case 327:
#line 1448 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("~", (yyvsp[(2) - (2)].pexpr)); ;}
    break;

  case 328:
#line 1450 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("+", (yyvsp[(1) - (3)].pexpr), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 329:
#line 1452 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("-", (yyvsp[(1) - (3)].pexpr), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 330:
#line 1454 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("*", (yyvsp[(1) - (3)].pexpr), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 331:
#line 1456 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("/", (yyvsp[(1) - (3)].pexpr), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 332:
#line 1458 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("<<", (yyvsp[(1) - (3)].pexpr), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 333:
#line 1460 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr(">>", (yyvsp[(1) - (3)].pexpr), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 334:
#line 1462 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("%", (yyvsp[(1) - (3)].pexpr), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 335:
#line 1464 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("==", (yyvsp[(1) - (3)].pexpr), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 336:
#line 1466 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("!=", (yyvsp[(1) - (3)].pexpr), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 337:
#line 1468 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("<=", (yyvsp[(1) - (3)].pexpr), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 338:
#line 1470 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr(">=", (yyvsp[(1) - (3)].pexpr), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 339:
#line 1472 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("<", (yyvsp[(1) - (3)].pexpr), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 340:
#line 1474 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr(">", (yyvsp[(1) - (3)].pexpr), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 341:
#line 1476 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("&", (yyvsp[(1) - (3)].pexpr), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 342:
#line 1478 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("|", (yyvsp[(1) - (3)].pexpr), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 343:
#line 1480 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("^", (yyvsp[(1) - (3)].pexpr), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 344:
#line 1482 "chapel.ypp"
    { (yyval.pexpr) = buildLogicalAndExpr((yyvsp[(1) - (3)].pexpr), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 345:
#line 1484 "chapel.ypp"
    { (yyval.pexpr) = buildLogicalOrExpr((yyvsp[(1) - (3)].pexpr), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 346:
#line 1486 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("**", (yyvsp[(1) - (3)].pexpr), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 347:
#line 1488 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("by", (yyvsp[(1) - (3)].pexpr), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 348:
#line 1490 "chapel.ypp"
    { (yyval.pexpr) = new CallExpr("#", (yyvsp[(1) - (3)].pexpr), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 349:
#line 1496 "chapel.ypp"
    { (yyval.pexpr) = buildReduceExpr((yyvsp[(1) - (3)].pexpr), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 350:
#line 1498 "chapel.ypp"
    { (yyval.pexpr) = buildReduceExpr(new UnresolvedSymExpr("SumReduceScanOp"), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 351:
#line 1500 "chapel.ypp"
    { (yyval.pexpr) = buildReduceExpr(new UnresolvedSymExpr("ProductReduceScanOp"), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 352:
#line 1502 "chapel.ypp"
    { (yyval.pexpr) = buildReduceExpr(new UnresolvedSymExpr("LogicalAndReduceScanOp"), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 353:
#line 1504 "chapel.ypp"
    { (yyval.pexpr) = buildReduceExpr(new UnresolvedSymExpr("LogicalOrReduceScanOp"), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 354:
#line 1506 "chapel.ypp"
    { (yyval.pexpr) = buildReduceExpr(new UnresolvedSymExpr("BitwiseAndReduceScanOp"), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 355:
#line 1508 "chapel.ypp"
    { (yyval.pexpr) = buildReduceExpr(new UnresolvedSymExpr("BitwiseOrReduceScanOp"), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 356:
#line 1510 "chapel.ypp"
    { (yyval.pexpr) = buildReduceExpr(new UnresolvedSymExpr("BitwiseXorReduceScanOp"), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 357:
#line 1516 "chapel.ypp"
    { (yyval.pexpr) = buildScanExpr((yyvsp[(1) - (3)].pexpr), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 358:
#line 1518 "chapel.ypp"
    { (yyval.pexpr) = buildScanExpr(new UnresolvedSymExpr("SumReduceScanOp"), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 359:
#line 1520 "chapel.ypp"
    { (yyval.pexpr) = buildScanExpr(new UnresolvedSymExpr("ProductReduceScanOp"), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 360:
#line 1522 "chapel.ypp"
    { (yyval.pexpr) = buildScanExpr(new UnresolvedSymExpr("LogicalAndReduceScanOp"), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 361:
#line 1524 "chapel.ypp"
    { (yyval.pexpr) = buildScanExpr(new UnresolvedSymExpr("LogicalOrReduceScanOp"), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 362:
#line 1526 "chapel.ypp"
    { (yyval.pexpr) = buildScanExpr(new UnresolvedSymExpr("BitwiseAndReduceScanOp"), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 363:
#line 1528 "chapel.ypp"
    { (yyval.pexpr) = buildScanExpr(new UnresolvedSymExpr("BitwiseOrReduceScanOp"), (yyvsp[(3) - (3)].pexpr)); ;}
    break;

  case 364:
#line 1530 "chapel.ypp"
    { (yyval.pexpr) = buildScanExpr(new UnresolvedSymExpr("BitwiseXorReduceScanOp"), (yyvsp[(3) - (3)].pexpr)); ;}
    break;


/* Line 1267 of yacc.c.  */
#line 5030 "chapel.tab.cpp"
      default: break;
    }
  YY_SYMBOL_PRINT ("-> $$ =", yyr1[yyn], &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;
  *++yylsp = yyloc;

  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if ! YYERROR_VERBOSE
      yyerror (YY_("syntax error"));
#else
      {
	YYSIZE_T yysize = yysyntax_error (0, yystate, yychar);
	if (yymsg_alloc < yysize && yymsg_alloc < YYSTACK_ALLOC_MAXIMUM)
	  {
	    YYSIZE_T yyalloc = 2 * yysize;
	    if (! (yysize <= yyalloc && yyalloc <= YYSTACK_ALLOC_MAXIMUM))
	      yyalloc = YYSTACK_ALLOC_MAXIMUM;
	    if (yymsg != yymsgbuf)
	      YYSTACK_FREE (yymsg);
	    yymsg = (char *) YYSTACK_ALLOC (yyalloc);
	    if (yymsg)
	      yymsg_alloc = yyalloc;
	    else
	      {
		yymsg = yymsgbuf;
		yymsg_alloc = sizeof yymsgbuf;
	      }
	  }

	if (0 < yysize && yysize <= yymsg_alloc)
	  {
	    (void) yysyntax_error (yymsg, yystate, yychar);
	    yyerror (yymsg);
	  }
	else
	  {
	    yyerror (YY_("syntax error"));
	    if (yysize != 0)
	      goto yyexhaustedlab;
	  }
      }
#endif
    }

  yyerror_range[0] = yylloc;

  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse look-ahead token after an
	 error, discard it.  */

      if (yychar <= YYEOF)
	{
	  /* Return failure if at end of input.  */
	  if (yychar == YYEOF)
	    YYABORT;
	}
      else
	{
	  yydestruct ("Error: discarding",
		      yytoken, &yylval, &yylloc);
	  yychar = YYEMPTY;
	}
    }

  /* Else will try to reuse look-ahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

  /* Pacify compilers like GCC when the user code never invokes
     YYERROR and the label yyerrorlab therefore never appears in user
     code.  */
  if (/*CONSTCOND*/ 0)
     goto yyerrorlab;

  yyerror_range[0] = yylsp[1-yylen];
  /* Do not reclaim the symbols of the rule which action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;	/* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (yyn != YYPACT_NINF)
	{
	  yyn += YYTERROR;
	  if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
	    {
	      yyn = yytable[yyn];
	      if (0 < yyn)
		break;
	    }
	}

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
	YYABORT;

      yyerror_range[0] = *yylsp;
      yydestruct ("Error: popping",
		  yystos[yystate], yyvsp, yylsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  *++yyvsp = yylval;

  yyerror_range[1] = yylloc;
  /* Using YYLLOC is tempting, but would change the location of
     the look-ahead.  YYLOC is available though.  */
  YYLLOC_DEFAULT (yyloc, (yyerror_range - 1), 2);
  *++yylsp = yyloc;

  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#ifndef yyoverflow
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
  if (yychar != YYEOF && yychar != YYEMPTY)
     yydestruct ("Cleanup: discarding lookahead",
		 yytoken, &yylval, &yylloc);
  /* Do not reclaim the symbols of the rule which action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
		  yystos[*yyssp], yyvsp, yylsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
#if YYERROR_VERBOSE
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
#endif
  /* Make sure YYID is used.  */
  return YYID (yyresult);
}


#line 1534 "chapel.ypp"


