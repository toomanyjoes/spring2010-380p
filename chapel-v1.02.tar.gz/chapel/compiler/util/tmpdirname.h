/**************************************************************************
  Copyright (c) 2004-2009 Cray Inc.  (See LICENSE file for more details)
**************************************************************************/


#ifndef _TMPDIRNAME_H_
#define _TMPDIRNAME_H_

extern const char* tmpdirname;

#endif
