/**************************************************************************
  Copyright (c) 2004-2009 Cray Inc.  (See LICENSE file for more details)
**************************************************************************/


#ifndef _RUN_PASSES_H_
#define _RUN_PASSES_H_

extern bool printPasses;

void runPasses(void);

#endif
